package e13.packets;

import java.io.Serializable;

/**
 * La clase Person representa una persona que atiende a un evento
 * Implementa Serializable para poder transferir objetos de esta clase
 * Implementa Comparabla para poder ordenar personas en base a su apellido
 * @author Sebas Lavigne
 */
public class Person implements Serializable, Comparable<Person> {

	private static final long serialVersionUID = -2372707715515770180L;
	
	private String nid;
	private String name;
	private String surname;
	private int phone;
	private String email;
	
	public Person() {
		
	}
	
	@Override
	public String toString() {
		return "Person [nid=" + nid + ", name=" + name + ", surname=" + surname + ", phone=" + phone + ", email="
				+ email + "]";
	}

	/**
	 * @return the nid
	 */
	public String getNid() {
		return nid;
	}

	/**
	 * @param nid the nid to set
	 */
	public void setNid(String nid) {
		this.nid = nid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * @return the phone
	 */
	public int getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(int phone) {
		this.phone = phone;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public int compareTo(Person other) {
		return this.getSurname().compareToIgnoreCase(other.getSurname());
	}
	
	
	
	

}

