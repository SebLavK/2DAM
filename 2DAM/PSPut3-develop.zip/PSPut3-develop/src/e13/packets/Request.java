package e13.packets;

import java.io.Serializable;

/**
*@author Sebas Lavigne
*
*/

public class Request implements Serializable {
	
	private static final long serialVersionUID = -5925790230912809357L;
	
	public static final int ADD_REQUEST = 0;
	public static final int CHECK_REQUEST = 1;
	public static final int LIST_REQUEST = 2;
	
	public static final String[] REQUEST_OPTIONS = {
			"Agregar una persona a la lista",
			"Verificar que una persona esta en la lista",
			"Ver lista de invitados"
	};
	
	private int requestCode;
	private Person person;
	private int sortMode;
	
	public Request(int requestCode) {
		this.requestCode = requestCode;
		person = null;
		sortMode = -1;
	}
	
	/**
	 * Verifica que este objeto contenga la informacion requerida en base al tipo de peticion
	 * @return
	 */
	public boolean isValid() {
		//Si se pide anadir o verificar una persona, el objeto debe contener una persona con DNI no nulo
		if ((requestCode == ADD_REQUEST || requestCode == CHECK_REQUEST)
				&& person != null && person.getNid() != null) {
			return true;
			//Si se pide listar las personas, el objeto debe tener definido el tipo de ordenacion
		} else if (requestCode == LIST_REQUEST && sortMode != -1) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @return the requestCode
	 */
	public int getRequestCode() {
		return requestCode;
	}

	/**
	 * @param requestCode the requestCode to set
	 */
	public void setRequestCode(int requestCode) {
		this.requestCode = requestCode;
	}

	/**
	 * @return the person
	 */
	public Person getPerson() {
		return person;
	}

	/**
	 * @param person the person to set
	 */
	public void setPerson(Person person) {
		this.person = person;
	}

	/**
	 * @return the sortMode
	 */
	public int getSortMode() {
		return sortMode;
	}

	/**
	 * @param sortMode the sortMode to set
	 */
	public void setSortMode(int sortMode) {
		this.sortMode = sortMode;
	}
	
	

}

