package e13.packets;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * La clase Attendees transporta una lista de asistentes del Servidor al Cliente
 * Contiene un TreeSet de Person instanciado con el comparador que haya
 * especificado el Cliente en su peticion para ser mostrado en el orden deseado
 * @author Sebas Lavigne
 */
public class Attendees implements Serializable {

	private static final long serialVersionUID = 3023159232487349294L;
	
	private ArrayList<Person> attendeeList;

	/**
	 * @param attendeesList
	 */
	public Attendees(ArrayList<Person> attendeeList) {
		super();
		this.attendeeList = attendeeList;
	}
	
	public void showList() {
		System.out.println("Lista de invitados ("+attendeeList.size()+" entradas)");
		for (Person person : attendeeList) {
			System.out.println(person);
		}
	}

	
}

