package e13.utils;

import java.util.Scanner;

import e13.packets.Person;

/**
*@author Sebas Lavigne
*/

public class PersonGenerator {
	
	private static String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	private static int inputInt() {
		try {
			return Integer.parseInt(inputString());
		} catch (NumberFormatException e) {
			System.out.println("Debes introducir un numero");
			return inputInt();
		}
	}
	
	/**
	 * Devuelve una persona con todos sus datos rellenos por el usuario
	 * @return
	 */
	public static Person generateFullPerson() {
		Person person = new Person();
		System.out.println("Introduce los datos de la persona");
		System.out.println("\tIntroduce el DNI");
		person.setNid(inputString());
		System.out.println("\tIntroduce el nombre");
		person.setName(inputString());
		System.out.println("\tIntroduce los apellidos");
		person.setSurname(inputString());
		System.out.println("\tIntroduce el telefono");
		person.setPhone(inputInt());
		System.out.println("\tIntroduce el e-mail");
		person.setEmail(inputString());
		
		return person;
	}
	
	/**
	 * Devuelve una persona con el DNI relleno por el usuario
	 * @return
	 */
	public static Person generateIDPerson() {
		Person person = new Person();
		System.out.println("Introduce el DNI de la persona");
		person.setNid(inputString());
		
		return person;
	}

}
