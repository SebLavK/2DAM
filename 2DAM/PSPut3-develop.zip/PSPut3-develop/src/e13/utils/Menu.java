package e13.utils;

import java.util.Scanner;

/**
*@author Sebas Lavigne
*
*/

public final class Menu {

	private Menu() {};
	
	/**
	 * Muestra un menu acorde con un array de objetos que recibe y devuelve una
	 * opcion elegida por el usuario.
	 * 
	 * Las opciones se numeran a partir del uno, se devuelve restando uno para
	 * que la opcion este acorde al indice del array.
	 * 
	 * Tener en cuenta que la opcion de salida devuelve -1 para el control de flujo
	 * que recibe el return de este metodo.
	 * 
	 * @param items array de objetos con el que generar el menu
	 * @param exitItem opcion de salida
	 * @param msg mensaje del menu, se puede poner nulo
	 * @return
	 */
	public static int generateMenu(Object[] items, boolean exitItem, String msg) {
		int option = -2;
		int i = 1; //Contador para elementos del menu
		int min = 1; //Valor minimo del menu, se pone a 0 si la opcion de salir se incluye
		if (msg == null) {
			msg = "";
		}
		
		//Muestra los elementos del menu
		System.out.println("\nMENU: "+ msg + "\n--------------------");
		for (Object item : items) {
			System.out.println(i + " - " + item);
			i++;
		}
		
		if (exitItem) {//Si el menu tiene la opcion de salir
			System.out.println("\n0 - Salir");//Muestra la opcion
			min = 0;//Establece el rango minimo a 0
		}
		
		//Pide al usuario la opcion tantas veces sea necesario
		do {
			System.out.print("--------------------\nOpcion: ");
			try {
				option = Integer.parseInt(new Scanner(System.in).nextLine());
			} catch (Exception e) {
				System.out.println("Debes introducir un numero");
			}
		} while (option < min || option >= i);
		System.out.println();
		return option - 1;//Devuelve el valor 'real' de la posicion del array
	}
}