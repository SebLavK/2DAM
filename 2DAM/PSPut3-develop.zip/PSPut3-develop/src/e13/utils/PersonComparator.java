package e13.utils;

import e13.packets.Person;

/**
*@author Sebas Lavigne
*
*/

public class PersonComparator {
	
	public static final int COMPARE_NID = 0;
	public static final int COMPARE_NAME = 1;
	public static final int COMPARE_SURNAME = 2;
	public static final int COMPARE_PHONE = 3;
	public static final int COMPARE_EMAIL = 4;
	
	public static final String[] COMPARISON_OPTIONS = {
			"Ordenar por DNI",
			"Ordenar por Nombre",
			"Ordenar por Apellido",
			"Ordenar por Telefono",
			"Ordenar por E-Mail"
	};
	
	private PersonComparator() {}
	
	public static int compareByNid(Person p1, Person p2) {
		return p1.getNid().compareToIgnoreCase(p2.getNid());
	}
	
	public static int compareByName(Person p1, Person p2) {
		return p1.getName().compareToIgnoreCase(p2.getName());
	}
	
	public static int compareBySurname(Person p1, Person p2) {
		return p1.getSurname().compareToIgnoreCase(p2.getSurname());
	}
	
	public static int compareByPhone(Person p1, Person p2) {
		return p1.getPhone() - p2.getPhone();
	}
	
	public static int compareByEmail(Person p1, Person p2) {
		return p1.getEmail().compareToIgnoreCase(p2.getEmail());
	}

}

