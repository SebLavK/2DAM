package e13.threads;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import e13.main.Server;
import e13.packets.Attendees;
import e13.packets.Person;
import e13.packets.Request;

/**
*@author Sebas Lavigne
*
*/

public class TicketSeller extends Thread {
	
	private Server server;
	private Socket socket;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private DataOutputStream os;
	
	public TicketSeller(Server server, Socket socket) {
		this.server = server;
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			ois = new ObjectInputStream(socket.getInputStream());
			oos = new ObjectOutputStream(socket.getOutputStream());
			os = new DataOutputStream(socket.getOutputStream());
			while (true) {
				Request request = getRequest();
				processRequest(request);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
//			e.printStackTrace();
			System.out.println("XXX Cliente "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort()
					+ " ha cerrado la conexion");
		}
	}
	
	/**
	 * Obtiene una peticion del cliente conectado al socket
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	private Request getRequest() throws ClassNotFoundException, IOException {
		Request request = (Request) ois.readObject();
		return request;
		
	}

	/**
	 * Control de flujo en funcion del tipo de peticion
	 * @param request
	 * @throws IOException 
	 */
	private void processRequest(Request request) throws IOException {
		switch (request.getRequestCode()) {
		case Request.ADD_REQUEST:
			addPerson(request);
			break;
		case Request.CHECK_REQUEST:
			checkPerson(request);
			break;
		case Request.LIST_REQUEST:
			listAttendees(request);
			break;
		default:
			break;
		}
	}
	
	/**
	 * Manda al cliente un texto verificando si se pudo anaidr una persona a la lista o no
	 * @param request
	 * @throws IOException
	 */
	private void addPerson(Request request) throws IOException {
		if (server.addAttendee(request.getPerson())) {
			os.writeUTF("Persona anadida a la lsita");
		} else {
			os.writeUTF("Error. Ya hay en la lista una persona con ese DNI");
		}
	}
	
	/**
	 * Manda al cliente un texto verificando si una persona se encuentra en la lista o no
	 * @param request
	 * @throws IOException
	 */
	private void checkPerson(Request request) throws IOException {
		Person person = server.getAttendee(request.getPerson().getNid());
		if (person != null) {
			os.writeUTF(person.getName() + " " + person.getSurname() + " se encuentra en la lista");
		} else {
			os.writeUTF("Esa persona no se encuentra en la lista");
		}
	}
	
	/**
	 * Manda al cliente un TreeSet de las personas que se encuentran en la lista
	 * ordenadas de la forma en que pidio
	 * @param request
	 * @throws IOException
	 */
	private void listAttendees(Request request) throws IOException {
		int sortMode = request.getSortMode();
		Attendees set = server.generateOrderedSet(sortMode); 
		oos.writeObject(set);
		oos.flush();
		oos.reset();
	}
	
	

}

