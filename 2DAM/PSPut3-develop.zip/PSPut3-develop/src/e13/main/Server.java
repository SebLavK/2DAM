package e13.main;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.TreeSet;

import e13.packets.Attendees;
import e13.packets.Person;
import e13.threads.TicketSeller;
import e13.utils.PersonComparator;

/**
 * El Servidor se encarga de mantener una lista de personas que atenderan al evento
 * Lanza un TicketSeller para cada conexion entrante desde un cliente
 * 
 * El cliente puede enviar una peticion para:
 *   - Agregar una persona a la lista de asistentes
 *   - Verificar que una persona se encuentre en una lista a partir de su DNI
 *   - Obtener una lista de personas que van a atender, ordenada de distintas maneras
 * @author Sebas Lavigne
 */
public class Server {
	
	public static final int PORT = 8000;
	
	private ServerSocket serverSocket;
	
	private TreeMap<String, Person> attendeeMap;
	
	public static void main(String[] args) {
		Server server = new Server();
		server.initializeServer();
		
		try {
			while (true) server.launchTicketSeller();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		server.closeConnection();
	}

	/**
	 * Inicia el ServerSocket del servidor e inicializa el mapa de invitados
	 */
	public void initializeServer() {
		attendeeMap = new TreeMap<>();
		try {
			serverSocket = new ServerSocket(PORT);
			System.out.println("Servidor a la escucha en el puerto "
					+ serverSocket.getLocalPort() + "...");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Espera una conexion entrante desde un cliente y le lanza un "gestor de tickets"
	 * @throws IOException
	 */
	public void launchTicketSeller() throws IOException {
		System.out.println("Servidor esperando conexion...");
		Socket socket = serverSocket.accept();
		System.out.println("Conexion establecida con: "
				+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		new TicketSeller(this, socket).start();
	}
	
	/**
	 * Anade una persona al mapa si no existe ya una clave (si no hay nadie con ese DNI)
	 * @param person
	 * @return verdadero si se anade, falso si ya existe la clave
	 */
	public synchronized boolean addAttendee(Person person) {
		if (!attendeeMap.containsKey(person.getNid())) {
			attendeeMap.put(person.getNid(), person);
			System.out.println("Anadida la persona\n"+person);
			return true;
		} else {
			System.out.println("Se intento anadir la persona (ya existe una persona con ese DNI)\n"+person);
			return false;
		}
	}
	
	/**
	 * Devuelve la persona cuyo DNI sea el que se recibe por parametro
	 * @param nid el DNI de la persona a recuperar del mapa
	 * @return la persona con el DNI especificado
	 */
	public synchronized Person getAttendee(String nid) {
		System.out.println("Se intento acceder al mapa con la clave: " + nid);
		return attendeeMap.get(nid);
	}
	
	/**
	 * Devuelve una lista a partir del mapa ordenada de la manera especificada por parametro
	 * @param sortMode el tipo de ordenacion que se pide
	 * @return la lista ordenada
	 */
	public synchronized Attendees generateOrderedSet(int sortMode) {
		TreeSet<Person> attendeeSet = null;
		//Genera el TreeSet con el Comparator requerido
		switch (sortMode) {
		case PersonComparator.COMPARE_NID:
			attendeeSet = new TreeSet<>(PersonComparator::compareByNid);
			break;
		case PersonComparator.COMPARE_NAME:
			attendeeSet = new TreeSet<>(PersonComparator::compareByName);
			break;
		case PersonComparator.COMPARE_SURNAME:
			attendeeSet = new TreeSet<>(PersonComparator::compareBySurname);
			break;
		case PersonComparator.COMPARE_PHONE:
			attendeeSet = new TreeSet<>(PersonComparator::compareByPhone);
			break;
		case PersonComparator.COMPARE_EMAIL:
			attendeeSet = new TreeSet<>(PersonComparator::compareByEmail);
			break;
		}
		
		//Anade Person al TreeSet a partir del Mapa de invitados
		for (Person person : attendeeMap.values()) {
			attendeeSet.add(person);
		}
		
		
		/*
		 * Al parecer, si genero un TreeSet con un comparador con Lambdas
		 * de la manera en que lo hago
		 * ese TreeSet ya no es serializable
		 * 
		 * Usar un ArrayList es un arreglo rapido
		 * 
		 * La verdadera solucion reside en crear los comparadores como clases
		 * propias y serializables
		 */
		ArrayList<Person> list = new ArrayList<>();
		for (Person person : attendeeSet) {
			list.add(person);
		}
		
		Attendees attendees = new Attendees(list);
		
		System.out.println("Se ha generado la lista ordenada mediante el codigo: "+sortMode);
		System.out.println("Mapa");
		System.out.println(attendeeMap.size());
		System.out.println("Set");
		System.out.println(attendeeSet.size());
		attendees.showList();
		
		return attendees;
	}
	
	/**
	 * Cierra la conexion
	 */
	public void closeConnection() {
		try {
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

