package e13.main;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import e13.packets.Attendees;
import e13.packets.Request;
import e13.utils.Menu;
import e13.utils.PersonComparator;
import e13.utils.PersonGenerator;

/**
*@author Sebas Lavigne
*
*/

public class Client {
	
	public static final String ADDRESS = "localhost";
	public static final int PORT = 8000;
	
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private DataInputStream is;
	

	public static void main(String[] args) {
		Client client = new Client();
		client.setConnection();
		client.initializeStreams();
		client.interact();
		client.closeStreams();
		client.closeConnection();
	}
	
	/**
	 * Establece conexion con el servidor
	 */
	public void setConnection() {
		try {
			socket = new Socket(ADDRESS, PORT);
			System.out.println("Socket iniciado en "
			+ socket.getInetAddress().getHostAddress() + ":" + socket.getLocalPort());
			System.out.println("Conexion establecida con: "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void initializeStreams() {
		try {
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
			is = new DataInputStream(socket.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void interact() {
		boolean done = false;
		while (!done) {
			switch (Menu.generateMenu(Request.REQUEST_OPTIONS, true, "Que deseas hacer?")) {
			case -1:
				done = true;
				System.out.println("Saliendo del programa");
				break;
			case Request.ADD_REQUEST:
				generateAddRequest();
				break;
			case Request.CHECK_REQUEST:
				generateCheckRequest();
				break;
			case Request.LIST_REQUEST:
				generateListRequest();
				break;
			default:
				System.out.println("No existe esa opcion");
			}
			if (!done) {
				System.out.println("Pulsa INTRO para continuar");
				new Scanner(System.in).nextLine();
			}
		}
	}
	
	/**
	 * Genera una peticion para anadir una persona
	 * Manda la peticion
	 * Recibe la respuesta del servidor
	 */
	public void generateAddRequest() {
		Request request = new Request(Request.ADD_REQUEST);
		request.setPerson(PersonGenerator.generateFullPerson());
		if (sendRequest(request)) {
			try {
				System.out.println(is.readUTF());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Genera una peticion para verificar que una persona esta en la lista
	 * Manda la peticion
	 * Recibe la respuesta del servidor
	 */
	public void generateCheckRequest() {
		Request request = new Request(Request.CHECK_REQUEST);
		request.setPerson(PersonGenerator.generateIDPerson());
		if (sendRequest(request)) {
			try {
				System.out.println(is.readUTF());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Genera una peticion para listar las personas en la lista del servidor
	 * Manda la peticion
	 * Recibe un objeto Attendees con la lista de personas
	 */
	public void generateListRequest() {
		Request request = new Request(Request.LIST_REQUEST);
		request.setSortMode(Menu.generateMenu(PersonComparator.COMPARISON_OPTIONS, false, "Como quieres ordenar la lista?"));
		if (sendRequest(request)) {
			try {
				Attendees set = (Attendees) ois.readObject();
				set.showList();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Envia una peticion
	 * @param request la peticion a enviar
	 * @return verdareo si la peticion fue enviada
	 */
	public boolean sendRequest(Request request) {
		boolean sent = false;
		try {
			if (request.isValid()) {
				oos.writeObject(request);
				oos.flush();
				oos.reset();
				sent = true;
				System.out.println("Peticion enviada");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return sent;
	}
	
	public void closeStreams() {
		try {
			oos.close();
			ois.close();
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Cierra la conexion
	 */
	public void closeConnection() {
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

