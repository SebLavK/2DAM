package e04;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
*@author Sebas Lavigne
*
*/

public class Client {
	
	public static final int PORT = 8000;
	public static final String ADDRESS = "localhost";
	
	
	private Socket client;
	private DataInputStream is = null;
	private DataOutputStream os = null;
	private String serverMsg;
	
	public static void main(String[] args) {
		Client client = new Client();
		client.setConnection();
		client.getServerMsg();
		client.transformMsg();
		client.setServerMsg();
		client.closeSocketStreams();
	}
	
	/**
	 * Transforma el mensaje a mayusculas
	 */
	public void transformMsg() {
		serverMsg = serverMsg.toUpperCase();
	}
	
	/**
	 * Establece conexion con el servidor
	 */
	public void setConnection() {
		try {
			client = new Socket(ADDRESS, PORT);
			System.out.println("Socket cliente iniciado...");
		} catch (IOException e) {
			System.out.println("Error al establecer conexion con el servidor:\n"+e.getMessage());
		}
	}
	
	/**
	 * Recibe un mensaje del servidor
	 */
	public void getServerMsg() {
		try {
			is = new DataInputStream(client.getInputStream());
			serverMsg = is.readUTF();
			System.out.println("Servidor: "+serverMsg);
		} catch (IOException e) {
			System.out.println("Error al leer del servidor:\n"+e.getMessage());
		}
	}
	
	/**
	 * Envia un mensaje al servidor
	 */
	public void setServerMsg() {
		try {
			os = new DataOutputStream(client.getOutputStream());
			os.writeUTF(serverMsg);
			System.out.println("Cliente: "+serverMsg);
		} catch (IOException e) {
			System.out.println("Error al escribir al servidor:\n"+e.getMessage());
		}
	}
	
	/**
	 * Cierra los flujos de entrada y salida y el socket cliente
	 */
	public void closeSocketStreams() {
		try {
			is.close();
			os.close();
			client.close();
		} catch (IOException e) {
			System.out.println("Error al cerrar flujos:\n"+e.getMessage());
		}
	}

}

