package e08;

import java.util.Scanner;

/**
*@author Sebas Lavigne
*
*/

public class Utils {
	
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}

}

