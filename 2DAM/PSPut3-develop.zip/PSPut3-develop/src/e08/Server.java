package e08;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
*@author Sebas Lavigne
*
*/

public class Server {
	
	public static final int PORT = 8000;
	
	private Socket socket;
	private ServerSocket serverSocket;
	private DataInputStream is = null;
	private DataOutputStream os = null;
	
	public static void main(String[] args) {
		Server server = new Server();
		server.setConnection();
		server.connectionInteraction();
		server.closeConnection();
	}
	
	public void setConnection() {
		try {
			serverSocket = new ServerSocket(PORT);
			System.out.println("Servidor a la escucha en el puerto " + serverSocket.getLocalPort() + "...");
			
			socket = serverSocket.accept();
			System.out.println("Conexion establecida con: "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void closeConnection() {
		try {
			is.close();
			os.close();
			socket.close();
			serverSocket.close();
			System.out.println("Conexion terminada");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void connectionInteraction() {
		String msg;
		try {
			is = new DataInputStream(socket.getInputStream());
			os = new DataOutputStream(socket.getOutputStream());
			
			while(true) {
				//Escribe desde el servidor
				System.out.print("Servidor: ");
				msg = Utils.inputString();
				os.writeUTF(msg);
				//Lee desde el servidor
				System.out.print("Cliente: ");
				msg = is.readUTF();
				System.out.println(msg);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

