package e08;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

/**
*@author Sebas Lavigne
*
*/

public class Client {
	
	public static final int PORT = 8000;
	public static final String ADDRESS = "localhost";
	
	private Socket socket;
	private DataInputStream is = null;
	private DataOutputStream os = null;
	
	public static void main(String[] args) {
		Client client = new Client();
		client.setConnection();
		client.connectionInteraction();
		client.closeConnection();
	}
	
	public void setConnection() {
		try {
			socket = new Socket(ADDRESS, PORT);
			System.out.println("Socket iniciado en "
			+ socket.getInetAddress().getHostAddress() + ":" + socket.getLocalPort());
			System.out.println("Conexion establecida con: "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void closeConnection() {
		try {
			is.close();
			os.close();
			socket.close();
			System.out.println("Conexion terminada");
		} catch (IOException e) {
			e.printStackTrace();
		};
	}
	
	public void connectionInteraction() {
		String msg;
		try {
			is = new DataInputStream(socket.getInputStream());
			os = new DataOutputStream(socket.getOutputStream());
			
			while(true) {
				//Lee desde el cliente
				System.out.print("Servidor: ");
				msg = is.readUTF();
				System.out.println(msg);
				//Escribe desde el cliente
				System.out.print("Cliente: ");
				msg = Utils.inputString();
				os.writeUTF(msg);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

