package e12;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

/**
*@author Sebas Lavigne
*
*/

public class Monitor extends Thread {
	
	private Socket socket;
	private ObjectInputStream ois;
	private DataOutputStream os;
	
	public Monitor(Socket socket) {
		this.socket = socket;
	}
	
	/**
	 * Espera recibir un objeto Vitals de un cliente, analiza sus valores
	 * y envia una alerta al cliente si es necesario
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	private void checkVitals() throws ClassNotFoundException, IOException {
		Vitals vitals = (Vitals) ois.readObject();
		System.out.println("Vitales recibidas de "
				+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		int code = vitals.getAlertCode();
		if (code != 0) {
			os.writeUTF(vitals.generateAlertMessage(code));
			System.out.println("\tAlerta enviada");
		} else {
			System.out.println("\tNo hay alertas");
		}
	}

	@Override
	public void run() {
		try {
			ois = new ObjectInputStream(socket.getInputStream());
			os = new DataOutputStream(socket.getOutputStream());
			while (true) checkVitals();
		} catch (IOException e) {
//			e.printStackTrace();
			System.out.println("XXX Cliente "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort()
					+ " ha cerrado la conexion");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

	
}

