package e12;

import java.io.Serializable;
import java.util.Random;

/**
*@author Sebas Lavigne
*
*/

public class Vitals implements Serializable {

	private static final long serialVersionUID = 8088269543652790719L;
	
	private static final int MIN_TEMPERATURE = 37;
	private static final int MAX_TEMPERATURE = 42;
	
	private static final int MIN_HEART_RATE = 60;
	private static final int MAX_HEART_RATE = 100;
	
	private static final int MIN_PRESSURE_SYSTOLIC = 120;
	private static final int MAX_PRESSURE_SYSTOLIC = 140;
	
	private static final int MIN_PRESSURE_DIASTOLIC = 70;
	private static final int MAX_PRESSURE_DIASTOLIC = 90;
	
	private static final int CODE_TEMPERATURE = 		0b0001;
	private static final int CODE_HEART_RATE = 			0b0010;
	private static final int CODE_PRESSURE_SYSTOLIC = 	0b0100;
	private static final int CODE_PRESSURE_DIASTOLIC = 	0b1000;
	
	private int temperature;
	private int heartRate;
	private int pressureSystolic;
	private int pressureDiastolic;
	
	public Vitals() {
		
	}
	
	/**
	 * Aleatoriza los valores de las constantes vitales
	 */
	public void randomize() {
		Random rd = new Random();
		temperature = rd.nextInt(MAX_TEMPERATURE + 4 - MIN_TEMPERATURE) + MIN_TEMPERATURE;
		heartRate = rd.nextInt(MAX_HEART_RATE + 40 - MIN_HEART_RATE) + MIN_HEART_RATE;
		pressureSystolic = rd.nextInt(MAX_PRESSURE_SYSTOLIC + 5 - MIN_PRESSURE_SYSTOLIC) + MIN_PRESSURE_SYSTOLIC;
		pressureDiastolic = rd.nextInt(MAX_PRESSURE_DIASTOLIC + 5 - MIN_PRESSURE_DIASTOLIC) + MIN_PRESSURE_DIASTOLIC;
	}
	
	/**
	 * Devuelve un codigo de alerta de que constantes vitales estan en peligro
	 * @return
	 */
	public int getAlertCode() {
		int code = 0;
		code += (temperature >= MAX_TEMPERATURE) ? 				CODE_TEMPERATURE : 0;
		code += (heartRate >= MAX_HEART_RATE) ? 				CODE_HEART_RATE : 0;
		code += (pressureSystolic >= MAX_PRESSURE_SYSTOLIC) ? 	CODE_PRESSURE_SYSTOLIC : 0;
		code += (pressureDiastolic >= MAX_PRESSURE_DIASTOLIC) ? CODE_PRESSURE_DIASTOLIC : 0;
		return code;
	}
	
	/**
	 * Genera un mensaje de alerta en funcion del codigo de alerta
	 * @param code
	 * @return
	 */
	public String generateAlertMessage(int code) {
		String msg = "\n***\nPELIGRO\n***\nLos siguientes valores son muy altos:";
		
		msg += ((code & CODE_TEMPERATURE) == CODE_TEMPERATURE) ?
				"\nTemperatura: " + temperature : "";
		msg += ((code & CODE_HEART_RATE) == CODE_HEART_RATE) ?
				"\nRitmo cardiaco: " + heartRate : "";
		msg += ((code & CODE_PRESSURE_SYSTOLIC) == CODE_PRESSURE_SYSTOLIC) ?
				"\nPresion sistolica: " + pressureSystolic : "";
		msg += ((code & CODE_PRESSURE_DIASTOLIC) == CODE_PRESSURE_DIASTOLIC) ?
				"\nPresion diastolica: " + pressureDiastolic : "";
		
		return msg;
		
	}

}

