package e12;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

/**
*@author Sebas Lavigne
*
*/

public class Client {
	
	public static final String ADDRESS = "localhost";
	public static final int PORT = 8000;
	
	private Socket socket;
	private ObjectOutputStream oos;
	
	/**
	 * Crea un objeto cliente, lo conecta con el monitor, lanza un Display y
	 * envia constantes vitales al monitor
	 * @param args
	 */
	public static void main(String[] args) {
		Client client = new Client();
		client.setConnection();
		client.launchDisplay();
		try {
			client.sendVitals();
		} catch (IOException e) {
			e.printStackTrace();
		}
		client.closeConnection();
	}
	
	/**
	 * Establece conexion con el servidor
	 */
	public void setConnection() {
		try {
			socket = new Socket(ADDRESS, PORT);
			System.out.println("Socket iniciado en "
			+ socket.getInetAddress().getHostAddress() + ":" + socket.getLocalPort());
			System.out.println("Conexion establecida con: "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Lanza un ClientDisplay para escuchar las posibles alertas del monitor
	 */
	public void launchDisplay() {
		new ClientDisplay(socket).start();
		System.out.println("Display a la escucha del servidor");
	}
	
	/**
	 * Cada 10 segundos genera constantes vitales aleatorias y las envia al servidor
	 * @throws IOException
	 */
	public void sendVitals() throws IOException {
		oos = new ObjectOutputStream(socket.getOutputStream());
		while (true) {
			Vitals vitals = new Vitals();
			vitals.randomize();
			oos.writeObject(vitals);
			oos.flush();
			oos.reset();
			
			System.out.println("Constantes vitales enviadas");
			
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Cierra la conexion
	 */
	public void closeConnection() {
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

