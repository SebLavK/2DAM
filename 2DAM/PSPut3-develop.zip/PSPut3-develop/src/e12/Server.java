package e12;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author Sebas Lavigne
 *
 */

public class Server {
	
	public static final int PORT = 8000;

	private ServerSocket serverSocket;

	/**
	 * Crea un objeto servidor y lo pone a disposicion de los clientes
	 * @param args
	 */
	public static void main(String[] args) {
		Server server = new Server();
		server.startServer();
		
		try {
			while (true) server.launchMonitor();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		server.closeConnection();
	}

	/**
	 * Inicia el ServerSocket del servidor
	 */
	public void startServer() {
		try {
			serverSocket = new ServerSocket(PORT);
			System.out.println("Servidor a la escucha en el puerto "
					+ serverSocket.getLocalPort() + "...");
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Espera una conexion entrante desde un cliente y lanza un monitor para
	 * atenderla
	 * @throws IOException
	 */
	public void launchMonitor() throws IOException {
		System.out.println("Servidor esperando conexion...");
		Socket socket = serverSocket.accept();
		System.out.println("Conexion establecida con: "
				+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		new Monitor(socket).start();
	}

	/**
	 * Cierra la conexion
	 */
	public void closeConnection() {
		try {
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
