package e12;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

/**
*@author Sebas Lavigne
*
*/

public class ClientDisplay extends Thread {
	
	private Socket socket;
	private DataInputStream is;
	
	public ClientDisplay(Socket socket) {
		this.socket = socket;
	}
	
	/**
	 * Muestra por pantalla cualquier mensaje del monitor
	 * @throws IOException
	 */
	public void displayTextFromMonitor() throws IOException {
		System.out.println(is.readUTF());
	}
	
	@Override
	public void run() {
		try {
			is = new DataInputStream(socket.getInputStream());
			while (true) displayTextFromMonitor();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	

}

