package e15;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}

	public static void main(String[] args) {
		System.out.println("===\nNAVEGADOR WEB \n===");
		System.out.println("Introduce la direccion a visitar");
		try {
			URL url = new URL(inputString());
			
			showTitleFromURL(url);
		} catch (MalformedURLException e) {
//			e.printStackTrace();
			System.out.println("Error: URL mal formada\n"+e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Obtiene la URL de una pagina web y busca su titulo
	 * @param url
	 * @throws IOException
	 */
	public static void showTitleFromURL(URL url) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
		
		String line;
		boolean done = false;
		while ((line = br.readLine()) != null && !done) {
			//Este patron regex busca el contenido de la etiqueta <title>
			//teniendo en cuenta las posibles etiquetas que pueda contener
			Pattern pattern = Pattern.compile(".*<title[\\w\\s-\"=]*>(.*)<\\/title>.*");
			Matcher matcher = pattern.matcher(line);
			if (matcher.matches()) {
				String title = matcher.group(1);
				System.out.println("===TITULO===");
				System.out.println(title);
				done = true;
			}
		}
	}
}

