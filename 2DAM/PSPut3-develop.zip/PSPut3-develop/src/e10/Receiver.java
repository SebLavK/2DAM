package e10;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * Un objeto receiver lee constantemente del flujo de entrada de un socket
*@author Sebas Lavigne
*
*/
public class Receiver extends Thread {
	
	private Socket socket;
	private DataInputStream is;
	
	/**
	 * Constructor
	 * @param socket el socket de la conexion
	 */
	public Receiver(Socket socket) {
		this.socket = socket;
		is = null;
	}
	
	/**
	 * Inicializa el flujo de entrada
	 * @throws IOException
	 */
	private void initializeStream() throws IOException {
		is = new DataInputStream(socket.getInputStream());
	}
	
	/**
	 * Muestra por pantalla el mensaje recibido
	 * @throws IOException
	 */
	private void receiveMsg() throws IOException {
		System.out.println(socket.getInetAddress().getHostName() + ":" + socket.getPort()
		+ " -> " + is.readUTF());
	}
	
	/**
	 * Cierra el flujo
	 * @throws IOException
	 */
	private void closeStream() throws IOException {
		is.close();
	}

	@Override
	public void run() {
		try {
			initializeStream();
			while(true) {
				receiveMsg();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				closeStream();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

