package e10;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

/**
 * Un objeto sender envia mensajes constantemente por el flujo de salida de un socket
*@author Sebas Lavigne
*
*/
public class Sender extends Thread {
	
	private Socket socket;
	private DataOutputStream os;
	
	/**
	 * Constructor
	 * @param socket el socket de la conexion
	 */
	public Sender(Socket socket) {
		this.socket = socket;
		os = null;
	}
	
	/**
	 * 
	 * @return una cadena introducida por teclado
	 */
	private String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	/**
	 * Inicializa el flujo de salida
	 * @throws IOException
	 */
	private void initializeStream() throws IOException {
		os = new DataOutputStream(socket.getOutputStream());
	}
	
	/**
	 * Envia un mensaje por el flujo de salida
	 * @throws IOException
	 */
	private void sendMsg() throws IOException {
		os.writeUTF(inputString());
	}
	
	/**
	 * Cierra el flujo
	 * @throws IOException
	 */
	private void closeStream() throws IOException {
		os.close();
	}

	@Override
	public void run() {
		try {
			initializeStream();
			while(true) {
				sendMsg();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				closeStream();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

