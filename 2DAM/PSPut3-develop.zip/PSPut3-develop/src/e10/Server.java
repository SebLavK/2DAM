package e10;

import java.io.IOException;
import java.net.ServerSocket;

import java.net.Socket;

/**
*@author Sebas Lavigne
*
*/

public class Server {
	
	public static final int PORT = 8000;

	private Socket socket;
	private ServerSocket serverSocket;
	private Sender sender;
	private Receiver receiver;
	
	public static void main(String[] args) {
		Server server = new Server();
		server.setConnection();
		server.launchThreads();
		server.waitForCompletion();
		server.closeConnection();
	}
	
	/**
	 * Establece conexion con un cliente
	 */
	public void setConnection() {
		try {
			serverSocket = new ServerSocket(PORT);
			System.out.println("Servidor a la escucha en el puerto " + serverSocket.getLocalPort() + "...");
			
			socket = serverSocket.accept();
			System.out.println("Conexion establecida con: "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Lanza los hilos para enviar y recibir mensajes
	 */
	public void launchThreads() {
		sender = new Sender(socket);
		receiver = new Receiver(socket);
		sender.start();
		receiver.start();
	}
	
	/**
	 * Espera a que los hilos terminen
	 */
	public void waitForCompletion() {
		try {
			sender.join();
			receiver.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Cierra la conexion
	 */
	public void closeConnection() {
		try {
			socket.close();
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

