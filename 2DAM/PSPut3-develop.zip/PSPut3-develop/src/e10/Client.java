package e10;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

/**
*@author Sebas Lavigne
*
*/

public class Client {
	
	public static final String ADDRESS = "localhost";
	public static final int PORT = 8000;
	
	private Socket socket;
	private Sender sender;
	private Receiver receiver;
	
	public static void main(String[] args) {
		Client client = new Client();
		client.setConnection();
		client.launchThreads();
		client.waitForCompletion();
		client.closeConnection();
	}
	
	/**
	 * Establece conexion con el servidor
	 */
	public void setConnection() {
		try {
			socket = new Socket(ADDRESS, PORT);
			System.out.println("Socket iniciado en "
			+ socket.getInetAddress().getHostAddress() + ":" + socket.getLocalPort());
			System.out.println("Conexion establecida con: "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Lanza los hilos para enviar y recibir mensajes
	 */
	public void launchThreads() {
		sender = new Sender(socket);
		receiver = new Receiver(socket);
		sender.start();
		receiver.start();
	}
	
	/**
	 * Espera a que los hilos terminen
	 */
	public void waitForCompletion() {
		try {
			sender.join();
			receiver.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Cierra la conexion
	 */
	public void closeConnection() {
		try {
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

