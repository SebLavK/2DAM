package e14;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	public static void main(String[] args) {
		System.out.println("Elige una opcion:\n1 - URL completa\n2 - URL Por partes");
		switch (inputString()) {
		case "1":
			System.out.println("Introduce una direccion URL completa para analizar");
			try {
				URL url = new URL(inputString());
				
				showURLInfo(url);
			} catch (MalformedURLException e) {
				//e.printStackTrace();
				System.out.println("Error: URL mal formada\n"+e.getMessage());
			}
			break;
		case "2":
			System.out.println("Introduce el protocolo:");
			String protocol = inputString();
			System.out.println("Introduce el host:");
			String host = inputString();
			System.out.println("Introduce el puerto:");
			String port = inputString();
			System.out.println("Introduce el fichero:");
			String file = inputString();
			
			try {
				URL url = new URL(protocol, host, Integer.parseInt(port), file);
				
				showURLInfo(url);
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (MalformedURLException e) {
//				e.printStackTrace();
				System.out.println("Error: URL mal formada\n"+e.getMessage());
			}
			break;
		default:
			System.out.println("No existe esa opcion");
			break;
		}
	}

	/**
	 * Muestra la informacion de cada parte de una URL que recibe por parametro
	 * @param url
	 */
	public static void showURLInfo(URL url) {
		System.out.println("===\nDATOS DE LA URL\n===");
		System.out.println("URL:\n\t" + url);
		System.out.println("Protocolo:\n\t" + url.getProtocol());
		System.out.println("Nombre de la maquina:\n\t" + url.getHost());
		System.out.println("Puerto:\n\t" + url.getPort());
		System.out.println("Fichero:\n\t" + url.getFile());
		System.out.println("Informacion del usuario:\n\t" + url.getUserInfo());
		System.out.println("Path:\n\t" + url.getPath());
		System.out.println("Autoridad:\n\t" + url.getAuthority());
		System.out.println("Query:\n\t" + url.getQuery());
	}
}

