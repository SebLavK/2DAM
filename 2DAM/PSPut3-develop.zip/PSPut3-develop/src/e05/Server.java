package e05;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
*@author Sebas Lavigne
*
*/

public class Server {
	
	public static final int PORT = 8000;
	
	private Socket socket;
	private ServerSocket serverSocket;
	private DataInputStream is = null;
	private DataOutputStream os = null;
	
	/**
	 * Crea un servidor, establece la conexion, interactua con el cliente y cierra conexion
	 * @param args
	 */
	public static void main(String[] args) {
		Server server = new Server();
		server.setConnection();
		server.socketInteraction();
		server.closeSocketStreams();
	}
	
	/**
	 * Inicia un ServerSocket en el puerto designado y establece conexion con un cliente
	 * mediante un Socket
	 */
	public void setConnection() {
		try {
			serverSocket = new ServerSocket(PORT);
			System.out.println("Servidor a la escucha en el puerto " + PORT + "...");
			
			socket = serverSocket.accept();
			System.out.println("Conexion establecida con: "
			+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Interactua con un cliente mediante el Socket
	 */
	public void socketInteraction() {
		String msg;
		try {
			is = new DataInputStream(socket.getInputStream());
			os = new DataOutputStream(socket.getOutputStream());
			
			//PIM
			dramaPause();
			System.out.println("Cliente: " + readFromClient(is));
			
			//PAM
			dramaPause();
			msg = "PAM";
			writeToClient(os, msg);
			System.out.println("Servidor: " + msg);
			
			//PUM
			dramaPause();
			System.out.println("Cliente: " + readFromClient(is));
			
			//FUEGO
			dramaPause();
			msg = "FUEGO";
			writeToClient(os, msg);
			System.out.println("Servidor: " + msg);
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Lee un String recibido a traves del Socket
	 * @param is el flujo de entrada
	 * @return el mensaje recibido por el flujo
	 * @throws IOException
	 */
	public String readFromClient(DataInputStream is) throws IOException {
		return is.readUTF();
	}
	
	/**
	 * Envia un String a traves del Socket
	 * @param os el flujo de salida
	 * @param msg el mensaje a enviar por el flujo
	 * @throws IOException
	 */
	public void writeToClient(DataOutputStream os, String msg) throws IOException {
		os.writeUTF(msg);
	}
	
	/**
	 * Espera tres segundos para generar drama
	 */
	public void dramaPause() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Cierra los flujos del socket, cierra el Socket y el ServerSocket
	 */
	public void closeSocketStreams() {
		try {
			is.close();
			os.close();
			socket.close();
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

}

