package e06;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


/**
*@author Sebas Lavigne
*
*/

public class Server {
	
public static final int PORT = 8000;
	
	private Socket socket;
	private ServerSocket serverSocket;
	private DataInputStream is = null;
	private DataOutputStream os = null;
	
	/**
	 * Crea un servidor, establece la conexion, interactua con el cliente y cierra conexion
	 * @param args
	 */
	public static void main(String[] args) {
		Server server = new Server();
		server.setConnection();
		server.socketInteraction();
		server.closeSocketStreams();
	}

	/**
	 * Inicia un ServerSocket en el puerto designado y establece conexion con un cliente
	 * mediante un Socket
	 */
	public void setConnection() {
		try {
			serverSocket = new ServerSocket(PORT);
			System.out.println("Servidor a la escucha en el puerto " + PORT + "...");
			
			socket = serverSocket.accept();
			System.out.println("Conexion establecida con: "
			+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Cierra los flujos del socket, cierra el Socket y el ServerSocket
	 */
	public void closeSocketStreams() {
		try {
			is.close();
			os.close();
			socket.close();
			serverSocket.close();
			System.out.println("Conexion terminada");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Invierte el orden de las letras del String que recibe por parametro
	 * @param msg el mensaje a transponer
	 * @return el mensaje transpuesto
	 */
	public String transposeString(String msg) {
		String msgInverted = "";
		System.out.println("Transponiendo mensaje...");
		for (int i = 0; i < msg.length(); i++) {
			msgInverted += msg.charAt(msg.length() - i -1);
		}
		System.out.println(msg + " -> " + msgInverted);
		return msgInverted;
	}
	
	/**
	 * Recibe un mensaje del cliente y lo devuelve simulando un eco
	 * No termina nunca
	 */
	public void socketInteraction() {
		String msg;
		
		try {
			is = new DataInputStream(socket.getInputStream());
			os = new DataOutputStream(socket.getOutputStream());
			
			while (true) {
				msg = is.readUTF();
				System.out.println("Cliente: " + msg);
				msg = transposeString(msg);
				msg = msg.toUpperCase() + " ... " + msg.toUpperCase() + " ... " + msg.toLowerCase() + " ...";
				os.writeUTF(msg);
				System.out.println("Servidor responde con eco:\n" + msg);
				
				System.out.println();
			}
			
		} catch (IOException e) {
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

}

