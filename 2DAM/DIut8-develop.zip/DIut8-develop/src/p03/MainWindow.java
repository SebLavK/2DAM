package p03;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {
	
	public static final int ICON_SIZE = 24;
	
	private JFrame window;
	
	private JPanel pLeft;
	private JLabel lImage;
	private BufferedImage currentImage;
	
	private JPanel pRight;
	private JPanel pColors;
	private JButton bLoad;
	private JButton bNew;
	
	private JRadioButton[] bColors;
	private static final String[] COLOR_NAMES = {"Negro", "Azul", "Blanco", "Verde"};
	private static final Color[] COLOR_COLORS = {Color.BLACK, Color.BLUE, Color.WHITE, Color.GREEN};
	
	private JRadioButton rbBlack;
	private JRadioButton rbBlue;
	private JRadioButton rbWhite;
	private JRadioButton rbGreen;
	
	private ButtonGroup bgColors;
	
	public MainWindow() {
		window = new JFrame("Parte 3");
		window.setBounds(100, 100, 1000, 700);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		window.setLayout(new GridBagLayout());
		GridBagConstraints settings;
		
		/*
		 * Panel izquierdo
		 */
		pLeft = new JPanel(new GridBagLayout());
		pLeft.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createEmptyBorder(40, 40, 40, 40),
				BorderFactory.createLineBorder(Color.BLACK)
				));
		settings = new GridBagConstraints();
		settings.weightx = 1;
		settings.weighty = 1;
		settings.fill = GridBagConstraints.BOTH;
		window.add(pLeft, settings);
		
		/*
		 * JLabel del panel izquierdo
		 */
		lImage = new JLabel();
		lImage.setHorizontalAlignment(SwingConstants.CENTER);
		settings = new GridBagConstraints();
		settings.weightx = 1;
		settings.weighty = 1;
		settings.fill = GridBagConstraints.BOTH;
		pLeft.add(lImage, settings);
		
		/*
		 * Panel derecho
		 */
		pRight = new JPanel(new GridBagLayout());
		settings = new GridBagConstraints();
		settings.gridx = 1;
		settings.anchor = GridBagConstraints.EAST;
		settings.weighty = 1;
		settings.insets = new Insets(0, 0, 0, 40);
		settings.fill = GridBagConstraints.VERTICAL;
		window.add(pRight, settings);
		
		/*
		 * Componentes panel derecho
		 */
		bLoad = new JButton("Cargar");
		
		try {
			Image iconLoad = ImageIO.read(getClass().getResource("/img/load.png"))
					.getScaledInstance(ICON_SIZE, ICON_SIZE, Image.SCALE_SMOOTH);
			bLoad.setIcon(new ImageIcon(iconLoad));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		settings = new GridBagConstraints();
		settings.gridx = 0;
		settings.weightx = 1;
		settings.insets = new Insets(0, 8, 0, 4);
		settings.fill = GridBagConstraints.BOTH;
		pRight.add(bLoad, settings);
		
		bNew = new JButton("Nuevo");
		
		try {
			Image iconNew = ImageIO.read(getClass().getResource("/img/new.png"))
					.getScaledInstance(ICON_SIZE, ICON_SIZE, Image.SCALE_SMOOTH);
			bNew.setIcon(new ImageIcon(iconNew));
			bNew.setHorizontalTextPosition(SwingConstants.LEFT);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		settings = new GridBagConstraints();
		settings.gridx = 1;
		settings.weightx = 1;
		settings.insets = new Insets(0, 4, 0, 8);
		settings.fill = GridBagConstraints.BOTH;
		pRight.add(bNew, settings);
		
		pColors = new JPanel(new GridLayout(4, 1));
		pColors.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createLineBorder(Color.BLUE),
				"Colores",
				TitledBorder.CENTER,
				TitledBorder.ABOVE_TOP
				));
		settings = new GridBagConstraints();
		settings.gridy = 1;
		settings.gridwidth = 2;
		settings.insets = new Insets(80, 8, 20, 8);
		settings.ipadx = 200;
		settings.ipady = 100;
		settings.fill = GridBagConstraints.BOTH;
		pRight.add(pColors, settings);
		
		/*
		 * Botones de colores
		 */
		bColors = new JRadioButton[COLOR_NAMES.length];
		bgColors = new ButtonGroup();
		
		for (int i = 0; i < bColors.length; i++) {
			bColors[i] = new JRadioButton(COLOR_NAMES[i]);
			bgColors.add(bColors[i]);
			pColors.add(bColors[i]);
		}
	}
	
	public void initializeListeners() {
		/*
		 * Boton cargar
		 */
		bLoad.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					currentImage = ImageIO.read(chooseImageFile());
					setLabelImage();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}

			
		});
		
		/*
		 * Boton nuevo
		 */
		bNew.addActionListener(e -> colorizeLeftPanel());
		
		/*
		 * Ajuste de tamano de la imagen
		 */
		lImage.addComponentListener(new ComponentAdapter() {

			@Override
			public void componentResized(ComponentEvent e) {
				try {
					setLabelImage();
				} catch (NullPointerException | IllegalArgumentException e2) {
					//Do nothing
				}
			}
			
		});
	}
	
	public void setLabelImage() {
		Image img = currentImage
				.getScaledInstance(lImage.getWidth(), lImage.getHeight(), Image.SCALE_SMOOTH);
		lImage.setIcon(new ImageIcon(img));
	}
	
	private File chooseImageFile() {
		File imageFile = null;
		JFileChooser fc = new JFileChooser();
		fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
		fc.setDialogTitle("Elige una imagen");
		
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Imagenes",
				"jpg",
				"bmp",
				"jpeg",
				"wbmp",
				"png",
				"gif"
				);
		
		fc.setFileFilter(filter);
		
		int option = fc.showOpenDialog(window);
		
		if (option == JFileChooser.APPROVE_OPTION) {
			imageFile = fc.getSelectedFile();
		}
		
		return imageFile;
	}
	
	private Color getSelectedColor() {
		Color color = Color.WHITE;
		for (int i = 0; i < bColors.length; i++) {
			if (bColors[i].isSelected()) {
				color = COLOR_COLORS[i];
			}
		}
		return color;
	}
	
	private void colorizeLeftPanel() {
		BufferedImage img = new BufferedImage(lImage.getWidth(), lImage.getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics graphics = img.getGraphics();
		
		graphics.setColor(getSelectedColor());
		graphics.fillRect(0, 0, img.getWidth(), img.getHeight());
		graphics.dispose();
		
		lImage.setIcon(new ImageIcon(img));
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}
	
}

