package p02;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow extends MouseAdapter {

	public static final int ICON_SIZE = 100;
	public static final String[] IMG_PATHS = {
			"/img/bb.png",
			"/img/dexter.png",
			"/img/house.png",
			"/img/lost.png"
	};
	
	private JFrame window;
	private JLabel[] lIcons;
	private JLabel lImage;
	private JPanel pLeft;
	private JPanel pRight;
	
	public MainWindow() {
		window = new JFrame("Parte 2");
		window.setBounds(100, 100, 700, 700);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		window.setLayout(new GridBagLayout());
		GridBagConstraints settings;
		pLeft = new JPanel();
		pRight = new JPanel();

		/*
		 * PANEL IZQUIERDA
		 */
		pLeft.setBackground(Color.GREEN);
		pLeft.setLayout(new GridLayout(4, 1));
		Image[] images = new Image[IMG_PATHS.length];
		lIcons = new JLabel[images.length];
		for (int i = 0; i < images.length; i++) {
			try {
				//Carga las imagenes y las redimensiona
				images[i] = ImageIO.read(getClass().getResource(IMG_PATHS[i]))
						.getScaledInstance(ICON_SIZE, ICON_SIZE, Image.SCALE_SMOOTH);
				//Anade las imagenes a los JLabel y anade al JFrame
				lIcons[i] = new JLabel(new ImageIcon(images[i]));
				lIcons[i].setName(Integer.toString(i));
				pLeft.add(lIcons[i]);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		settings = new GridBagConstraints();
		settings.fill = GridBagConstraints.VERTICAL;
		settings.anchor = GridBagConstraints.WEST;
		settings.ipadx = 100;
		settings.weighty = 1;
		window.add(pLeft, settings);
		
		/*
		 * PANEL DERECHA
		 */
		
		pRight.setLayout(new GridLayout(1, 1));
		
			lImage = new JLabel();
			lImage.setHorizontalAlignment(SwingConstants.CENTER);
			pRight.add(lImage);
		
		pRight.setBackground(Color.BLUE);
		settings = new GridBagConstraints();
		settings.gridx = 1;
		settings.fill = GridBagConstraints.BOTH;
		settings.weighty = 1;
		settings.weightx = 1;
		window.add(pRight, settings);
	}
	
	public void initializeListeners()  {
		for (int i = 0; i < lIcons.length; i++) {
			lIcons[i].addMouseListener(this);
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		JLabel clickedLabel = (JLabel) e.getSource();
		try {
			Image img = ImageIO.read(getClass().getResource(
					IMG_PATHS[Integer.parseInt(clickedLabel.getName())]
					));
			img = img.getScaledInstance(img.getWidth(null)/2, img.getHeight(null)/2, Image.SCALE_SMOOTH);
			lImage.setIcon(new ImageIcon(img));
		} catch (NumberFormatException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}
}

