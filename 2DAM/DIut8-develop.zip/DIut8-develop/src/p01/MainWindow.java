package p01;

import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {

	private JFrame window;
	private JLabel lImage;
	
	public MainWindow() {
		window = new JFrame("Parte 1");
		window.setBounds(100, 100, 700, 700);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		window.setLayout(null);
		Image img = null;
		try {
			img = ImageIO.read(Main.class.getResource("/img/bb.png"));
			img = img.getScaledInstance(img.getWidth(null)/2, img.getHeight(null)/2, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			e.printStackTrace();
		}
		lImage = new JLabel(new ImageIcon(img));
		lImage.setBounds(0, 0, img.getWidth(null), img.getHeight(null));
		window.add(lImage);
	}
	
	public void initializeListeners() {
		
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}
}

