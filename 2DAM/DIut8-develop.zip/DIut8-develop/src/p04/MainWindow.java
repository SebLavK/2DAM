package p04;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {

	private JFrame window;
	
	private JPanel pControls;
	private JPanel pImage;
	private JPanel pExtra;
	
	private JButton bSquare;
	private JButton bCircle;
	private JSeparator separator;
	private JLabel lPosX;
	private JLabel lPosY;
	private JTextField tfPosX;
	private JTextField tfPosY;
	
	private JLabel lienzo;
	private BufferedImage canvas;
	private Graphics graficos;
	
	private JButton bColor;
	private JLabel lSize;
	private JTextField tfSize;
	private Color currentColor;
	
	public MainWindow() {
		window = new JFrame("Paint");
		window.setBounds(100, 100, 800, 600);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public void initializeComponents() {
		window.setLayout(new GridBagLayout());
		GridBagConstraints settings;
		
		/*
		 * Panel izquierdo
		 */
		pControls = new JPanel(new GridBagLayout());
		settings = new GridBagConstraints();
		settings.anchor = GridBagConstraints.WEST;
		settings.fill = GridBagConstraints.BOTH;
		settings.insets = new Insets(0, 20, 0, 20);
		settings.weighty = 1;
		
		window.add(pControls, settings);
		
		Insets controlInsets = new Insets(10, 0, 10, 0);
		
			/*
			 * Componentes panel izquierdo
			 */
			bSquare = new JButton();
			bSquare.setActionCommand("square");
			try {
				bSquare.setIcon(new ImageIcon(
						ImageIO.read(getClass().getResource("/img/square.png"))
						.getScaledInstance(40, 40, Image.SCALE_SMOOTH)
						));
			} catch (IOException e) {
				e.printStackTrace();
			}
			settings = new GridBagConstraints();
			settings.insets = controlInsets;
			pControls.add(bSquare, settings);
			
			bCircle = new JButton();
			bCircle.setActionCommand("circle");
			try {
				bCircle.setIcon(new ImageIcon(
						ImageIO.read(getClass().getResource("/img/circle.png"))
						.getScaledInstance(40, 40, Image.SCALE_SMOOTH)
						));
			} catch (IOException e) {
				e.printStackTrace();
			}
			settings = new GridBagConstraints();
			settings.gridy = 1;
			settings.insets = controlInsets;
			pControls.add(bCircle, settings);
			
			separator = new JSeparator();
			settings = new GridBagConstraints();
			settings.gridy = 2;
			settings.fill = GridBagConstraints.BOTH;
			settings.insets = controlInsets;
			pControls.add(separator, settings);
			
			lPosX = new JLabel("Posición X");
			settings = new GridBagConstraints();
			settings.gridy = 3;
			settings.insets = controlInsets;
			pControls.add(lPosX, settings);
			
			tfPosX = new JTextField();
			settings.gridy = 4;
			settings.fill = GridBagConstraints.BOTH;
			settings.insets = controlInsets;
			pControls.add(tfPosX, settings);
			
			lPosY = new JLabel("Posición Y");
			settings = new GridBagConstraints();
			settings.gridy = 5;
			settings.insets = controlInsets;
			pControls.add(lPosY, settings);
			
			tfPosY = new JTextField();
			settings.gridy = 6;
			settings.fill = GridBagConstraints.BOTH;
			settings.insets = controlInsets;
			pControls.add(tfPosY, settings);
			
		/*
		 * Panel derecho
		 */
		pImage = new JPanel(new GridBagLayout());
		settings = new GridBagConstraints();
		settings.gridx = 1;
		settings.fill = GridBagConstraints.BOTH;
		settings.weightx = 1;
		settings.weighty = 1;
		window.add(pImage, settings);
		
			/*
			 * Componenetes del panel derecho
			 */
			lienzo = new JLabel();
			lienzo.setBorder(new LineBorder(Color.BLACK));
			canvas = new BufferedImage(400, 400, BufferedImage.TYPE_INT_ARGB);
			lienzo.setIcon(new ImageIcon(canvas));
			pImage.add(lienzo);
			
			graficos = canvas.getGraphics();
			graficos.setColor(Color.WHITE);
			graficos.fillRect(0, 0, 400, 400);
			graficos.dispose();
			
			lienzo.repaint();
			
		/*
		 * Panel Extra
		 */
		pExtra = new JPanel(new GridBagLayout());
		pExtra.setBorder(new TitledBorder(
				BorderFactory.createEtchedBorder(),
				"Extra"));
		settings = new GridBagConstraints();
		settings.gridx = 2;
		settings.ipadx = 40;
		settings.anchor = GridBagConstraints.EAST;
		settings.weighty = 1;
		settings.fill = GridBagConstraints.BOTH;
		window.add(pExtra, settings);
			
			/*
			 * Componentes panel extra
			 */
			currentColor = Color.BLACK;
			
			bColor = new JButton();
			bColor.setBackground(currentColor);
			bColor.setActionCommand("color");
			settings = new GridBagConstraints();
			settings.insets = controlInsets;
			settings.fill = GridBagConstraints.BOTH;
			settings.ipady = 20;
			pExtra.add(bColor, settings);
			
			JSeparator extraSeparator = new JSeparator();
			settings = new GridBagConstraints();
			settings.gridy = 1;
			settings.insets = controlInsets;
			settings.fill = GridBagConstraints.BOTH;
			pExtra.add(extraSeparator, settings);
			
			lSize = new JLabel("Tamaño:");
			settings = new GridBagConstraints();
			settings.gridy = 2;
			settings.insets = controlInsets;
			pExtra.add(lSize, settings);
			
			tfSize = new JTextField();
			settings = new GridBagConstraints();
			settings.gridy = 3;
			settings.insets = controlInsets;
			settings.fill = GridBagConstraints.BOTH;
			pExtra.add(tfSize, settings);
	}	
	
	public void initializeListeners() {
		bSquare.addActionListener(e -> buttonPressed(e));
		bCircle.addActionListener(e -> buttonPressed(e));
		bColor.addActionListener(e -> buttonPressed(e));
	}
	
	private void buttonPressed(ActionEvent e) {
		switch (((JButton) e.getSource()).getActionCommand()) {
		case "square":
			paintSquare();
			break;
		case "circle":
			paintCircle();
			break;
		case "color":
			chooseColor();
			break;
		}
	}
	
	private int posX() {
		try {
			return Integer.parseInt(tfPosX.getText());
		} catch (NumberFormatException e) {
			return 0;
		}
	}
	
	private int posY() {
		try {
			return Integer.parseInt(tfPosY.getText());
		} catch (NumberFormatException e) {
			return 0;
		}
	}
	
	private int size() {
		try {
			return Integer.parseInt(tfSize.getText());
		} catch (NumberFormatException e) {
			return 0;
		}
	}
	
	private void paintSquare() {
		graficos = canvas.getGraphics();
		graficos.setColor(currentColor);
		graficos.fillRect(posX(), posY(), size(), size());
		graficos.dispose();
		lienzo.repaint();
	}
	
	private void paintCircle() {
		graficos = canvas.getGraphics();
		graficos.setColor(currentColor);
		graficos.fillOval(posX(), posY(), size(), size());
		graficos.dispose();
		lienzo.repaint();
	}
	
	private void chooseColor() {
		Color newColor = JColorChooser.showDialog(window, "Elige un color", currentColor);
		currentColor = (newColor != null? newColor : currentColor);
		bColor.setBackground(currentColor);
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}
}

