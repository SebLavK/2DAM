package main;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {

	private JFrame window;
	
	public MainWindow() {
		window = new JFrame("Prueba tablas");
		window.setBounds(100, 100, 500, 500);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		Object[][] data = {
				{"Seph", "999888777", "Calle Pez", true, 43},
				{"Ridas", "777888999", "Calle Perro", false, 28}
		};
		String[] header = {"Nombre", "Numero", "Calle", "Check", "Numero"};
		JTable table = new JTable(new DefaultTableModel(data, header));
		JScrollPane scroller = new JScrollPane(table);
		window.add(scroller);
	}
	
	public void initializeListeners() {
		
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}
}

