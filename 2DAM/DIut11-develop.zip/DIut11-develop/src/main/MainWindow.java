package main;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {

	private JFrame window;
	private JTable table;
	
	public MainWindow() {
		window = new JFrame("Prueba tablas");
		window.setBounds(100, 100, 500, 500);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		Object[][] data = {
				{"Seph", "Calle Pez", 999888777, true, 43},
				{"Ridas", "Calle Perro", 777888999, false, 28}
		};
		String[] header = {"Nombre", "Numero", "Calle", "Check", "Numero"};
		table = new JTable();
		table.setModel(new MyTableModel());
		JScrollPane scroller = new JScrollPane(table);
		window.add(scroller);
	}
	
	public void initializeListeners() {
		table.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == MouseEvent.BUTTON3) {
					Point point = e.getPoint();
					int row = table.rowAtPoint(point);
					int column = table.columnAtPoint(point);
					table.setRowSelectionInterval(row, row);
					table.setColumnSelectionInterval(column, column);
					JOptionPane.showMessageDialog(window,
							table.getValueAt(row, column)
							);
				}
			}
		});
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}
}

