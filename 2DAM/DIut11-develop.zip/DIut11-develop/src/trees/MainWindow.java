package trees;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {

	private JFrame window;
	private JTree tree;
	
	public MainWindow() {
		window = new JFrame("Prueba tablas");
		window.setBounds(100, 100, 500, 500);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("Phones");
		DefaultTreeModel treeModel = new DefaultTreeModel(root);
		tree = new JTree();
		tree.setModel(treeModel);
		window.add(tree);
		
		DefaultMutableTreeNode category;
		DefaultMutableTreeNode letter;
		DefaultMutableTreeNode name;
		Person person;
		
		category = new DefaultMutableTreeNode("Friends");
		root.add(category);
			letter = new DefaultMutableTreeNode("A");
			category.add(letter);
				person = new Person("Alberto", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
				person = new Person("Alba", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
				person = new Person("All", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
			letter = new DefaultMutableTreeNode("B");
			person = new Person("Bertin", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
				person = new Person("Busquets", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
			category.add(letter);
		category = new DefaultMutableTreeNode("Clients");
		root.add(category);
			letter = new DefaultMutableTreeNode("A");
			category.add(letter);
			person = new Person("Ana", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
				person = new Person("Alcia", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
			letter = new DefaultMutableTreeNode("C");
			category.add(letter);
			person = new Person("Carlos", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
				person = new Person("Celia", "aaa", 34, true, "999");
				name = new DefaultMutableTreeNode(person);
				letter.add(name);
				
	}
	
	public void initializeListeners() {
		tree.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				TreePath selPath = tree.getPathForLocation(e.getX(), e.getY());
				if (e.getButton() == MouseEvent.BUTTON1) {
					if (e.getClickCount() == 3) {
						JOptionPane.showMessageDialog(window,
								selPath.getLastPathComponent() 
								);
					}
				} else if (e.getButton() == MouseEvent.BUTTON3) {
					TreePath path = tree.getPathForLocation(e.getX(), e.getY());
					DefaultMutableTreeNode clickedNode = (DefaultMutableTreeNode) path.getLastPathComponent();
					DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
					model.removeNodeFromParent(clickedNode);
				}
			}
			
		});
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}
}

