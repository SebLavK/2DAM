package trees;

/**
 * @author Sebas Lavigne
 */

public class Person {

	String name;
	String address;
	int age;
	boolean married;
	String phone;

	public Person(String name, String address, int age, boolean married, String phone) {
		super();
		this.name = name;
		this.address = address;
		this.age = age;
		this.married = married;
		this.phone = phone;
	}

	public Person() {
		super();
	}

	@Override
	public String toString() {
		return name;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return the married
	 */
	public boolean isMarried() {
		return married;
	}

	/**
	 * @param married the married to set
	 */
	public void setMarried(boolean married) {
		this.married = married;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	

}
