package e07;

import java.util.ArrayList;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

/**
*@author Sebas Lavigne
*/

public class MyTableModel implements TableModel {
	
	private ArrayList<ArrayList<Object>> tableData;
	private ArrayList<Object> tableHeader;
	
	public MyTableModel(ArrayList<ArrayList<Object>> tableData, ArrayList<Object> tableHeader) {
		this.tableData = tableData;
		this.tableHeader = tableHeader;
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#addTableModelListener(javax.swing.event.TableModelListener)
	 */
	@Override
	public void addTableModelListener(TableModelListener l) {
		//Does nothing
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#getColumnClass(int)
	 */
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		//Todas las columnas se comportan como String
		return String.class;
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#getColumnCount()
	 */
	@Override
	public int getColumnCount() {
		//Si el ArrayList esta inicializado devuelve su tamano
		if (tableHeader != null) {
			return tableHeader.size();
		} else {
			return 0;
		}
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#getColumnName(int)
	 */
	@Override
	public String getColumnName(int columnIndex) {
		//Devuelve el nombre a partir de la lista de la cabecera
		return tableHeader.get(columnIndex).toString();
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#getRowCount()
	 */
	@Override
	public int getRowCount() {
		//Si el ArrayList esta inicializado devuelve su tamano
		if (tableData != null) {
			return tableData.size();
		} else {
			return 0;
		}
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#getValueAt(int, int)
	 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		//Obtiene un dato del ArrayList de datos
		return tableData.get(rowIndex).get(columnIndex).toString();
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#isCellEditable(int, int)
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		//Todas las celdas son editables
		return true;
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#removeTableModelListener(javax.swing.event.TableModelListener)
	 */
	@Override
	public void removeTableModelListener(TableModelListener l) {
		//Does nothing
	}

	/* (non-Javadoc)
	 * @see javax.swing.table.TableModel#setValueAt(java.lang.Object, int, int)
	 */
	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		//Inserta o altera un dato en el ArrayList de datos
		tableData.get(rowIndex).set(columnIndex, aValue);
	}
	
	
}
