package e07;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {

	private JFrame window;
	private JTable table;
	
	private JMenuBar menuBar;
	private JMenu menu;
	private JMenuItem itemLoad;
	private JMenuItem itemQuit;
	
	
	public MainWindow() {
		window = new JFrame("Prueba tablas");
		window.setBounds(100, 100, 500, 500);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	/**
	 * Inicializa los componentes de la ventana
	 */
	public void initializeComponents() {
		table = new JTable(new MyTableModel(null, null));
		JScrollPane scroller = new JScrollPane(table);
		window.add(scroller);
		
	}
	
	/**
	 * Inicializa el menu
	 */
	public void initializeMenu() {
		menuBar = new JMenuBar();
		window.setJMenuBar(menuBar);
		
		menu = new JMenu("File");
		menu.setMnemonic(KeyEvent.VK_F);
		menuBar.add(menu);
		
		itemLoad = new JMenuItem("Load");
		itemLoad.setActionCommand("load");
		itemLoad.setMnemonic(KeyEvent.VK_L);
		itemLoad.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, InputEvent.CTRL_DOWN_MASK));
		
		itemQuit = new JMenuItem("Quit");
		itemQuit.setActionCommand("quit");
		itemQuit.setMnemonic(KeyEvent.VK_Q);
		itemQuit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_DOWN_MASK));
		
		menu.add(itemLoad);
		menu.add(itemQuit);
	}
	
	/**
	 * Inicializa los listeners
	 */
	public void initializeListeners() {
		MenuListener menuListener = new MenuListener();
		itemLoad.addActionListener(menuListener);
		itemQuit.addActionListener(menuListener);
	}
	
	/**
	 * Esta clase es un ActionListener propio para los items del menu
	 */
	private class MenuListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			switch (e.getActionCommand()) {
			case "load":
				loadFile();
				break;
			case "quit":
				window.dispatchEvent(new WindowEvent(window, WindowEvent.WINDOW_CLOSING));
				break;
			}
		}
		
	}
	
	/**
	 * Inicializa la ventana
	 */
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeMenu();
		initializeListeners();
	}
	
	/**
	 * Muestra al usuario un dialogo de seleccion de ficheros
	 * Manda el fichero seleccionado a la tabla
	 * @see #loadDataFromFile(File)
	 */
	public void loadFile() {
		JFileChooser fc = new JFileChooser();
		fc.setFileFilter(new FileFilter() {
			
			@Override
			public String getDescription() {
				return "Archivos CSV (*.csv)";
			}
			
			@Override
			public boolean accept(File f) {
				if (f.isDirectory()) {
					return true;
				} else {
					return f.getName().toLowerCase().endsWith(".csv");
				}
			}
		});
		fc.setAcceptAllFileFilterUsed(false);
		fc.showOpenDialog(window);
		
		File file = fc.getSelectedFile();
		if (file != null) {
			loadDataFromFile(file);
		}
	}
	
	/**
	 * Carga los datos de un archivo CSV en ArrayLists y los manda a la tabla
	 * @param file
	 */
	public void loadDataFromFile(File file) {
		FileReader fr = null;
		BufferedReader br = null;
		
		ArrayList<Object> header = new ArrayList<>();
		ArrayList<ArrayList<Object>> data = new ArrayList<>();
		
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			String[] splitHeader = br.readLine().split(",");
			for (String string : splitHeader) {
				header.add(string);
			}
			
			String rowLine;
			while ((rowLine = br.readLine()) != null) {
				String[] splitRow = rowLine.split(",");
				ArrayList<Object> row = new ArrayList<>();
				for (String column : splitRow) {
					row.add(column);
				}
				data.add(row);
			}
			
			br.close();
			fr.close();
			
			table.setModel(new MyTableModel(data, header));
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

