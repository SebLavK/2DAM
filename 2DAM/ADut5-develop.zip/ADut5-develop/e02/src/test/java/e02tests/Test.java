package e02tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import e02.Equipo;
import e02.Jugador;

public class Test {
	public static void main(String[] args) {
		//Obtiene el contexto a partir del recurso
		ApplicationContext appContext = new ClassPathXmlApplicationContext("context-bean.xml");
	
		//Obtiene el equipo
		Equipo equipo = (Equipo) appContext.getBean("equipo");
		
		//Muestra el nombre del equipo
		System.out.println(equipo.getNombre());
		//Muestra los nombres de sus jugadores
		for (Jugador jugador : equipo.getJugadores()) {
			System.out.println(jugador.getNombre()+" "+jugador.getApellidos());
		}
		
		//Obtiene un jugador
		Jugador jugador = (Jugador) appContext.getBean("jugador1");
		//Muestra su posicion
		System.out.println(jugador.getPosicion());
		//Muestra el estadio de su equipo
		System.out.println(jugador.getEquipo().getEstadio());
	}
}
