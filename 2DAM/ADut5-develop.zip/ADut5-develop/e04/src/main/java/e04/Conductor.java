package e04;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Conductor {
	
	private String nombre;
	private String apellidos;
	private LocalDate fechaCarnet;
	
	@Autowired
	@Qualifier("coche")
	private IVehiculo coche;
	
	@Autowired
	@Qualifier("camion")
	private IVehiculo camion;
	
	@Autowired
	@Qualifier("moto")
	private IVehiculo moto;

	public Conductor(String nombre, String apellidos, LocalDate fechaCarnet) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaCarnet = fechaCarnet;
	}

	public Conductor() {
		super();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public LocalDate getFechaCarnet() {
		return fechaCarnet;
	}

	public void setFechaCarnet(LocalDate fechaCarnet) {
		this.fechaCarnet = fechaCarnet;
	}

	public IVehiculo getCoche() {
		return coche;
	}

	public void setCoche(IVehiculo coche) {
		this.coche = coche;
	}

	public IVehiculo getCamion() {
		return camion;
	}

	public void setCamion(IVehiculo camion) {
		this.camion = camion;
	}

	public IVehiculo getMoto() {
		return moto;
	}

	public void setMoto(IVehiculo moto) {
		this.moto = moto;
	}

	
	
}
