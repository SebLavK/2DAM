package e01tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import e01.Persona;

public class Test {
	
	public static void main(String[] args) {
		//Carga el contexto a partir del recurso
		ApplicationContext appContext = new ClassPathXmlApplicationContext("context-bean.xml");
		
		//Obtiene el bean persona
		Persona persona = (Persona) appContext.getBean("persona");
		//Muestra su nombre
		System.out.println(persona.getNombre());
		//Muestra la calle de su direccion
		System.out.println(persona.getDireccion().getCalle());
	}
}
