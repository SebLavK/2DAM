package e03;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;

public class Jugador {

	private String nombre;
	private String apellidos;
	private String nacionalidad;
	private String posicion;
	private int dorsal;
	
	@Autowired
	private Equipo equipo;
	
	public Jugador(String nombre, String apellidos, String nacionalidad, String posicion, int dorsal, Equipo equipo) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.nacionalidad = nacionalidad;
		this.posicion = posicion;
		this.dorsal = dorsal;
		this.equipo = equipo;
	}

	public Jugador(String nombre, String apellidos, String nacionalidad, String posicion, int dorsal) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.nacionalidad = nacionalidad;
		this.posicion = posicion;
		this.dorsal = dorsal;
	}
	
	public Jugador() {
		super();
	}
	
	public String getNombre() {
		return nombre;
	}
	
	@Required
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	
	@Required
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getNacionalidad() {
		return nacionalidad;
	}
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
	public String getPosicion() {
		return posicion;
	}
	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}
	public int getDorsal() {
		return dorsal;
	}
	public void setDorsal(int dorsal) {
		this.dorsal = dorsal;
	}

	public Equipo getEquipo() {
		return equipo;
	}

	public void setEquipo(Equipo equipo) {
		this.equipo = equipo;
	}
	
	
}
