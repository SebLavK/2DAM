package e03;

import java.util.List;

import org.springframework.beans.factory.annotation.Required;

public class Equipo {
	
	private String nombre;
	private String categoria;
	private String pais;
	private String estadio;
	
	private List<Jugador> jugadores;
	
	public Equipo(String nombre, String categoria, String pais, String estadio, List<Jugador> jugadores) {
		super();
		this.nombre = nombre;
		this.categoria = categoria;
		this.pais = pais;
		this.estadio = estadio;
		this.jugadores = jugadores;
	}

	public Equipo(String nombre, String categoria, String pais, String estadio) {
		super();
		this.nombre = nombre;
		this.categoria = categoria;
		this.pais = pais;
		this.estadio = estadio;
	}
	
	public Equipo() {
		super();
	}
	
	public String getNombre() {
		return nombre;
	}
	
	@Required
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCategoria() {
		return categoria;
	}
	
	@Required
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getEstadio() {
		return estadio;
	}
	public void setEstadio(String estadio) {
		this.estadio = estadio;
	}

	public List<Jugador> getJugadores() {
		return jugadores;
	}

	public void setJugadores(List<Jugador> jugadores) {
		this.jugadores = jugadores;
	}
	
	

}
