package e03;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext appContext = new ClassPathXmlApplicationContext("context-beans.xml");
		
		Equipo equipo = (Equipo) appContext.getBean("equipo1");
		equipo.setEstadio("Piazza Rossa");
		
		Jugador jugador1 = (Jugador) appContext.getBean("jugador1");
//		jugador1.setEquipo(equipo);
		
		Jugador jugador2 = (Jugador) appContext.getBean("jugador2");
//		jugador2.setEquipo(equipo);
		
		System.out.println(equipo.getNombre());
		System.out.println(jugador1.getNombre());
		System.out.println(jugador2.getApellidos());
		System.out.println(jugador2.getEquipo().getEstadio());
	}
}
