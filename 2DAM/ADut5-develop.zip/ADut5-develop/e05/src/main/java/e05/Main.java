package e05;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//Carga el contexto
		ApplicationContext appContext = new ClassPathXmlApplicationContext("context.xml");
		
		//Obtiene beans de objetos que implementan IVehiculo
		Coche coche = (Coche) appContext.getBean("beanCoche");
		coche.setModelo("Seat");
		Camion camion = (Camion) appContext.getBean("beanCamion");
		camion.setModelo("DAF");
		Moto moto = (Moto) appContext.getBean("beanMoto");
		moto.setModelo("Ducati");
		
		//Obtiene bean del conductor
		Conductor conductor = (Conductor) appContext.getBean("beanConductor");
		conductor.setNombre("Paco");
		
		//Muestra por pantalla
		//Hace arrancar cada IVehiculo del conductor
		System.out.println(conductor.getNombre());
		conductor.getCoche().arrancar();
		conductor.getCamion().arrancar();
		conductor.getMoto().arrancar();
	}
	

}
