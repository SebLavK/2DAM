package e05;

public interface IVehiculo {
	
	public void mover();
	public void arrancar();
	public void parar();

}
