package e05;

import org.springframework.stereotype.Component;

@Component(value="beanMoto")
public class Moto implements IVehiculo {
	
	private int deposito;
	private String marca;
	private String modelo;
	private int cc;
	
	public Moto(int deposito, String marca, String modelo, int cc) {
		super();
		this.deposito = deposito;
		this.marca = marca;
		this.modelo = modelo;
		this.cc = cc;
	}
	
	public Moto() {
		super();
	}
	
	@Override
	public void mover() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void arrancar() {
		System.out.println("Se ha arrancado la moto "+modelo);
		
	}
	@Override
	public void parar() {
		// TODO Auto-generated method stub
		
	}
	public int getDeposito() {
		return deposito;
	}
	public void setDeposito(int deposito) {
		this.deposito = deposito;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public int getCc() {
		return cc;
	}
	public void setCc(int cc) {
		this.cc = cc;
	}
	
	

}
