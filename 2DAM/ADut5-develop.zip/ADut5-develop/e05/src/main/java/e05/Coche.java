package e05;

import org.springframework.stereotype.Component;

@Component(value="beanCoche")
public class Coche implements IVehiculo {

	private int deposito;
	private String marca;
	private String modelo;
	public Coche(int deposito, String marca, String modelo) {
		super();
		this.deposito = deposito;
		this.marca = marca;
		this.modelo = modelo;
	}
	public Coche() {
		super();
	}
	@Override
	public void mover() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void arrancar() {
		System.out.println("Se ha arrancado el coche "+modelo);
		
	}
	@Override
	public void parar() {
		// TODO Auto-generated method stub
		
	}
	public int getDeposito() {
		return deposito;
	}
	public void setDeposito(int deposito) {
		this.deposito = deposito;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	
}
