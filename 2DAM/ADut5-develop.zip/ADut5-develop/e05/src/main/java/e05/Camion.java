package e05;

import org.springframework.stereotype.Component;

@Component(value="beanCamion")
public class Camion implements IVehiculo {

	private int deposito;
	private String marca;
	private String modelo;
	private double carga;
	
	public Camion(int deposito, String marca, String modelo, double carga) {
		super();
		this.deposito = deposito;
		this.marca = marca;
		this.modelo = modelo;
		this.carga = carga;
	}

	public Camion() {
		super();
	}

	@Override
	public void mover() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void arrancar() {
		System.out.println("Se ha arrancado el camion "+modelo);
		
	}

	@Override
	public void parar() {
		// TODO Auto-generated method stub
		
	}

	public int getDeposito() {
		return deposito;
	}

	public void setDeposito(int deposito) {
		this.deposito = deposito;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public double getCarga() {
		return carga;
	}

	public void setCarga(double carga) {
		this.carga = carga;
	}
	
	
	
	
}
