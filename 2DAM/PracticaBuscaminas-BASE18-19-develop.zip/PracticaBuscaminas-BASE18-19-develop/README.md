BASE PARA EL BUSCAMINAS: (Sebastián Lavigne Kálmar)
=========================

En este programa se encuentra la base para el Buscaminas de Desarrollo de intefaces (DAM2).

Pasos
-----

1. Descárgate el cliente de github si no lo tienes en tu equipo. Créate una cuenta y loguéate.

2. Haz un fork de este repositorio. Un Fork se utiliza para modificar el trabajo de otras personas sin que trabajemos sobre su proyecto. En este caso mi repositorio es público, cualquiera puede acceder a él y crearse un repositorio a partir del mismo. El único que puede modificar este repositorio sin crearse una réplica (un fork) soy yo.

3. Una vez has creado un fork de tu repositorio, importa ese repositorio en local para tu máquina. Utiliza el cliente de GitHub. Sobre esa copia será sobre la que trabajes

4. Importa el proyecto en eclipse, pero no olvides que debes utilizar los archivos desde el directorio del repositorio, ¡no los copies a tu workspace!

5. Implementa el buscaminas. Cada día que vayas haciendo cambios, mantén el repositorio, así podrás llevar un seguimiento.



Licencia
--------

La licencia de este repositorio y todo su contenido es [GNU General Public License v.3.0](https://es.wikipedia.org/wiki/Licencia_p%C3%BAblica_general_de_GNU) 

version 1.8.0
---