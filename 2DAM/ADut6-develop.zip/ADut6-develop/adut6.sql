CREATE DATABASE adut6;

CREATE TABLE estudiante(
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100),
  edad INT,
  cod_ciclo INT
);

CREATE TABLE ciclo(
  cod INT PRIMARY KEY AUTO_INCREMENT,
  nombre_ciclo VARCHAR(200),
  siglas VARCHAR(100),
  familia VARCHAR(200)
);

ALTER TABLE estudiante
  ADD CONSTRAINT ciclo_fk FOREIGN KEY (cod_ciclo)
  REFERENCES ciclo (cod)

--CONSULTAS
SELECT * FROM ESTUDIANTE LEFT JOIN CICLO ON estudiante.cod_ciclo = ciclo.cod 