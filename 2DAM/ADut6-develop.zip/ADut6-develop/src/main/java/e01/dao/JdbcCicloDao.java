package e01.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import e01.model.Ciclo;

@Repository("JdbcCicloDao")
public class JdbcCicloDao implements ICicloDao {
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void insertCiclo(Ciclo ciclo) {
		this.jdbcTemplate.update(
				"INSERT INTO CICLO(NOMBRE_ciclo) VALUES(?)",
				new Object[] {ciclo.getNombre()}
				);
	}

	public void updateCiclo(Ciclo ciclo) {
		this.jdbcTemplate.update(
				"UPDATE CICLO SET NOMBRE_ciclo=?, SIGLAS=?, FAMILIA=? WHERE COD=?",
				new Object[] {ciclo.getNombre(), ciclo.getSiglas(), ciclo.getFamilia(), ciclo.getCod()}
				);
	}

	public void deleteCiclo(Ciclo ciclo) {
		this.jdbcTemplate.update("DELETE FROM CICLO WHERE COD = ?",
				ciclo.getCod());
	}

	public Ciclo findById(int cod) {
		return this.jdbcTemplate.queryForObject("SELECT * FROM CICLO WHERE COD = ?",
				new CicloMapper(), cod);
	}
	
	public Ciclo findBySiglas(String siglas) {
		return this.jdbcTemplate.queryForObject("SELECT * FROM CICLO WHERE SIGLAS = ?",
				new CicloMapper(), siglas);
	}

	public List<Ciclo> getAll() {
		return jdbcTemplate.query("SELECT * FROM CICLO", new CicloMapper());
	}

}
