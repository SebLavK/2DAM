package e01.dao;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import e01.model.Estudiante;



public class EstudianteMapper implements RowMapper<Estudiante>{

	//Metodo para mapear el resultado de la consulta SQL a un objeto estudiante
	public Estudiante mapRow(ResultSet rs, int arg1) throws SQLException {
		Estudiante student = new Estudiante();
		student.setId(rs.getInt("id"));
		student.setNombre(rs.getString("nombre"));
		student.setEdad(rs.getInt("edad"));
		if (columnExists(rs, "cod_ciclo")) {
			student.setCod_ciclo(rs.getInt("cod_ciclo"));
		}
		if (columnExists(rs, "nombre_ciclo")) {
			student.setCiclo_nombre(rs.getString("nombre_ciclo"));
		}
		if (columnExists(rs, "siglas")) {
			student.setCiclo_siglas(rs.getString("siglas"));
		}
		return student;
	}
	
	/**
	 * Verifica que exista una columna en el ResultSet de nombre columnName
	 * @param rs
	 * @param columnName
	 * @return
	 * @throws SQLException
	 */
	public static boolean columnExists(ResultSet rs, String columnName) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		int columns = rsmd.getColumnCount();
		for (int i = 1; i <= columns; i++) {
			if (columnName.equalsIgnoreCase(rsmd.getColumnName(i))) {
				return true;
			}
		}
		return false;
	}

}
