package e01.dao;

import java.util.List;

import e01.model.Estudiante;

public interface IEstudianteDao {

	public void insertEstudiante(Estudiante estudiante);
	public void updateEstudiante(Estudiante estudiante);
	public void deleteEstudiante(Estudiante estudiante);
	public Estudiante findById(int id);
	public List<Estudiante> getAll();
	public List<Estudiante> getAlumnosByCiclo(String siglas);
}
