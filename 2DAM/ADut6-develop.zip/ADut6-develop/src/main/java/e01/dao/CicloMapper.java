package e01.dao;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import e01.model.Ciclo;

public class CicloMapper implements RowMapper<Ciclo> {

	public Ciclo mapRow(ResultSet rs, int arg1) throws SQLException {
		Ciclo ciclo = new Ciclo();
		ciclo.setCod(rs.getInt("cod"));
		ciclo.setNombre(rs.getString("nombre"));
		ciclo.setSiglas(rs.getString("siglas"));
		ciclo.setFamilia(rs.getString("familia"));
		return ciclo;
	}
	
	/**
	 * Verifica que exista una columna en el ResultSet de nombre columnName
	 * @param rs
	 * @param columnName
	 * @return
	 * @throws SQLException
	 */
	public static boolean columnExists(ResultSet rs, String columnName) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		int columns = rsmd.getColumnCount();
		for (int i = 1; i <= columns; i++) {
			if (columnName.equalsIgnoreCase(rsmd.getColumnName(i))) {
				return true;
			}
		}
		return false;
	}

}
