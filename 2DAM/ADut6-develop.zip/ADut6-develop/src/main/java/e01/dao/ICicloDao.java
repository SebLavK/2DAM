package e01.dao;

import java.util.List;

import e01.model.Ciclo;

public interface ICicloDao {
	
	public void insertCiclo(Ciclo ciclo);
	public void updateCiclo(Ciclo ciclo);
	public void deleteCiclo(Ciclo ciclo);
	public Ciclo findById(int id);
	public List<Ciclo> getAll();

}
