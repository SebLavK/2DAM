package e01.model;

public class Estudiante {
	
	private Integer id;
	private String nombre;
	private Integer edad;
	private int cod_ciclo;
	
	private String ciclo_nombre;
	private String ciclo_siglas;
	
	public Estudiante() {}

	public Estudiante(String nombre, Integer edad, Integer cod_ciclo) {
		this.nombre = nombre;
		this.edad = edad;
		this.cod_ciclo = cod_ciclo;
	}
	
	public Estudiante(String nombre, Integer edad) {
		this.nombre = nombre;
		this.edad = edad;
	}
	
	public Estudiante(Integer id, String nombre, Integer edad) {
		this.id = id;
		this.nombre = nombre;
		this.edad = edad;
	}

	public Estudiante(Integer id, String nombre, Integer edad, Integer cod_ciclo) {
		this.id = id;
		this.nombre = nombre;
		this.edad = edad;
		this.cod_ciclo = cod_ciclo;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getEdad() {
		return edad;
	}

	public void setEdad(Integer edad) {
		this.edad = edad;
	}

	public int getCod_ciclo() {
		return cod_ciclo;
	}

	public void setCod_ciclo(int cod_ciclo) {
		this.cod_ciclo = cod_ciclo;
	}

	public String getCiclo_nombre() {
		return ciclo_nombre;
	}

	public void setCiclo_nombre(String ciclo_nombre) {
		this.ciclo_nombre = ciclo_nombre;
	}

	public String getCiclo_siglas() {
		return ciclo_siglas;
	}

	public void setCiclo_siglas(String ciclo_siglas) {
		this.ciclo_siglas = ciclo_siglas;
	}
	
	

}
