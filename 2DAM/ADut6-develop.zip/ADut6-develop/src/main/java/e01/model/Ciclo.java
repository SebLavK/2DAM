package e01.model;

public class Ciclo {

	private int cod;
	private String nombre;
	private String siglas;
	private String familia;
	
	public Ciclo() {};
	
	public Ciclo(String nombre, String siglas, String familia) {
		super();
		this.nombre = nombre;
		this.siglas = siglas;
		this.familia = familia;
	}
	public Ciclo(int cod, String nombre, String siglas, String familia) {
		super();
		this.cod = cod;
		this.nombre = nombre;
		this.siglas = siglas;
		this.familia = familia;
	}
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getSiglas() {
		return siglas;
	}
	public void setSiglas(String siglas) {
		this.siglas = siglas;
	}
	public String getFamilia() {
		return familia;
	}
	public void setFamilia(String familia) {
		this.familia = familia;
	}
	
	
	
}
