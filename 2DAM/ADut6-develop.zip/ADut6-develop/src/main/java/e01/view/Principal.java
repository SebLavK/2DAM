package e01.view;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import e01.dao.JdbcCicloDao;
import e01.dao.JdbcEstudianteDao;
import e01.model.Ciclo;
import e01.model.Estudiante;

public class Principal {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext ("contexto-beans.xml");
		
		JdbcEstudianteDao JdbcEstudiante = (JdbcEstudianteDao) context.getBean("JdbcEstudianteDao");
//		JdbcCicloDao JdbcCiclo = (JdbcCicloDao) context.getBean("JdbcCicloDao");
		
//		Estudiante estudiante = new Estudiante("Alice", 18);
//		Estudiante estudiante2 = new Estudiante(6,"Bob",30);
//		Ciclo ciclo = new Ciclo("Desarrollo de aplicaciones multiplataforma", "DAM", "IT");
		
		System.out.println("---Alta de registros---");
//		JdbcEstudiante.insertEstudiante(estudiante);
//		JdbcCiclo.insertCiclo(ciclo);
		
		System.out.println("---Actualizacion de registros---");
//		JdbcEstudiante.updateEstudiante(estudiante2);
		
		System.out.println("---Listado de registros---");
		List<Estudiante> students = JdbcEstudiante.getAlumnosByCiclo("DAM");
		for (Estudiante record : students) {
			System.out.print("ID: "+record.getId());
			System.out.print(", Nombre: "+record.getNombre());
			System.out.println(", Edad: "+record.getEdad());
			System.out.println("Ciclo: "+record.getCiclo_siglas());
		}
		
		
		
	}
}
