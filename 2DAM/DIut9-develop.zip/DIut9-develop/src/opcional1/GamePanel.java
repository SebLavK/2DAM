package opcional1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import javax.swing.JPanel;

/**
*@author Sebas Lavigne
*
*/

public class GamePanel extends JPanel implements Runnable {
	
	public static final int SPRITE_SIZE = 30;
	public static final Color[] SPRITE_COLORS = {
			Color.RED, Color.BLUE, Color.GREEN, Color.CYAN,
			Color.GRAY, Color.MAGENTA, Color.ORANGE, Color.PINK,
			Color.YELLOW
	};
	
	private ArrayList<Sprite> sprites;
	private int destroyedCount;
	
	public GamePanel() {
		super();
	}

	/**
	 * Debe inicializarse despues de hacer la ventana visible
	 */
	public void initializePanel() {
		destroyedCount = 0;
		sprites = new ArrayList<>();
		new Thread(this).start();
	}
	
	public void initializePanelListener() {
		this.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Sprite sprite = new Sprite(e.getX(), e.getY(), SPRITE_SIZE, randomColor());
				randomizeSpriteVelocity(sprite);
				sprites.add(sprite);
				System.out.println("New sprite created at "+e.getX()+","+e.getY());
			}
		});
	}
	
	/**
	 * Instancia un sprite con valores aleatorios
	 * @return sprite
	 */
	public Sprite randomSprite() {
		Random rd = new Random();
		Sprite sprite = new Sprite(rd.nextInt(this.getWidth()),
				rd.nextInt(this.getHeight() - SPRITE_SIZE),
				SPRITE_SIZE,
				randomColor());
		randomizeSpriteVelocity(sprite);
		return sprite;
	}
	
	public Color randomColor() {
		return SPRITE_COLORS[new Random().nextInt(SPRITE_COLORS.length)];
	}

	/**
	 * Da valores aleatorios a la velocidad de un sprite
	 * @param sprite
	 */
	public void randomizeSpriteVelocity(Sprite sprite) {
		Random rd = new Random();
		sprite.setvX(rd.nextInt(14) + 1);
		sprite.setvY(rd.nextInt(14) + 1);
		if (rd.nextBoolean()) {
			sprite.bounceX();
		}
		if (rd.nextBoolean()) {
			sprite.bounceY();
		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		fillBackground(g);
		for (Sprite sprite : sprites) {
			drawSprite(g, sprite);
		}
		drawDestroyedCount(g);
	}
	
	/**
	 * Pinta de blanco la pantalla (para cada frame)
	 * @param g
	 */
	public void fillBackground(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
	}
	
	/**
	 * Dibuja un Sprite en la pantalla
	 * @param g
	 * @param sprite
	 */
	public void drawSprite(Graphics g, Sprite sprite) {
		g.drawImage(sprite.getBuffer(),
				sprite.getPosX(),
				sprite.getPosY(),
				sprite.getDiameter(),
				sprite.getDiameter(),
				null);
	}
	
	/**
	 * MUestra en pantalla la cantidad de Sprites destruidos por colision
	 * Crea un rectangulo blanco de fondo al texto
	 * para que no quede oscurecido por un Sprite
	 * @param g
	 */
	public void drawDestroyedCount(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(355, 340, 45, 40);
		g.setColor(Color.BLACK);
		g.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		g.drawString(Integer.toString(destroyedCount), 360, 362);
	}
	
	public void outOfBounds(Sprite sprite) {
		//Left and right edges
		if (sprite.getPosX() <= 0) {
			sprite.setVXPos();
			sprite.setPosX(0);
		} else if (sprite.getPosX() + sprite.getDiameter() >= this.getWidth()){
			sprite.setVXNeg();
			sprite.setPosX(this.getWidth() - sprite.getDiameter());
		}
		//Top and bottom edges
		if (sprite.getPosY() <= 0) {
			sprite.setVYPos();
			sprite.setPosY(0);
		} else if (sprite.getPosY() + sprite.getDiameter() >= this.getHeight()){
			sprite.setVYNeg();
			sprite.setPosY(this.getHeight() - sprite.getDiameter());
		}
	}
	
	/**
	 * Chequea aquellos sprites que esten en colision en este frame
	 * y los marca para destruccion
	 */
	public void checkCollisions() {
		for (Sprite sprite1 : sprites) {
			for (Sprite sprite2 : sprites) {
				if (sprite1 != sprite2) {
					if (sprite1.collidesWith(sprite2)) {
						System.out.println("Sprite flagged for destruction");
						sprite1.flagToDestroy();
					}
				}
			}
		}
	}
	
	/**
	 * Destruye los Sprites marcados,
	 * deberia llamarse al final de un frame
	 * 
	 * Actualiza el numero de frames destruidos
	 */
	public void destroyFlagged() {
		HashSet<Sprite> toDestroy = new HashSet<>();
		for (Sprite sprite : sprites) {
			if (sprite.isDestroyFlag()) {
				//Saca el sprite marcado de la lista de sprites
				toDestroy.add(sprite);
			}
		}
		for (Sprite sprite : toDestroy) {
			sprites.remove(sprite);
			destroyedCount++;
			System.out.println("Sprite destroyed");
		}
	}
	
	/**
	 * Se ejecuta por cada "frame" de la animacion
	 * Se llama desde el metodo run del hilo
	 */
	public void tick() {
		checkCollisions();
		destroyFlagged();
		for (Sprite sprite : sprites) {
			sprite.tick();
			//Si esta fuera del panel...
			outOfBounds(sprite);
		}
	}

	@Override
	public void run() {
		while (true) {
			try {
				Thread.sleep(25);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			tick();
			repaint();
		}
	}

	
}

