package opcional1;

import java.awt.GridLayout;

import javax.swing.JFrame;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {
	
	private JFrame window;
	
	private GamePanel gamePanel;

	public MainWindow() {
		//Activa OpenGL para tener una animacion fluida
		System.setProperty("sun.java2d.opengl", "true");
		
		window = new JFrame("Tiempo real");
		window.setBounds(100, 100, 400, 400);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		window.setLayout(new GridLayout(1, 1));
		gamePanel = new GamePanel();
		window.add(gamePanel);
	}
	
	public void initializeListeners() {
		
	}
	
	public void initialize() {
		initializeComponents();
		initializeListeners();
		window.setVisible(true);
		gamePanel.initializePanel();
		gamePanel.initializePanelListener();
	}
	

}

