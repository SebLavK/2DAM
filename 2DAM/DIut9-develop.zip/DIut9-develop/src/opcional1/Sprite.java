package opcional1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
*@author Sebas Lavigne
*
*/

public class Sprite {
	
	private BufferedImage buffer;
	private Color color;
	private int diameter;
	private int posX;
	private int posY;
	private int vX;
	private int vY;
	private boolean destroyFlag;
	
	/**
	 * @param diameter
	 * @param height
	 * @param posX
	 * @param posY
	 */
	public Sprite(int posX, int posY, int diameter, Color color) {
		this.color = color;
		this.diameter = diameter;
		this.posX = posX;
		this.posY = posY;
		destroyFlag = false;
		initializeBuffer();
	}

	public Sprite() {
		color = Color.BLACK;
		destroyFlag = false;
	}
	
	public void initializeBuffer() {
		buffer = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
		Graphics g = buffer.getGraphics();
		g.setColor(color);
		g.fillOval(0, 0, diameter, diameter);
		g.dispose();
	}
	
	/**
	 * Para cada frame el sprite ejecutara este metodo
	 */
	public void tick() {
		posX += vX;
		posY += vY;
	}
	
	/**
	 * No es correcto, rebote!
	 */
	public void bounceX() {
		vX *= -1;
	}
	/**
	 * No es correcto, rebote!
	 */
	public void bounceY() {
		vY *= -1;
	}
	
	/**
	 * Determina si este Sprite colisiona con otro
	 * basandose en la distancia entre ellos.
	 * @param other El otro Sprite
	 * @return verdadero si estan en colision
	 */
	public boolean collidesWith(Sprite other) {
		return this.distanceTo(other) <= GamePanel.SPRITE_SIZE;
	}
	
	/**
	 * Como son todos del mismo tamano, no hace falta calcular
	 * explicitamente la posicion de los centros,
	 * los calculos se anulan entre ellos, se puede tomar la posicion
	 * del sprite directamente
	 * @param other El otro Sprite
	 * @return la distancia entre los centros de este Sprite y el otro Sprite
	 */
	public int distanceTo(Sprite other) {
		int distX = this.posX - other.getPosX();
		int distY = this.posY - other.getPosY();
		//Pitagoras!
		return (int) Math.sqrt(distX*distX + distY*distY);
		
	}
	
	
	/**
	 * @return the buffer
	 */
	public BufferedImage getBuffer() {
		return buffer;
	}
	/**
	 * @param buffer the buffer to set
	 */
	public void setBuffer(BufferedImage buffer) {
		this.buffer = buffer;
	}
	/**
	 * @return the color
	 */
	public Color getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(Color color) {
		this.color = color;
	}
	/**
	 * @return the width
	 */
	public int getDiameter() {
		return diameter;
	}
	/**
	 * @param diameter the width to set
	 */
	public void setDiameter(int diameter) {
		this.diameter = diameter;
	}
	
	/**
	 * @return the posX
	 */
	public int getPosX() {
		return posX;
	}
	/**
	 * @param posX the posX to set
	 */
	public void setPosX(int posX) {
		this.posX = posX;
	}
	/**
	 * @return the posY
	 */
	public int getPosY() {
		return posY;
	}
	/**
	 * @param posY the posY to set
	 */
	public void setPosY(int posY) {
		this.posY = posY;
	}

	/**
	 * @return the vX
	 */
	public int getvX() {
		return vX;
	}

	/**
	 * @param vX the vX to set
	 */
	public void setvX(int vX) {
		this.vX = vX;
	}
	
	public void setVXPos() {
		vX = Math.abs(vX);
	}
	
	public void setVXNeg() {
		vX = -Math.abs(vX);
	}
	
	/**
	 * @return the vY
	 */
	public int getvY() {
		return vY;
	}
	
	/**
	 * @param vY the vY to set
	 */
	public void setvY(int vY) {
		this.vY = vY;
	}
	
	public void setVYPos() {
		vY = Math.abs(vY);
	}
	
	public void setVYNeg() {
		vY = -Math.abs(vY);
	}
	
	/**
	 * 
	 * @return Si se ha marcado para destruir
	 */
	public boolean isDestroyFlag() {
		return destroyFlag;
	}
	
	/**
	 * Marca este Sprite para destruirlo
	 */
	public void flagToDestroy() {
		destroyFlag = true;
	}
}

