package actividad1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
*@author Sebas Lavigne
*
*/

public class Sprite {
	
	private BufferedImage buffer;
	private Color color;
	private int width;
	private int height;
	private int posX;
	private int posY;
	private int vX;
	private int vY;
	private boolean destroyFlag;
	
	/**
	 * @param width
	 * @param height
	 * @param posX
	 * @param posY
	 */
	public Sprite(int posX, int posY, int width, int height) {
		color = Color.BLACK;
		this.width = width;
		this.height = height;
		this.posX = posX;
		this.posY = posY;
		destroyFlag = false;
		initializeBuffer();
	}

	public Sprite() {
		color = Color.BLACK;
		destroyFlag = false;
	}
	
	public void initializeBuffer() {
		buffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics g = buffer.getGraphics();
		g.setColor(color);
		g.fillRect(0, 0, width, height);
		g.dispose();
	}
	
	/**
	 * Para cada frame el sprite ejecutara este metodo
	 */
	public void tick() {
		posX += vX;
		posY += vY;
	}
	
	/**
	 * No es correcto, rebote!
	 */
	public void bounceX() {
		vX *= -1;
	}
	/**
	 * No es correcto, rebote!
	 */
	public void bounceY() {
		vY *= -1;
	}
	
	/**
	 * Determina si este Sprite colisiona con otro
	 * basandose en superposicion relativa a centros geometricos.
	 * Como todos los Sprite tienen el mismo tamano se ahorra
	 * el calculo de la distancia minima entre centros para que colisionen 
	 * @param other El otro Sprite
	 * @return verdadero si estan en colision
	 */
	public boolean collidesWith(Sprite other) {
		int thisCenterX = this.getPosX() + this.getWidth() / 2;
		int thisCenterY = this.getPosY() + this.getHeight() / 2;
		int otherCenterX = other.getPosX() + other.getWidth() / 2;
		int otherCenterY = other.getPosY() + other.getHeight() / 2;
		
		boolean overlapX = Math.abs(thisCenterX - otherCenterX) <= GamePanel.SPRITE_SIZE;
		boolean overlapY = Math.abs(thisCenterY - otherCenterY) <= GamePanel.SPRITE_SIZE;
		
		return (overlapX && overlapY);
	}
	
	
	
	
	
	
	
	/**
	 * @return the buffer
	 */
	public BufferedImage getBuffer() {
		return buffer;
	}
	/**
	 * @param buffer the buffer to set
	 */
	public void setBuffer(BufferedImage buffer) {
		this.buffer = buffer;
	}
	/**
	 * @return the color
	 */
	public Color getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(Color color) {
		this.color = color;
	}
	/**
	 * @return the width
	 */
	public int getWidth() {
		return width;
	}
	/**
	 * @param width the width to set
	 */
	public void setWidth(int width) {
		this.width = width;
	}
	/**
	 * @return the height
	 */
	public int getHeight() {
		return height;
	}
	/**
	 * @param height the height to set
	 */
	public void setHeight(int height) {
		this.height = height;
	}
	/**
	 * @return the posX
	 */
	public int getPosX() {
		return posX;
	}
	/**
	 * @param posX the posX to set
	 */
	public void setPosX(int posX) {
		this.posX = posX;
	}
	/**
	 * @return the posY
	 */
	public int getPosY() {
		return posY;
	}
	/**
	 * @param posY the posY to set
	 */
	public void setPosY(int posY) {
		this.posY = posY;
	}

	/**
	 * @return the vX
	 */
	public int getvX() {
		return vX;
	}

	/**
	 * @param vX the vX to set
	 */
	public void setvX(int vX) {
		this.vX = vX;
	}
	
	public void setVXPos() {
		vX = Math.abs(vX);
	}
	
	public void setVXNeg() {
		vX = -Math.abs(vX);
	}
	
	/**
	 * @return the vY
	 */
	public int getvY() {
		return vY;
	}
	
	/**
	 * @param vY the vY to set
	 */
	public void setvY(int vY) {
		this.vY = vY;
	}
	
	public void setVYPos() {
		vY = Math.abs(vY);
	}
	
	public void setVYNeg() {
		vY = -Math.abs(vY);
	}
	
	/**
	 * 
	 * @return Si se ha marcado para destruir
	 */
	public boolean isDestroyFlag() {
		return destroyFlag;
	}
	
	/**
	 * Marca este Sprite para destruirlo
	 */
	public void flagToDestroy() {
		destroyFlag = true;
	}
}

