package spaceAttack;

import java.awt.GridLayout;

import javax.swing.JFrame;

import spaceAttack.base.GamePanel;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {
	
	private JFrame window;
	private GamePanel gamePanel;
	
	public MainWindow() {
		window = new JFrame("Space attack!");
		window.setBounds(100, 100, 600, 800);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		window.setLayout(new GridLayout(1, 1));
		gamePanel = new GamePanel();
		window.add(gamePanel);
		
	}
	
	public void initializeListeners() {
		
	}
	
	public void initialize() {
		initializeComponents();
		initializeListeners();
		window.setVisible(true);
		gamePanel.initializePanel();
//		gamePanel.initializePanelListener();
	}
}

