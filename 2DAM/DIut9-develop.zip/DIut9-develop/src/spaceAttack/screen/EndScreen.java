package spaceAttack.screen;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import spaceAttack.base.GamePanel;
import spaceAttack.base.Screen;

/**
*@author Sebas Lavigne
*
*/

public class EndScreen implements Screen {
	
	public static final int PARALLAX_SPEED = 1;
	public static final int PARALLAX_PERIOD = 1;
	public static final int MODE_VICTORY = 0;
	public static final int MODE_DEFEAT = 1;
	
	Image background;
	Image stars;
	Image bigPlanet;
	Image ringPlanet;
	Image farPlanets;
	Image spaceAttack;
	int parallax;
	int tickCount;
	String time;
	int mode;
	
	GamePanel gamePanel;

	public EndScreen(GamePanel gamePanel, String time, int mode) {
		this.gamePanel = gamePanel;
		this.time = time;
		this.mode = mode;
	}

	@Override
	public void initializeScreen() {
		initializeImages();
	}
	
	public void initializeImages() {
		try {
			background = ImageIO.read(getClass().getResource("../img/parallax-space-backgound.png"))
					.getScaledInstance(gamePanel.getWidth() + 10, gamePanel.getHeight(), BufferedImage.SCALE_SMOOTH);
			//TODO este +10 de arriba es necesario en linux?
			stars = ImageIO.read(getClass().getResource("../img/parallax-space-stars.png"))
					.getScaledInstance(gamePanel.getWidth() + 10, gamePanel.getHeight(), BufferedImage.SCALE_SMOOTH);
			farPlanets = ImageIO.read(getClass().getResource("../img/parallax-space-far-planets.png"))
					.getScaledInstance(gamePanel.getWidth() + 10, gamePanel.getHeight(), BufferedImage.SCALE_SMOOTH);
			bigPlanet = ImageIO.read(getClass().getResource("../img/parallax-space-big-planet.png"))
					.getScaledInstance(gamePanel.getWidth()*88/272, gamePanel.getWidth()*88/272, BufferedImage.SCALE_SMOOTH);
			ringPlanet = ImageIO.read(getClass().getResource("../img/parallax-space-ring-planet.png"))
					.getScaledInstance(gamePanel.getWidth()*51/272, gamePanel.getWidth()*115/272, BufferedImage.SCALE_SMOOTH);
			spaceAttack = ImageIO.read(getClass().getResource("../img/GAME-OVER.png"));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void drawScreen(Graphics g) {
		fillBackground(g);
		
		drawTitleScreen(g);
		
	}
	
	public void fillBackground(Graphics g) {
		g.drawImage(background, 0, 0, null);
		g.drawImage(stars, 0, 0, null);
		g.drawImage(farPlanets, parallax, 0, null);
		g.drawImage(bigPlanet,
				(int) (gamePanel.getWidth() - bigPlanet.getWidth(null) * 1.6) + parallax * 3,
				gamePanel.getHeight() / 2 - bigPlanet.getHeight(null) / 2,
				null);
		g.drawImage(ringPlanet,
				(int) (ringPlanet.getWidth(null) * 0.8) + parallax * 2,
				(int) (gamePanel.getHeight() - ringPlanet.getHeight(null) * 1.3),
				null);
//		g.drawImage(background, 0, parallax-background.getHeight(null), null);
//		g.drawImage(background, 0, parallax+background.getHeight(null), null);
	}

	
	public void drawTitleScreen(Graphics g) {
		
		g.drawImage(spaceAttack, (gamePanel.getWidth() - spaceAttack.getWidth(null)) / 2, 100, null);
		
		g.setColor(Color.WHITE);
		g.setFont(new Font("Consolas", Font.PLAIN, 32));
		String msg = (mode == MODE_DEFEAT) ? "Has perdido" : "Has ganado";
		g.drawString(msg, 80, 300);
		g.drawString("Puntuacion: "+time, 80, 350);
	}

	@Override
	public void tick() {
		moveParallax();
	}
	
	/**
	 * Mueve el fondo para un efecto de parallax
	 */
	public void moveParallax() {
		parallax = (int) (50 * Math.sin(Math.toRadians(tickCount) / 3));
		tickCount++;
	}

	@Override
	public void moveMouse() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clickMouse(MouseEvent e) {
		IntroScreen introScreen = new IntroScreen(gamePanel, tickCount);
		introScreen.initializeScreen();
		
		gamePanel.setCurrentScreen(introScreen);
		
	}

	@Override
	public void resizeScreen(ComponentEvent e) {
		initializeImages();
	}

}

