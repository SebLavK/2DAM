package spaceAttack.screen;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import javax.swing.SwingUtilities;

import spaceAttack.base.GamePanel;
import spaceAttack.base.Master;
import spaceAttack.base.Screen;

/**
 * @author Sebas Lavigne
 */

public class TransitionScreen extends GameScreen implements Screen {
	
	private Point shipPoint;


	public TransitionScreen(GamePanel gamePanel) {
		super(gamePanel, 0);
		shipPoint = new Point(this.getWidth() / 2 - 16, this.getHeight() - 100);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.base.Screen#initializeScreen()
	 */
	@Override
	public void initializeScreen() {
		initializeBackground();
		master = new Master(this);
		master.initializeShip();
		master.getShip().setDesiredPos(shipPoint);
		master.getShip().setPos(new Point2D.Double(
				master.getShip().getPos().getX(),
				master.getShip().getPos().getY() + 200));
		master.getShip().setAcc(0.1f);
		master.initializeCrosshair();
		gamePanel.hideCursor();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.base.Screen#drawScreen(java.awt.Graphics)
	 */
	@Override
	public void drawScreen(Graphics g) {
		fillBackground(g);

//		g.setColor(Color.RED);
//		g.fillRect(master.getLaserBolt().getPosX(),
//				master.getLaserBolt().getPosY(),
//				master.getLaserBolt().getWidth(),
//				master.getLaserBolt().getHeight());
		drawSprite(g, master.getCrosshair());
		drawSprite(g, master.getShip());
		drawTimer(g);
	}
	
	@Override
	public void drawTimer(Graphics g) {
		g.setColor(Color.WHITE);
		g.setFont(new Font("Consolas", Font.PLAIN, 32));
		g.drawString("0.000", 48, 48);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.base.Screen#tick()
	 */
	@Override
	public void tick() {
		moveParallax();
		Point p = MouseInfo.getPointerInfo().getLocation();
		SwingUtilities.convertPointFromScreen(p, this.getGamePanel());
		master.getCrosshair().setPos(p);
		master.getShip().tick();
		master.getCrosshair().tick();
		if (parallax >= 250) {
			launchGameScreen();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.base.Screen#moveMouse()
	 */
	@Override
	public void moveMouse() {
		
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.base.Screen#clickMouse(java.awt.event.MouseEvent)
	 */
	@Override
	public void clickMouse(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.base.Screen#resizeScreen(java.awt.event.ComponentEvent)
	 */
	@Override
	public void resizeScreen(ComponentEvent e) {
		super.resizeScreen(e);
	}
	
	public void launchGameScreen() {
		GameScreen screen = new GameScreen(gamePanel, parallax);
		screen.initializeScreen();
		gamePanel.setCurrentScreen(screen);
	}

}
