package spaceAttack.screen;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

import javax.imageio.ImageIO;

import spaceAttack.base.GamePanel;
import spaceAttack.base.Master;
import spaceAttack.base.Screen;
import spaceAttack.base.Sprite;
import spaceAttack.sprite.SpriteImages;

/**
*@author Sebas Lavigne
*/

public class GameScreen implements Screen {

	public static final SpriteImages SPRITE_IMAGES = new SpriteImages();
	public static final int PARALLAX_SPEED = 2;
	
	protected Master master;
	
	Image background;
	int parallax;
	
	protected LocalTime startTime;
	protected boolean freezeTime;
	protected String timeSinceString;
	
	GamePanel gamePanel;
	
	public GameScreen(GamePanel gamePanel, int parallax) {
		this.gamePanel = gamePanel;
		freezeTime = false;
		this.parallax = parallax;
	}
	
	@Override
	public void initializeScreen() {
		startTime = LocalTime.now();
		master = new Master(this);
		master.initialize();
//		initializeListeners();
		initializeBackground();
//		parallax = 0;
		gamePanel.hideCursor();
	}
	
	public void initializeBackground() {
		try {
			background = ImageIO.read(getClass().getResource("../img/bg_1_1_vertical.png"))
					.getScaledInstance(gamePanel.getWidth() + 10, gamePanel.getHeight(), BufferedImage.SCALE_SMOOTH);
			//TODO este +10 de arriba es necesario en linux?
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void drawScreen(Graphics g) {
		//Descomentar lineas para depurar colisiones
		fillBackground(g);
		
		for (Sprite sprite : master.getAsteroids()) {
			drawSprite(g, sprite);
//			g.setColor(Color.WHITE);
//			g.fillRect(sprite.getPosX(), sprite.getPosY(), sprite.getWidth(), sprite.getHeight());
		}
		for (Sprite sprite : master.getEnemyBolts()) {
			drawSprite(g, sprite);
		}
		for (Sprite sprite : master.getEnemies()) {
			drawSprite(g, sprite);
		}
		drawSprite(g, master.getLaserBolt());
//		g.setColor(Color.RED);
//		g.fillRect(master.getLaserBolt().getPosX(),
//				master.getLaserBolt().getPosY(),
//				master.getLaserBolt().getWidth(),
//				master.getLaserBolt().getHeight());
		drawSprite(g, master.getCrosshair());
		drawSprite(g, master.getShip());
		for (Sprite sprite : master.getExplosions()) {
			drawSprite(g, sprite);
		}
		drawTimer(g);
		
	}
	
	public void fillBackground(Graphics g) {
		g.drawImage(background, 0, parallax, null);
		g.drawImage(background, 0, parallax-background.getHeight(null), null);
		g.drawImage(background, 0, parallax+background.getHeight(null), null);
	}

	
	/**
	 * Dibuja un Sprite en la pantalla
	 * @param g
	 * @param sprite
	 */
	public void drawSprite(Graphics g, Sprite sprite) {
		g.drawImage(sprite.getBuffer(),
				sprite.getPosX(),
				sprite.getPosY(),
				sprite.getWidth(),
				sprite.getHeight(),
				null);
	}
	
	public void drawTimer(Graphics g) {
		if (! freezeTime) {
			Duration timeSince = Duration.between(startTime, LocalTime.now());
			long timeSinceSeconds = timeSince.getSeconds();
			long timeSinceMillis = timeSince.get(ChronoUnit.NANOS) / 1000000;
			timeSinceString = timeSinceSeconds + "." + String.format("%03d", timeSinceMillis);
		}
		g.setColor(Color.WHITE);
		g.setFont(new Font("Consolas", Font.PLAIN, 32));
		g.drawString(timeSinceString, 48, 48);
	}
	
	@Override
	public void tick() {
		moveParallax();
		master.tick();
		
	}

	/**
	 * Mueve el fondo para un efecto de parallax
	 */
	public void moveParallax() {
		parallax += PARALLAX_SPEED;
		parallax %= background.getHeight(null);
	}
	
	@Override
	public void moveMouse() {
	}

	@Override
	public void clickMouse(MouseEvent e) {
		master.mouseClicked();
		
	}

	@Override
	public void resizeScreen(ComponentEvent e) {
		initializeBackground();
	}
	
	/**
	 * @return the startTime
	 */
	public LocalTime getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}
	
	public int getWidth() {
		return gamePanel.getWidth();
	}
	
	public int getHeight() {
		return gamePanel.getHeight();
	}

	public GamePanel getGamePanel() {
		return gamePanel;
	}
	
	public void launchEndScreen(int mode) {
		EndScreen endScreen = new EndScreen(gamePanel, timeSinceString, mode);
		endScreen.initializeScreen();
		gamePanel.setCurrentScreen(endScreen);
		gamePanel.restoreCursor();
	}
	
	public void freezeTimer() {
		freezeTime = true;
	}
}
