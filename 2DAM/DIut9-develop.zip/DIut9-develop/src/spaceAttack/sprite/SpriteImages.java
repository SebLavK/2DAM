package spaceAttack.sprite;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
*@author Sebas Lavigne
*/

public class SpriteImages {

	private BufferedImage shipBuffer;
	private BufferedImage shipDestroyedBuffer;
	private BufferedImage boltBuffer;
	private BufferedImage asteroidBuffer;
	private BufferedImage explosionBuffer;
	private BufferedImage crosshairBuffer;
	private BufferedImage emptyBuffer;
	private BufferedImage enemyBuffer;
	private BufferedImage bigEnemyBuffer;
	
	private BufferedImage[][] shipSubBuffers;
	private BufferedImage[] boltSubBuffers;
	private BufferedImage[] asteroidSubBuffers;
	private BufferedImage[] explosionSubBuffers;
	private BufferedImage[] crosshairSubBuffers;
	private BufferedImage[] enemySubBuffers;
	private BufferedImage[] ballBoltSubBuffers;
	private BufferedImage[] bigEnemySubBuffers;
	
	public SpriteImages(){
		initializeShipBuffer();
		initializeShipDestroyedBuffer();
		initializeBoltBuffer();
		initializeAsteroidBuffer();
		initializeExplosionBuffer();
		initializeCrosshairBuffer();
		initializeEmptyBuffer();
		initializeEnemyBuffer();
		initializeBigEnemyBuffer();
	}
	
	private void initializeShipBuffer() {
		try {
			this.shipBuffer = ImageIO.read(getClass().getResource("../sprite/ship.png"));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		shipSubBuffers = new BufferedImage[5][3];
		//Center
		shipSubBuffers[0][0] = shipBuffer.getSubimage(64, 0, 32, 48);
		shipSubBuffers[0][1] = shipBuffer.getSubimage(64, 48, 32, 48);
		shipSubBuffers[0][2] = shipBuffer.getSubimage(64, 96, 32, 48);
		
		//Left low
		shipSubBuffers[1][0] = shipBuffer.getSubimage(32, 0, 32, 48);
		shipSubBuffers[1][1] = shipBuffer.getSubimage(32, 48, 32, 48);
		shipSubBuffers[1][2] = shipBuffer.getSubimage(32, 96, 32, 48);
		
		//Right low
		shipSubBuffers[2][0] = shipBuffer.getSubimage(96, 0, 32, 48);
		shipSubBuffers[2][1] = shipBuffer.getSubimage(96, 48, 32, 48);
		shipSubBuffers[2][2] = shipBuffer.getSubimage(96, 96, 32, 48);
		
		//Left high
		shipSubBuffers[3][0] = shipBuffer.getSubimage(0, 0, 32, 48);
		shipSubBuffers[3][1] = shipBuffer.getSubimage(0, 48, 32, 48);
		shipSubBuffers[3][2] = shipBuffer.getSubimage(0, 96, 32, 48);
		
		//Right high
		shipSubBuffers[4][0] = shipBuffer.getSubimage(128, 0, 32, 48);
		shipSubBuffers[4][1] = shipBuffer.getSubimage(128, 48, 32, 48);
		shipSubBuffers[4][2] = shipBuffer.getSubimage(128, 96, 32, 48);
	}
	
	private void initializeShipDestroyedBuffer() {
		try {
			shipDestroyedBuffer = ImageIO.read(getClass().getResource("../sprite/ship_destroyed.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void initializeBoltBuffer() {
		try {
			boltBuffer = ImageIO.read(getClass().getResource("../sprite/laserbolts.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boltSubBuffers = new BufferedImage[2];
		boltSubBuffers[0] = boltBuffer.getSubimage(6, 18, 5, 13);
		boltSubBuffers[1] = boltBuffer.getSubimage(20, 18, 5, 13);
		
		ballBoltSubBuffers = new BufferedImage[2];
		ballBoltSubBuffers[0] = boltBuffer.getSubimage(6, 7, 5, 5);
		ballBoltSubBuffers[1] = boltBuffer.getSubimage(20, 7, 5, 5);
	}

	private void initializeAsteroidBuffer() {
		try {
			asteroidBuffer = ImageIO.read(getClass().getResource("../sprite/asteroid.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		asteroidSubBuffers = new BufferedImage[8];
		for (int i = 0; i < 8; i++) {
			asteroidSubBuffers[i] = asteroidBuffer.getSubimage(32*i%128, 32*(i/4), 32, 32);
		}
	}

	
	private void initializeExplosionBuffer() {
		try {
			explosionBuffer = ImageIO.read(getClass().getResource("../sprite/explosion.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		explosionSubBuffers = new BufferedImage[5];
		for (int i = 0; i < 5; i++) {
			explosionSubBuffers[i] = explosionBuffer.getSubimage(16*i,0,16,16);
		}
	}
	
	private void initializeCrosshairBuffer() {
		try {
			crosshairBuffer = ImageIO.read(getClass().getResource("../sprite/crosshair.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		crosshairSubBuffers = new BufferedImage[4];
		for (int i = 0; i < 4; i++) {
			crosshairSubBuffers[i] = crosshairBuffer.getSubimage(64*i, 0, 64, 64);
		}
	}
	
	private void initializeEmptyBuffer() {
		emptyBuffer = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
	}
	
	private void initializeEnemyBuffer() {
		try {
			enemyBuffer = ImageIO.read(getClass().getResource("../sprite/enemy-small.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		enemySubBuffers = new BufferedImage[4];
		for (int i = 0; i < 2; i++) {
			enemySubBuffers[i] = enemyBuffer.getSubimage(16*i, 0, 16, 16);
		}
	}
	
	private void initializeBigEnemyBuffer() {
		try {
			bigEnemyBuffer = ImageIO.read(getClass().getResource("../sprite/enemy-big.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		bigEnemySubBuffers = new BufferedImage[4];
		for (int i = 0; i < 2; i++) {
			bigEnemySubBuffers[i] = bigEnemyBuffer.getSubimage(32*i, 0, 32, 32);
		}
	}
	
	/**
	 * @return the shipBuffer
	 */
	public BufferedImage getShipBuffer() {
		return shipBuffer;
	}

	/**
	 * @return the boltBuffer
	 */
	public BufferedImage getBoltBuffer() {
		return boltBuffer;
	}

	/**
	 * @return the asteroidBuffer
	 */
	public BufferedImage getAsteroidBuffer() {
		return asteroidBuffer;
	}

	/**
	 * @return the shipSubBuffers
	 */
	public BufferedImage[][] getShipSubBuffers() {
		return shipSubBuffers;
	}

	/**
	 * @return the boltSubBuffers
	 */
	public BufferedImage[] getBoltSubBuffers() {
		return boltSubBuffers;
	}

	/**
	 * @return the asteroidSubBuffers
	 */
	public BufferedImage[] getAsteroidSubBuffers() {
		return asteroidSubBuffers;
	}

	/**
	 * @return the explosionBuffer
	 */
	public BufferedImage getExplosionBuffer() {
		return explosionBuffer;
	}

	/**
	 * @return the explosionSubBuffers
	 */
	public BufferedImage[] getExplosionSubBuffers() {
		return explosionSubBuffers;
	}

	/**
	 * @return the crosshairBuffer
	 */
	public BufferedImage getCrosshairBuffer() {
		return crosshairBuffer;
	}

	/**
	 * @return the crosshairSubBuffers
	 */
	public BufferedImage[] getCrosshairSubBuffers() {
		return crosshairSubBuffers;
	}

	/**
	 * @return the emptyBuffer
	 */
	public BufferedImage getEmptyBuffer() {
		return emptyBuffer;
	}

	/**
	 * @return the shipDestoryedBuffer
	 */
	public BufferedImage getShipDestroyedBuffer() {
		return shipDestroyedBuffer;
	}

	/**
	 * @return the enemyBuffer
	 */
	public BufferedImage getEnemyBuffer() {
		return enemyBuffer;
	}

	/**
	 * @return the enemySubBuffers
	 */
	public BufferedImage[] getEnemySubBuffers() {
		return enemySubBuffers;
	}

	/**
	 * @return the ballBoltSubBuffers
	 */
	public BufferedImage[] getBallBoltSubBuffers() {
		return ballBoltSubBuffers;
	}

	/**
	 * @return the bigEnemyBuffer
	 */
	public BufferedImage getBigEnemyBuffer() {
		return bigEnemyBuffer;
	}

	/**
	 * @return the bigEnemySubBuffers
	 */
	public BufferedImage[] getBigEnemySubBuffers() {
		return bigEnemySubBuffers;
	}
	
	

	
}
