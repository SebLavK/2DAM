package spaceAttack.sprite;

import java.awt.image.BufferedImage;
import java.util.Random;

import spaceAttack.base.Master;
import spaceAttack.screen.GameScreen;

/**
 * @author Sebas Lavigne
 */

public class BigEnemy extends Enemy {

	public static final int INTRO_MODE = 0;
	public static final int CIRCLE_MODE = 1;
	public static final int DESTROY_MODE = 2;
	public static final float BIG_AMPLITUDE = 200;
	public static final float BIG_FREQ = 0.6f;
	public static final int BIG_POS_HEIGHT = 400;

	private int flyMode;
	private int circleCount;
	private int centerX;
	private Random rd;

	/**
	 * @param posX
	 * @param posY
	 * @param vX
	 * @param amplitude
	 * @param frequencyMod
	 * @param master
	 */
	public BigEnemy(int posX, int posY, int vX, float amplitude, float frequencyMod, Master master) {
		super(posX, posY, vX, amplitude, frequencyMod, master);
		this.posY = posY;
		vY = 1;
		this.hp = DEFAULT_BIG_HP;
		this.flyMode = INTRO_MODE;
		centerX = posX;
		this.width *= 2;
		this.height *= 2;
		rd = new Random();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.sprite.Enemy#getBuffer()
	 */
	@Override
	public BufferedImage getBuffer() {
		return GameScreen.SPRITE_IMAGES.getBigEnemySubBuffers()[rotation];
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.sprite.Enemy#tick()
	 */
	@Override
	public void tick() {
		super.tick();
		updateVelocity();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.sprite.Enemy#updateVelocity()
	 */
	@Override
	public void updateVelocity() {
		if (flyMode == INTRO_MODE && posY == BIG_POS_HEIGHT) {
			flyMode = CIRCLE_MODE;
			vY = 0;
			vX = 0;
		} else if (flyMode == CIRCLE_MODE) {
			posX = (int) (BIG_AMPLITUDE * Math.sin(Math.toRadians(circleCount) * BIG_FREQ)) + centerX;
			posY = (int) (BIG_AMPLITUDE * Math.cos(Math.toRadians(circleCount) * BIG_FREQ)) + BIG_POS_HEIGHT / 2;
			circleCount++;
		} else if (flyMode == DESTROY_MODE) {
			vX = 0;
			vY = 0;
			if (tickCount % 4 == 0) {

				master.spawnExplosion(posX + rd.nextInt(this.width - 32), posY + rd.nextInt(this.height - 32), 0, 0);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.sprite.Enemy#randomFire()
	 */
	@Override
	public void randomFire() {
		if (flyMode != DESTROY_MODE) {
			super.randomFire();
			master.spawnEnemyBolt(this.posX + this.width / 2 - 5 + 20, this.posY + this.height / 2, 0,
					BallBolt.DEFAULT_SPEED);
			master.spawnEnemyBolt(this.posX + this.width / 2 - 5 - 20, this.posY + this.height / 2, 0,
					BallBolt.DEFAULT_SPEED);
			master.spawnEnemyBolt(this.posX + this.width / 2 - 5, this.posY + this.height / 2, 1,
					BallBolt.DEFAULT_SPEED);
			master.spawnEnemyBolt(this.posX + this.width / 2 - 5, this.posY + this.height / 2, -1,
					BallBolt.DEFAULT_SPEED);
			master.spawnEnemyBolt(this.posX + this.width / 2 - 5, this.posY + this.height / 2, 2, 2);
			master.spawnEnemyBolt(this.posX + this.width / 2 - 5, this.posY + this.height / 2, -2, 2);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spaceAttack.base.Sprite#flagToDestroy()
	 */
	@Override
	public void flagToDestroy() {
		super.flagToDestroy();
		flyMode = DESTROY_MODE;
	}

	/**
	 * @return the flyMode
	 */
	public int getFlyMode() {
		return flyMode;
	}

	/**
	 * @param flyMode the flyMode to set
	 */
	public void setFlyMode(int flyMode) {
		this.flyMode = flyMode;
	}

}
