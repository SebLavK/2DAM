package spaceAttack.sprite;

import java.awt.image.BufferedImage;

import spaceAttack.base.GamePanel;
import spaceAttack.base.Sprite;
import spaceAttack.screen.GameScreen;

/**
*@author Sebas Lavigne
*/

public class Explosion extends Sprite {
	
	private static final int DEFAULT_PERIOD = 8;
	
	private int tickCount;
	private int rotation;
	private int rotationPeriod;
	private int rotationAmount;
	
	/**
	 * @param posX
	 * @param posY
	 */
	public Explosion(int posX, int posY, int vX, int vY) {
		super(posX, posY);
		this.vX = vX;
		this.vY = vY;
		initializeBuffer();
		width = getBuffer().getWidth()*2;
		height = getBuffer().getHeight()*2;
		rotationPeriod = DEFAULT_PERIOD;
		rotationAmount = GameScreen.SPRITE_IMAGES.getExplosionSubBuffers().length;
	}
	
	@Override
	public void initializeBuffer() {
		rotation = 0;
	}
	
	public void tick() {
		super.tick();
		if (tickCount % rotationPeriod == 0) {
			rotation++;
			if (rotation == rotationAmount) {
				this.flagToDestroy();
			}
			rotation %= rotationAmount;
		}
		tickCount++;
	}
	
	@Override
	public BufferedImage getBuffer() {
		return GameScreen.SPRITE_IMAGES.getExplosionSubBuffers()[rotation];
	}

}
