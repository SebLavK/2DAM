package spaceAttack.sprite;

import java.awt.image.BufferedImage;
import java.util.Random;

import spaceAttack.base.Master;
import spaceAttack.base.Sprite;
import spaceAttack.screen.GameScreen;

/**
*@author Sebas Lavigne
*/

public class Enemy extends Sprite {
	
	public static final int ROTATION_PERIOD = 15;
	public static final float DEFAULT_AMPLITUDE = 60;
	public static final float DEFAULT_FREQ_MOD = 4;
	public static final int DEFAULT_SMALL_HP = 2;
	public static final int DEFAULT_BIG_HP = 20;
	public static final int MIN_FIRE_RATE = 50;
	public static final int MAX_FIRE_RATE = 100;
	
	protected int tickCount;
	protected int nextFire;
	protected int rotation;
	protected int rotationPeriod;
	protected float amplitude;
	protected float frequencyMod;
	protected int posHeight;
	protected int hp;
	protected Master master;
	

	/**
	 * @param posX
	 * @param posY
	 */
	public Enemy(int posX, int posY, int vX, float amplitude, float frequencyMod, Master master) {
		super(posX, 0);
		this.vX = vX;
		this.amplitude = amplitude;
		this.frequencyMod = frequencyMod;
		this.posHeight = posY;
		this.master = master;
		initializeBuffer();
		width = getBuffer().getWidth() * 2;
		height = getBuffer().getHeight() * 2;
		rotationPeriod = ROTATION_PERIOD;
		hp = DEFAULT_SMALL_HP;
	}

	@Override
	public void initializeBuffer() {
		rotation = 0;
	}

	/* (non-Javadoc)
	 * @see spaceAttack.base.Sprite#tick()
	 */
	@Override
	public void tick() {
		super.tick();
		updateVelocity();
		if (tickCount % rotationPeriod == 0) {
			rotation++;
			rotation %= 2;
		}
		if (tickCount == nextFire) {
			randomFire();
		}
		tickCount++;
	}
	
	/**
	 * Sigue una funcion para determinar la velocidad
	 */
	public void updateVelocity() {
		posY = (int) (amplitude * Math.sin(Math.toRadians(tickCount) * frequencyMod)) + posHeight; 
	}
	
	public void hit() {
		hp--;
		if (hp <= 0) {
			this.flagToDestroy();
		}
	}
	
	public void randomFire() {
		nextFire = new Random().nextInt(MAX_FIRE_RATE - MIN_FIRE_RATE) + MIN_FIRE_RATE + tickCount;
		master.spawnEnemyBolt(this.posX + this.width / 2 - 5, this.posY + this.height / 2, 0, BallBolt.DEFAULT_SPEED);
	}

	@Override
	public void keepInBounds(int screenWidth, int screenHeight) {
//		super.keepInBounds(screenWidth, screenHeight);
		vX = (posX <= -this.width * 3) ? Math.abs(vX) : vX;
		vX = (posX + this.width >= screenWidth + this.width * 3) ? -Math.abs(vX) : vX;
	}

	/* (non-Javadoc)
	 * @see spaceAttack.base.Sprite#getBuffer()
	 */
	@Override
	public BufferedImage getBuffer() {
		return GameScreen.SPRITE_IMAGES.getEnemySubBuffers()[rotation];
	}

	/**
	 * @return the hp
	 */
	public int getHp() {
		return hp;
	}

	/**
	 * @param hp the hp to set
	 */
	public void setHp(int hp) {
		this.hp = hp;
	}
	
	
	
}
