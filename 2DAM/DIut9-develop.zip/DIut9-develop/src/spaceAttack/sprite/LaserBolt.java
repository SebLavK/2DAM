package spaceAttack.sprite;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import spaceAttack.base.GamePanel;
import spaceAttack.base.Sprite;
import spaceAttack.screen.GameScreen;

/**
*@author Sebas Lavigne
*
*/

public class LaserBolt extends Sprite {
	
	public static final int SPRITE_CYCLE_RATE = 10;
	
	private int spriteNum;
	private int tickCount;
	private boolean fired;
	
	/**
	 * @param posX
	 * @param posY
	 */
	public LaserBolt(int posX, int posY, int vY) {
		super(posX, posY);
		vX = 0;
		this.vY = vY;
		initializeBuffer();
		width = getBuffer().getWidth() * 2;
		height = getBuffer().getHeight() * 2;
	}

	@Override
	public void initializeBuffer() {
		spriteNum = 0;
	}

	@Override
	public void keepInBounds(int screenWidth, int screenHeight) {
		if (this.posY <= 0) {
			this.flagToDestroy();
		}
	}

	@Override
	public void tick() {
		super.tick();
		if (tickCount % SPRITE_CYCLE_RATE == 0) {
			spriteNum = spriteNum == 0 ? 1 : 0;
		}
		tickCount++;
		if (destroyFlag) {
			this.hide();
		}
	}
	
	public void hide() {
		posX = -200;
		posY = 100;
		vY = 0;
		destroyFlag = false;
		fired = false;
	}

	@Override
	public BufferedImage getBuffer() {
		return GameScreen.SPRITE_IMAGES.getBoltSubBuffers()[spriteNum];
	}
	
	public boolean isFired() {
		return fired;
	}
	
	public void flagFired() {
		fired = true;
	}
	
	

}

