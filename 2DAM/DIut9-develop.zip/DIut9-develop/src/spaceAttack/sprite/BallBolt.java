package spaceAttack.sprite;

import java.awt.image.BufferedImage;

import spaceAttack.base.Sprite;
import spaceAttack.screen.GameScreen;

/**
*@author Sebas Lavigne
*/

public class BallBolt extends Sprite {
	
	public static final int SPRITE_CYCLE_RATE = 10;
	public static final int DEFAULT_SPEED = 3;
	
	private int spriteNum;
	private int tickCount;

	/**
	 * @param posX
	 * @param posY
	 */
	public BallBolt(int posX, int posY, int vX, int vY) {
		super(posX, posY);
		this.vX = vX;
		this.vY = vY;
		initializeBuffer();
		width = getBuffer().getWidth() * 2;
		height = getBuffer().getWidth() * 2;
	}

	@Override
	public void initializeBuffer() {
		spriteNum = 0;
	}

	@Override
	public void keepInBounds(int screenWidth, int screenHeight) {
		if (this.posY >= screenHeight) {
			this.flagToDestroy();
		}
	}

	@Override
	public void tick() {
		super.tick();
		if (tickCount % SPRITE_CYCLE_RATE == 0) {
			spriteNum = spriteNum == 0 ? 1 : 0;
		}
		tickCount++;
	}

	/* (non-Javadoc)
	 * @see spaceAttack.base.Sprite#getBuffer()
	 */
	@Override
	public BufferedImage getBuffer() {
		return GameScreen.SPRITE_IMAGES.getBallBoltSubBuffers()[spriteNum];
	}
	
	
	
	

}
