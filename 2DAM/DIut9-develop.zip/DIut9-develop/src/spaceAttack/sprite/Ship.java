package spaceAttack.sprite;

import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.Random;

import spaceAttack.base.Master;
import spaceAttack.base.Sprite;
import spaceAttack.screen.GameScreen;

/**
*@author Sebas Lavigne
*/

public class Ship extends Sprite {
	
	public static final int ENGINE_PULSE_RATE = 15;
	public static final float DEFAULT_V_MAX = 10f;
	public static final float DEFAULT_ACC = 0.3f;
	
	public static final int ENGINE_FLUME_0 = 0;
	public static final int ENGINE_FLUME_1 = 1;
	public static final int ENGINE_FLUME_NONE = 2;
	
	public static final int ROLL_MODE_NONE = 0;
	public static final int ROLL_MODE_LEFT = 1;
	public static final int ROLL_MODE_RIGHT = 2;
	
	public static final int ROLL_STRENGTH_LOW = 0;
	public static final int ROLL_STRENGTH_HIGH = 2;
	
	public static final int DEFAULT_BOLT_SPEED = -10;
	
	private int engineMode;
	private int rollModifier;
	private int rollStrength;
	private int tickCount;
	private Point2D desiredPos;
	
	private Master master;
	private Random rd;
	
	private int boltSpeed;
	
	/** Current position */
	private Point2D pos;
	/** Current velocity */
	private Point2D vTotal;
	/** Max velocity */
	private float vMax;
	/** Acceleration */
	private float acc;
	

	public Ship(int posX, int posY) {
		super(posX, posY);
		tickCount = 0;
		pos = new Point2D.Float(posX, posY);
		vTotal = new Point2D.Float(0, 0);
		vMax = DEFAULT_V_MAX;
		acc = DEFAULT_ACC;
		boltSpeed = DEFAULT_BOLT_SPEED;
		initializeBuffer();
		width = getBuffer().getWidth();
		height = getBuffer().getHeight();
		rd = new Random();
	}
	
	@Override
	public void initializeBuffer() {
		engineMode = 0;
	}

	/* (non-Javadoc)
	 * @see spaceAttack.Sprite#tick()
	 */
	@Override
	public void tick() {
		if (destroyFlag) {
			super.tick();
		} else {
			moveTowardsDesiredPos();
		}
		animateEngine();
		animateRoll();
		tickCount++;
	}

	/**
	 * Anima el cohete de la nave
	 */
	public void animateEngine() {
		if (desiredPos.getY() - pos.getY() > GameScreen.PARALLAX_SPEED) {
			engineMode = ENGINE_FLUME_NONE;
		} else if (tickCount % ENGINE_PULSE_RATE == 0) {
			if (engineMode == ENGINE_FLUME_0) {
				engineMode = ENGINE_FLUME_1;
			} else {
				engineMode = ENGINE_FLUME_0;
			}
			
		}
		
		if (isDestroyFlag() && tickCount % ENGINE_PULSE_RATE == 0) {
			master.spawnExplosion(
					posX + rd.nextInt(51) - 25,
					posY + rd.nextInt(51) - 25,
					vX / 2,
					vY / 2);;
		}
	}
	
	/**
	 * Anima el alaveo de la nave
	 */
	public void animateRoll() {
		int diffHor = (int) (desiredPos.getX() - pos.getX());
		
		if (Math.abs(diffHor) > 100) {
			rollModifier = (diffHor < 0) ? ROLL_MODE_LEFT : ROLL_MODE_RIGHT;
		} else {
			rollModifier = ROLL_MODE_NONE;
		}
		
		rollStrength = (Math.abs(diffHor) > 200) ? ROLL_STRENGTH_HIGH : ROLL_STRENGTH_LOW;
	}
	
	/**
	 * Mueve la nave hacia el cursor
	 * 
	 * Implementa aceleracion en la direccion del cursor
	 * Decelera cuando se va acercando
	 */
	private void moveTowardsDesiredPos() {
		double dragModifier = 1;
		Point2D currentPos = new Point2D.Float(posX, posY);
		
		double distanceToCursor = currentPos.distance(desiredPos);
		double vMagnitude = vTotal.distance(0, 0);
		
		/* Decelerating when closing to desiredPos */
		//Time it would take to stop at current speed and acceleration rate
		double time = vMagnitude / acc;
		//If reaching the desiredPos
		if (vMagnitude * time >= distanceToCursor) {
			//Slow down
			dragModifier = distanceToCursor / (vMagnitude * time);
		}
		
		/* Accelerating towards direction */
		vTotal.setLocation(
				vTotal.getX() + acc * (desiredPos.getX() - currentPos.getX()) / distanceToCursor,
				vTotal.getY() + acc * (desiredPos.getY() - currentPos.getY()) / distanceToCursor
		);
		
		/* Artificial drag to slow down when near the cursor */
		if (dragModifier < 1) {
			vTotal.setLocation(vTotal.getX() * dragModifier, vTotal.getY() * dragModifier);
		}
		
		if (Double.isNaN(vTotal.getX())) {
			vTotal.setLocation(0, vTotal.getY());
		}
		
		if (Double.isNaN(vTotal.getY())) {
			vTotal.setLocation(vTotal.getX(), 0);
		}
		
		/* Respecting limits of max velocity */
		if (vTotal.distance(0, 0) > vMax) {
			vTotal.setLocation(
					vMax * vTotal.getX() / vTotal.distance(0,0),
					vMax * vTotal.getY() / vTotal.distance(0,0)
			);
		}
		
		/* Changing position accordingly */
		pos.setLocation(
				pos.getX() + vTotal.getX(),
				pos.getY() + vTotal.getY()
				);
		
		/* Casting to int for GamePanel */
		posX = (int) pos.getX();
		posY = (int) pos.getY();
	}
	

	@Override
	public void keepInBounds(int screenWidth, int screenHeight) {
		super.keepInBounds(screenWidth, screenHeight);
		if (posX == 0 || posX + this.width == screenWidth) {
			pos.setLocation(posX, pos.getY());
		}
		if (posY == 0 || posY + this.height == screenHeight) {
			pos.setLocation(pos.getX(), posY);
		}
	}

	@Override
	public void flagToDestroy() {
		super.flagToDestroy();
		vX = (int) vTotal.getX() / 2;
		vY = (int) vTotal.getY() / 2;
	}

	@Override
	public BufferedImage getBuffer() {
		return isDestroyFlag() ? GameScreen.SPRITE_IMAGES.getShipDestroyedBuffer()
				: GameScreen.SPRITE_IMAGES.getShipSubBuffers()[rollModifier + rollStrength][engineMode];
	}
	
	public void setDesiredPos(Point2D desiredPos) {
		this.desiredPos = desiredPos;
	}

	/**
	 * @return the boltSpeed
	 */
	public int getBoltSpeed() {
		return boltSpeed;
	}

	/**
	 * @param boltSpeed the boltSpeed to set
	 */
	public void setBoltSpeed(int boltSpeed) {
		this.boltSpeed = boltSpeed;
	}

	/**
	 * @return the vMax
	 */
	public float getvMax() {
		return vMax;
	}

	/**
	 * @param vMax the vMax to set
	 */
	public void setvMax(float vMax) {
		this.vMax = vMax;
	}

	/**
	 * @return the master
	 */
	public Master getMaster() {
		return master;
	}

	/**
	 * @param master the master to set
	 */
	public void setMaster(Master master) {
		this.master = master;
	}

	/**
	 * @return the pos
	 */
	public Point2D getPos() {
		return pos;
	}

	/**
	 * @param pos the pos to set
	 */
	public void setPos(Point2D pos) {
		this.pos = pos;
	}

	/**
	 * @return the acc
	 */
	public float getAcc() {
		return acc;
	}

	/**
	 * @param acc the acc to set
	 */
	public void setAcc(float acc) {
		this.acc = acc;
	}
	
	

}
