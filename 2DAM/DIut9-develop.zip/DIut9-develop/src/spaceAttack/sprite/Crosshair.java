package spaceAttack.sprite;

import java.awt.Point;
import java.awt.image.BufferedImage;

import spaceAttack.base.Sprite;
import spaceAttack.screen.GameScreen;

/**
*@author Sebas Lavigne
*/

public class Crosshair extends Sprite {
	
	public static final int CROSSHAIR_SIZE = 24;
	public static final int CROSSHAIR_ROTATION_SPEED = 5;
	
	private int tickCount;
	private int rotation;
	private int rotationPeriod;

	/**
	 * @param posX
	 * @param posY
	 */
	public Crosshair(int posX, int posY) {
		super(posX, posY);
		initializeBuffer();
		width = CROSSHAIR_SIZE;
		height = CROSSHAIR_SIZE;
		rotationPeriod = CROSSHAIR_ROTATION_SPEED;
	}

	@Override
	public void initializeBuffer() {
		rotation = 0;
	}

	@Override
	public void tick() {
		if (tickCount % rotationPeriod == 0) {
			rotation++;
			rotation %= 4;
		}
		tickCount++;
	}

	@Override
	public BufferedImage getBuffer() {
		return GameScreen.SPRITE_IMAGES.getCrosshairSubBuffers()[rotation];
	}
	
	public void setPos(Point p) {
		setPosX((int) p.getX() + 4);
		setPosY((int) p.getY() + 4); 
	}
	

}
