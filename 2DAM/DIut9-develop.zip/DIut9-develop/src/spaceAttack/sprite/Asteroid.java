package spaceAttack.sprite;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import spaceAttack.base.GamePanel;
import spaceAttack.base.Sprite;
import spaceAttack.screen.GameScreen;

/**
*@author Sebas Lavigne
*/

public class Asteroid extends Sprite {
	
	private int tickCount;
	private int rotation;
	private int rotationPeriod;

	public Asteroid(int posX, int posY, int vX, int vY) {
		super(posX, posY);
		this.vX = vX;
		this.vY = vY;
		initializeBuffer();
		width = getBuffer().getWidth();
		height = getBuffer().getHeight();
		rotationPeriod = new Random().nextInt(20)+5;
	}

	@Override
	public void initializeBuffer() {
		
		rotation = 0;
	}

	@Override
	public void keepInBounds(int screenWidth, int screenHeight) {
//		super.keepInBounds(screenWidth, screenHeight);
		
		vX = (posX <= 0) ? Math.abs(vX) : vX;
		vX = (posX + this.width >= screenWidth) ? -Math.abs(vX) : vX;
		vY = (posY <= 0) ? Math.abs(vY) : vY;
		vY = (posY + this.height >= screenHeight) ? -Math.abs(vY) : vY;
	}

	/* (non-Javadoc)
	 * @see spaceAttack.Sprite#tick()
	 */
	@Override
	public void tick() {
		// TODO Auto-generated method stub
		super.tick();
		if (tickCount % rotationPeriod == 0) {
			rotation++;
			rotation %= 8;
		}
		tickCount++;
	}

	/* (non-Javadoc)
	 * @see spaceAttack.Sprite#getBuffer()
	 */
	@Override
	public BufferedImage getBuffer() {
		return GameScreen.SPRITE_IMAGES.getAsteroidSubBuffers()[rotation];
	}
	
	
	
	

}
