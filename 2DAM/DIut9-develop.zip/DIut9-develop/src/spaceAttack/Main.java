package spaceAttack;

import java.awt.EventQueue;
import java.awt.GraphicsEnvironment;


/**
 * @author Sebas Lavigne
 *
 */

public class Main {

	public static void main(String[] args) {
//		String fonts[] = 
//			      GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
//
//			    for ( int i = 0; i < fonts.length; i++ )
//			    {
//			      System.out.println(fonts[i]);
//			    }
		
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				try {
					MainWindow mainWindow = new MainWindow();
					mainWindow.initialize();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
