package spaceAttack.base;

import java.awt.Graphics;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;

/**
*@author Sebas Lavigne
*/

public interface Screen {
	
	public void initializeScreen();
	
	public void drawScreen(Graphics g);
	
	public void tick();
	
	public void moveMouse();
	
	public void clickMouse(MouseEvent e);
	
	public void resizeScreen(ComponentEvent e);

}
