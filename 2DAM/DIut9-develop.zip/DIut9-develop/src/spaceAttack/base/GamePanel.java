package spaceAttack.base;

import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import spaceAttack.screen.IntroScreen;


/**
*@author Sebas Lavigne
*
*/

public class GamePanel extends JPanel implements Runnable, MouseListener, ComponentListener{
	
	private static final long serialVersionUID = 1L;
	
	public static final int REFRESH_PERIOD = 17;
	
	private Screen currentScreen;
	
	public void initializePanel() {
		
		currentScreen = new IntroScreen(this, 0);
		currentScreen.initializeScreen();
		initializeListeners();
		new Thread(this).start();
	}
	
	public void initializeListeners() {
		this.addMouseListener(this);
		this.addComponentListener(this);
	}
	
	public void hideCursor() {
		// Transparent 16 x 16 pixel cursor image.
		BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);

		// Create a new blank cursor.
		Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(cursorImg, new Point(0, 0), "blank cursor");

		// Set the blank cursor to the JPanel.
		this.setCursor(blankCursor);
	}
	
	public void restoreCursor() {
		this.setCursor(Cursor.getDefaultCursor());
	}
	
	/**
	 * @return the currentScreen
	 */
	public Screen getCurrentScreen() {
		return currentScreen;
	}

	/**
	 * @param currentScreen the currentScreen to set
	 */
	public void setCurrentScreen(Screen currentScreen) {
		this.currentScreen = currentScreen;
	}

	@Override
	public void run() {
		while(true) {
			try {
				Thread.sleep(REFRESH_PERIOD);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			currentScreen.tick();
			repaint();
			//Para funcionamiento fluido en Linux
			Toolkit.getDefaultToolkit().sync();
		}
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		currentScreen.drawScreen(g);
	}
	@Override
	public void mouseClicked(MouseEvent e) {}
	@Override
	public void mouseEntered(MouseEvent e) {}
	@Override
	public void mouseExited(MouseEvent e) {}
	@Override
	public void mousePressed(MouseEvent e) {
		currentScreen.clickMouse(e);
	}
	@Override
	public void mouseReleased(MouseEvent e) {}

	@Override
	public void componentShown(ComponentEvent e) {}
	@Override
	public void componentResized(ComponentEvent e) {currentScreen.resizeScreen(e);}
	@Override
	public void componentMoved(ComponentEvent e) {}
	@Override
	public void componentHidden(ComponentEvent e) {}
}

