package spaceAttack.base;

import java.awt.image.BufferedImage;

/**
*@author Sebas Lavigne
*
*/

public abstract class Sprite {
	
	protected BufferedImage buffer;
	protected int width;
	protected int height;
	protected int posX;
	protected int posY;
	protected int vX;
	protected int vY;
	protected boolean destroyFlag;
	
	/**
	 * @param posX
	 * @param posY
	 */
	public Sprite(int posX, int posY) {
		super();
		this.posX = posX;
		this.posY = posY;
		destroyFlag = false;
	}
	
	public abstract void initializeBuffer();
	
	/**
	 * Se ejecuta por cada frame para este Sprite
	 */
	public void tick() {
		posX += vX;
		posY += vY;
	}
	
	public void keepInBounds(int screenWidth, int screenHeight) {
		posX = (posX < 0)? 0 : posX;
		posY = (posY < 0)? 0 : posY;
		
		posX = (posX + this.width > screenWidth) ? screenWidth-this.width : posX;
		posY = (posY + this.height > screenHeight) ? screenHeight-this.height : posY;
	}

	/**
	 * Rebota la direccion en el exe X
	 */
	public void bounceX() {
		vX *= -1;
	}
	
	/**
	 * Rebota la direccion en el exe Y
	 */
	public void bounceY() {
		vY *= -1;
	}
	
	/**
	 * Determina si este Sprite colisiona con otro
	 * basandose en superposicion relativa a centros geometricos.
	 * Como todos los Sprite tienen el mismo tamano se ahorra
	 * el calculo de la distancia minima entre centros para que colisionen 
	 * @param other El otro Sprite
	 * @return verdadero si estan en colision
	 */
	public boolean collidesWithRectangular(Sprite other) {
		int thisCenterX = this.getPosX() + this.getWidth() / 2;
		int thisCenterY = this.getPosY() + this.getHeight() / 2;
		int otherCenterX = other.getPosX() + other.getWidth() / 2;
		int otherCenterY = other.getPosY() + other.getHeight() / 2;
		
		boolean overlapX = Math.abs(thisCenterX - otherCenterX) <= (this.getWidth() + other.getWidth()) / 2;
		boolean overlapY = Math.abs(thisCenterY - otherCenterY) <= (this.getHeight() + other.getHeight()) / 2;
		
		return (overlapX && overlapY);
	}
	
	/**
	 * @return the buffer
	 */
	public BufferedImage getBuffer() {
		return buffer;
	}
	/**
	 * @param buffer the buffer to set
	 */
	public void setBuffer(BufferedImage buffer) {
		this.buffer = buffer;
	}
	
	/**
	 * @return the width
	 */
	public int getWidth() {
		return width;
	}
	/**
	 * @param width the width to set
	 */
	public void setWidth(int width) {
		this.width = width;
	}
	/**
	 * @return the height
	 */
	public int getHeight() {
		return height;
	}
	/**
	 * @param height the height to set
	 */
	public void setHeight(int height) {
		this.height = height;
	}
	/**
	 * @return the posX
	 */
	public int getPosX() {
		return posX;
	}
	/**
	 * @param posX the posX to set
	 */
	public void setPosX(int posX) {
		this.posX = posX;
	}
	/**
	 * @return the posY
	 */
	public int getPosY() {
		return posY;
	}
	/**
	 * @param posY the posY to set
	 */
	public void setPosY(int posY) {
		this.posY = posY;
	}

	/**
	 * @return the vX
	 */
	public int getvX() {
		return vX;
	}

	/**
	 * @param vX the vX to set
	 */
	public void setvX(int vX) {
		this.vX = vX;
	}
	
	public void setVXPos() {
		vX = Math.abs(vX);
	}
	
	public void setVXNeg() {
		vX = -Math.abs(vX);
	}
	
	/**
	 * @return the vY
	 */
	public int getvY() {
		return vY;
	}
	
	/**
	 * @param vY the vY to set
	 */
	public void setvY(int vY) {
		this.vY = vY;
	}
	
	public void setVYPos() {
		vY = Math.abs(vY);
	}
	
	public void setVYNeg() {
		vY = -Math.abs(vY);
	}
	
	/**
	 * 
	 * @return Si se ha marcado para destruir
	 */
	public boolean isDestroyFlag() {
		return destroyFlag;
	}
	
	/**
	 * Marca este Sprite para destruirlo
	 */
	public void flagToDestroy() {
		destroyFlag = true;
	}
}

