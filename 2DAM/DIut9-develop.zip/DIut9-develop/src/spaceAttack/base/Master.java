package spaceAttack.base;

import java.awt.MouseInfo;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.SwingUtilities;

import spaceAttack.screen.EndScreen;
import spaceAttack.screen.GameScreen;
import spaceAttack.sprite.Asteroid;
import spaceAttack.sprite.BallBolt;
import spaceAttack.sprite.BigEnemy;
import spaceAttack.sprite.Crosshair;
import spaceAttack.sprite.Enemy;
import spaceAttack.sprite.Explosion;
import spaceAttack.sprite.LaserBolt;
import spaceAttack.sprite.Ship;

/**
*@author Sebas Lavigne
*
*/

public class Master {
	
	public static int tickCount = 0;
	
	public static final int INITIAL_ASTEROIDS = 8;
	public static final int ENEMY_SPAWN_RATE = 20;
	public static final int ENEMY_SPAWN_AMOUNT = 6;
	public static final int ENEMY_SPAWN_X = -100;
	public static final int ENEMY_SPAWN_Y = 150;
	public static final int ENEMY_SPAWN_V = 3;


	private GameScreen gameScreen;
	private Ship ship;
	private Crosshair crosshair;
	private LaserBolt laserBolt;
	private ArrayList<Asteroid> asteroids;
	private ArrayList<Explosion> explosions;
	private ArrayList<Enemy> enemies;
	private ArrayList<BallBolt> enemyBolts;
	private int endCount;
	private int endMode;
	private boolean endGame;
	private boolean endAsteroids;
	private boolean endEnemies;
	private int enemySpawnAmount;
	private boolean bigEnemy;
	private boolean endBigEnemy;
	
	/**
	 * @param gameScreen
	 */
	public Master(GameScreen gameScreen) {
		super();
		this.gameScreen = gameScreen;
		endGame = false;
		endAsteroids = false;
		endEnemies = false;
		bigEnemy = false;
		endBigEnemy = false;
	}
	
	public void initialize() {
		endCount = 0;
		enemySpawnAmount = 0;
		initializeShip();
		initializeCrosshair();
		initializeLaserBolt();
		initializeAsteroids();
		initializeExplosions();
		initializeEnemies();
		initializeEnemyBolts();
//		spawnEnemy(-100, 100, 3);
	}
	
	public void initializeShip() {
		ship = new Ship(gameScreen.getWidth() / 2 - 16, gameScreen.getHeight() - 100);
		ship.setMaster(this);
	}
	
	public void initializeCrosshair() {
		crosshair = new Crosshair(0, 0);
	}
	
	public void initializeLaserBolt() {
		laserBolt = new LaserBolt(-200, 100, 0);
	}
	
	public void initializeAsteroids() {
		asteroids = new ArrayList<>();
		for (int i = 0; i < INITIAL_ASTEROIDS; i++) {
			spawnAsteroid();
		}
	}
	
	public void initializeExplosions() {
		explosions = new ArrayList<>();
	}
	
	public void initializeEnemies() {
		enemies = new ArrayList<>();
	}
	
	public void initializeEnemyBolts() {
		enemyBolts = new ArrayList<>();
	}
	
	public void mouseClicked() {
		fireLaser();
	}
	
	/**
	 * Realiza todos los movimientos y calculos relacionados con
	 * el funcionamiento del juego
	 */
	public void tick() {
		int screenWidth = gameScreen.getWidth();
		int screenHeight = gameScreen.getHeight();
		enemySpawner();
		checkBoltCollision();
		checkShipCollision();
		steerShip();
		ship.tick();
		ship.keepInBounds(screenWidth, screenHeight);
		crosshair.tick();
		laserBolt.tick();
		laserBolt.keepInBounds(screenWidth, screenHeight);
		for (Asteroid asteroid : asteroids) {
			asteroid.tick();
			asteroid.keepInBounds(screenWidth, screenHeight);
		}
		for (BallBolt bolt : enemyBolts) {
			bolt.tick();
			bolt.keepInBounds(screenWidth, screenHeight);
		}
		for (Explosion explosion : explosions) {
			explosion.tick();
		}
		for (Enemy enemy : enemies) {
			enemy.tick();
			enemy.keepInBounds(screenWidth, screenHeight);
		}
		destroyFlagged();
		tickCount++;
		if (endGame) {
			countForEndScreen();
		}
	}
	
	public void spawnAsteroid() {
		Random rd = new Random();
		Asteroid asteroid = new Asteroid(
				rd.nextInt(gameScreen.getWidth()),
				-rd.nextInt(200),
				rd.nextInt(15) - 6,
				rd.nextInt(6) + 1
				);
		asteroids.add(asteroid);
	}
	
	public void spawnExplosion(int posX, int posY, int vX, int vY) {
		Explosion explosion = new Explosion(posX, posY, vX, vY);
		explosions.add(explosion);
	}
	
	public void spawnEnemy(int posX, int posY, int vX) {
		Enemy enemy = new Enemy(posX, posY, vX, Enemy.DEFAULT_AMPLITUDE, Enemy.DEFAULT_FREQ_MOD, this);
		enemies.add(enemy);
	}
	
	public void spawnEnemyBolt(int posX, int posY, int vX, int vY) {
		BallBolt bolt = new BallBolt(posX, posY, vX, vY);
		enemyBolts.add(bolt);
	}
	
	public void fireLaser() {
		if (!laserBolt.isFired() && !ship.isDestroyFlag()) {
			laserBolt.setPosX(ship.getPosX()+ship.getWidth()/2 - laserBolt.getWidth()/2);
			laserBolt.setPosY(ship.getPosY()+ship.getHeight()/2 - laserBolt.getHeight()/2);
			laserBolt.setvY(ship.getBoltSpeed());
			laserBolt.flagFired();
		}
	}
	
	public void steerShip() {
		Point p = MouseInfo.getPointerInfo().getLocation();
		SwingUtilities.convertPointFromScreen(p, gameScreen.getGamePanel());
		ship.setDesiredPos(p);
		crosshair.setPos(p);
	}
	
	public void checkBoltCollision() {
		for (Asteroid asteroid : asteroids) {
			if (laserBolt.collidesWithRectangular(asteroid)) {
				laserBolt.hide();
				
				asteroid.flagToDestroy();
				
			}
		}
		
		for (Enemy enemy : enemies) {
			if (laserBolt.collidesWithRectangular(enemy)) {
				spawnExplosion(laserBolt.getPosX() + laserBolt.getWidth() / 2 - 16, laserBolt.getPosY(),
						enemy.getvX() / 2, enemy.getvY() / 2);
				laserBolt.hide();
				enemy.hit();
			}
		}
	}
	
	public void checkShipCollision() {
		boolean collided = false;
		for (Asteroid asteroid : asteroids) {
			if (ship.collidesWithRectangular(asteroid)) {
				collided = true;
				ship.flagToDestroy();
				asteroid.flagToDestroy();
			}
		}
		
		for (BallBolt bolt : enemyBolts) {
			if (ship.collidesWithRectangular(bolt)) {
				collided = true;
				ship.flagToDestroy();
				bolt.flagToDestroy();
			}
		}
		
		for (Enemy enemy : enemies) {
			if (ship.collidesWithRectangular(enemy)) {
				collided = true;
				ship.flagToDestroy();
				if (enemy instanceof BigEnemy) {
//					((BigEnemy) enemy).setFlyMode(BigEnemy.DESTROY_MODE);
				} else {
					enemy.flagToDestroy();
				}
					
			}
		}
		
		if (collided) {
			setEndGame(EndScreen.MODE_DEFEAT);
		}
	}
	
	public void enemySpawner() {
		if (tickCount % ENEMY_SPAWN_RATE == 0 && enemySpawnAmount > 0) {
			enemySpawnAmount--;
			spawnEnemy(ENEMY_SPAWN_X, ENEMY_SPAWN_Y, ENEMY_SPAWN_V);
		}
		
		if (!bigEnemy && endEnemies) {
			bigEnemy = true;
			enemies.add(new BigEnemy(gameScreen.getWidth() / 2 - 64, -200, 0, 0, 0, this));
		}
	}
	
	
	public void countForEndScreen() {
		if (tickCount >= endCount) {
			gameScreen.launchEndScreen(endMode);
		}
	}
	
	public void destroyFlagged() {
		for (int i = 0; i < asteroids.size(); i++) {
			if (asteroids.get(i).isDestroyFlag()) {
				spawnExplosion(asteroids.get(i).getPosX(), asteroids.get(i).getPosY(),
						asteroids.get(i).getvX() / 2, asteroids.get(i).getvY() / 2);
				asteroids.remove(i);
			}
		}
		
		//Chequea el fin de los enemigos
		if (!endGame && endEnemies && endBigEnemy) {
			setEndGame(EndScreen.MODE_VICTORY);
		}
		
		if (endAsteroids && enemySpawnAmount == 0 && enemies.isEmpty()) {
			endEnemies = true;
		}
		
		 //Chequea el fin de los asteroides
		if (!endAsteroids && asteroids.isEmpty()) {
			endAsteroids = true;
			enemySpawnAmount = ENEMY_SPAWN_AMOUNT;
		}
		
		for (int i = 0; i < enemyBolts.size(); i++) {
			if (enemyBolts.get(i).isDestroyFlag()) {
				enemyBolts.remove(i);
			}
		}
		
		for (int i = 0; i < enemies.size(); i++) {
			if (enemies.get(i).isDestroyFlag()) {
				if (enemies.get(i) instanceof BigEnemy) {
					endBigEnemy = true;
				} else {
					spawnExplosion(enemies.get(i).getPosX(), enemies.get(i).getPosY(),
							enemies.get(i).getvX() / 2, enemies.get(i).getvY() / 2);
					enemies.remove(i);
				}
			}
		}
		
		for (int i = 0; i < explosions.size(); i++) {
			if (explosions.get(i).isDestroyFlag()) {
				explosions.remove(i);
			}
		}
	}

	/**
	 * 
	 */
	private void setEndGame(int mode) {
		if (!endGame) {
			endCount = tickCount + 3000/GamePanel.REFRESH_PERIOD;
			endMode = mode;
			endGame = true;
			gameScreen.freezeTimer();
		}
	}

	/**
	 * @return the ship
	 */
	public Ship getShip() {
		return ship;
	}

	/**
	 * @return the laserBolt
	 */
	public LaserBolt getLaserBolt() {
		return laserBolt;
	}

	/**
	 * @return the asteroids
	 */
	public ArrayList<Asteroid> getAsteroids() {
		return asteroids;
	}

	/**
	 * @return the explosions
	 */
	public ArrayList<Explosion> getExplosions() {
		return explosions;
	}

	/**
	 * @return the crosshair
	 */
	public Crosshair getCrosshair() {
		return crosshair;
	}

	/**
	 * @return the enemies
	 */
	public ArrayList<Enemy> getEnemies() {
		return enemies;
	}

	/**
	 * @return the enemyBolts
	 */
	public ArrayList<BallBolt> getEnemyBolts() {
		return enemyBolts;
	}

	
	
}

