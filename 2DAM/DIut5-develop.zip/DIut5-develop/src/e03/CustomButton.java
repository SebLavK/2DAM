package e03;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
//import javax.swing.JColorChooser;
import javax.swing.JPanel;

/**
*@author Sebas Lavigne
*/

public class CustomButton extends JButton implements MouseListener {
	
	private static final long serialVersionUID = 1L;
	
	public static Color currentColor = Color.BLACK;
	
	private JPanel panelLink;
	
	/**
	 * Al crear un boton propio le queda asignado un panel
	 * al que cambiara el color en cuanto se pulse el boton
	 * @param panelLink el panel al que esta relacionado
	 * @param i la fila
	 * @param j la columna
	 */
	public CustomButton(JPanel panelLink, int i, int j) {
		super(i+"-"+j);
		this.panelLink = panelLink;
		
		//A ESTE boton se le anade un MouseListener definido en ESTA clase
		this.addMouseListener(this);
	}
	
	/**
	 * Lanza un dialogo para elegir un color
	 * El color por defecto es el color elegido actualmente
	 * Si el usuario cancela se mantiene el color anterior
	 * @param posx la posicion x en la que abrir el dialogo
	 * @param posy la posicion y en la que abrir el dialogo
	 */
	public void selectColor(int posx, int posy) {
//		Color newColor = JColorChooser.showDialog(this, "Elige un color", currentColor);
//		currentColor = (newColor != null? newColor : currentColor);
		new DialogColorSelector(posx, posy);
	}
	

	/**
	 * Distingue entre el boton izquierdo y el boton derecho del raton
	 * El izquierdo pinta un panel del color actual
	 * El derecho lanza selectColor()
	 */
	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			paintPanel();
		} else if (e.getButton() == MouseEvent.BUTTON3) {
			
			selectColor(e.getXOnScreen(), e.getYOnScreen());
		}
		
	}

	/**
	 * Pinta el panel asociado del color actual
	 */
	public void paintPanel() {
		panelLink.setBackground(currentColor);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		
	}


}
