package e03;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;


/**
*@author Sebas Lavigne
*
*/

public class DialogColorSelector extends JDialog {

	private static final long serialVersionUID = 1L;
	
	public static final int DIALOG_WIDTH = 400;
	public static final int DIALOG_HEIGHT = 600;
	
	private Color selectedColor;
	private int valueRed, valueGreen, valueBlue;
	
	private GridBagConstraints settings;
	private JLabel lTitle, lRed, lGreen, lBlue;
	private JSlider sliderRed, sliderGreen, sliderBlue;
	private JTextField tfRed, tfGreen, tfBlue;
	private JPanel panelRed, panelGreen, panelBlue, panelColor;
	private JButton bDone;
	
	public DialogColorSelector(int posx, int posy) {
		super();
		setModal(true);
		//Se abre el dialogo con centro en la ubicacion del cursor
		setBounds(posx - DIALOG_WIDTH / 2,
				posy - DIALOG_HEIGHT/ 2,
				DIALOG_WIDTH,DIALOG_HEIGHT);
		
		addElements();
		initializeControls();
		addListeners();
		setVisible(true);
	}
	
	private void addElements() {
		this.setLayout(new GridBagLayout());
		
		/* Label titulo */
		lTitle = new JLabel("Selecciona color");
			lTitle.setHorizontalAlignment(SwingConstants.HORIZONTAL);
		
		settings = new GridBagConstraints();
		settings.gridy = 0;
		settings.insets = new Insets(20, 0, 0, 0);
		settings.fill = GridBagConstraints.BOTH;
		this.add(lTitle, settings);
		
		/* Paneles con label, slider y textField para cada color */
		GridBagConstraints settingsLabel = new GridBagConstraints();
		GridBagConstraints settingsSlider = new GridBagConstraints();
		GridBagConstraints settingsTextField = new GridBagConstraints();
		
		settingsLabel.gridy = 0;
		settingsSlider.gridy = 1;
		settingsTextField.gridy = 2;
		
		
		//ROJO
		panelRed = new JPanel(new GridBagLayout());
		
		settings = new GridBagConstraints();
		settings.gridy = 1;
		settings.insets = new Insets(20, 0, 20, 0);
		this.add(panelRed, settings);
		
		lRed = new JLabel("Rojo");
		sliderRed = new JSlider(SwingConstants.HORIZONTAL, 0, 255, 0);
			sliderRed.setMinorTickSpacing(16);
			sliderRed.setMajorTickSpacing(255);
			sliderRed.setPaintTicks(true);
			sliderRed.setPaintLabels(true);
		tfRed = new JTextField("0",5);
			tfRed.setHorizontalAlignment(SwingConstants.HORIZONTAL);
		panelRed.add(lRed, settingsLabel);
		panelRed.add(sliderRed, settingsSlider);
		panelRed.add(tfRed, settingsTextField);
		
		//VERDE
		panelGreen = new JPanel(new GridBagLayout());
		
		settings = new GridBagConstraints();
		settings.gridy = 2;
		settings.insets = new Insets(20, 0, 20, 0);
		this.add(panelGreen, settings);
		
		lGreen = new JLabel("Verde");
		sliderGreen = new JSlider(SwingConstants.HORIZONTAL, 0, 255, 0);
			sliderGreen.setMinorTickSpacing(16);
			sliderGreen.setMajorTickSpacing(255);
			sliderGreen.setPaintTicks(true);
			sliderGreen.setPaintLabels(true);
		tfGreen = new JTextField("0",5);
			tfGreen.setHorizontalAlignment(SwingConstants.HORIZONTAL);
		panelGreen.add(lGreen, settingsLabel);
		panelGreen.add(sliderGreen, settingsSlider);
		panelGreen.add(tfGreen, settingsTextField);
		
		//AZUL
		panelBlue = new JPanel(new GridBagLayout());
		
		settings = new GridBagConstraints();
		settings.gridy = 3;
		settings.insets = new Insets(20, 0, 20, 0);
		this.add(panelBlue, settings);
		
		lBlue = new JLabel("Azul");
		sliderBlue = new JSlider(SwingConstants.HORIZONTAL, 0, 255, 0);
			sliderBlue.setMinorTickSpacing(16);
			sliderBlue.setMajorTickSpacing(255);
			sliderBlue.setPaintTicks(true);
			sliderBlue.setPaintLabels(true);
		tfBlue = new JTextField("0",5);
			tfBlue.setHorizontalAlignment(SwingConstants.HORIZONTAL);
		panelBlue.add(lBlue, settingsLabel);
		panelBlue.add(sliderBlue, settingsSlider);
		panelBlue.add(tfBlue, settingsTextField);
		
		/* Color elegido */
		
		panelColor = new JPanel();
			panelColor.setBackground(Color.RED);
			panelColor.setBorder(new LineBorder(Color.BLACK));
		
		settings = new GridBagConstraints();
		settings.gridy = 4;
		settings.ipadx = 200;
		settings.ipady = 40;
		settings.insets = new Insets(20, 0, 20, 0);
		this.add(panelColor, settings);
		
		/* Boton */
		bDone = new JButton("Seleccionar");
		
		settings = new GridBagConstraints();
		settings.gridy = 5;
		settings.ipadx = 40;
		settings.insets = new Insets(0, 0, 20, 0);
		this.add(bDone, settings);
	}
	
	/**
	 * Inicializa los controles del dialogo con los valores del color con el que
	 * se esta trabajando en la ventana principal
	 */
	private void initializeControls() {
		Color c = CustomButton.currentColor;
		
		valueRed = c.getRed();
		valueGreen = c.getGreen();
		valueBlue = c.getBlue();
		
		updateColor();
		updateSliders();
		updateTextFields();
	}
	
	private void addListeners() {
		/* Listeners de los Sliders */
		sliderRed.addChangeListener(e -> onSliderChange(e));
		sliderGreen.addChangeListener(e -> onSliderChange(e));
		sliderBlue.addChangeListener(e -> onSliderChange(e));
		
		/*
		 * Listeners de los TextField
		 * Se declara un DocumentListener comun para todos ellos
		 * Solo se lanza onTextFieldChange si uno de los textfield tiene el foco
		 * De lo contrario, tambien se lanzan cuando se actualizan los Slider y el 
		 * programa da fallos
		 */
		DocumentListener textFieldListener = new DocumentListener() {
			@Override
			public void removeUpdate(DocumentEvent e) {
				if (tfRed.hasFocus() || tfGreen.hasFocus() || tfBlue.hasFocus()) {
					onTextFieldChange();
				}
			}
			@Override
			public void insertUpdate(DocumentEvent e) {
				if (tfRed.hasFocus() || tfGreen.hasFocus() || tfBlue.hasFocus()) {
					onTextFieldChange();
				}
			}
			@Override
			public void changedUpdate(DocumentEvent e) {
				if (tfRed.hasFocus() || tfGreen.hasFocus() || tfBlue.hasFocus()) {
					onTextFieldChange();
				}
			}
		};
		
		tfRed.getDocument().addDocumentListener(textFieldListener);
		tfGreen.getDocument().addDocumentListener(textFieldListener);
		tfBlue.getDocument().addDocumentListener(textFieldListener);
		
		/* Listener del boton "Seleccionar" */
		bDone.addActionListener(e -> onDoneAction());
	}
	
	/**
	 * Asigna un color nuevo en base a los valores guardados
	 */
	private void updateColor() {
		selectedColor = new Color(valueRed, valueGreen, valueBlue);
		panelColor.setBackground(selectedColor);
	}
	
	/**
	 * Actualiza la posicion de los Sliders en base a los valores guardados
	 */
	private void updateSliders() {
		sliderRed.setValue(valueRed);
		sliderGreen.setValue(valueGreen);
		sliderBlue.setValue(valueBlue);
	}
	
	/**
	 * Actualiza los TextField en base a los valores guardados
	 */
	private void updateTextFields() {
		tfRed.setText(Integer.toString(valueRed));
		tfGreen.setText(Integer.toString(valueGreen));
		tfBlue.setText(Integer.toString(valueBlue));
	}
	
	/**
	 * Se lanza para todos los cambios en los Slider
	 * Guarda los valores, actualiza los TextField y el color
	 * Solo funciona si el Slider tiene el foco para evitar que
	 * se ejecute al cambiar un TextField
	 */
	private void onSliderChange(ChangeEvent e) {
		JSlider slider = (JSlider) e.getSource();
		if (slider.hasFocus()) {
			valueRed = sliderRed.getValue();
			valueGreen = sliderGreen.getValue();
			valueBlue = sliderBlue.getValue();
			
			updateTextFields();
			updateColor();
		}
	}
	
	/**
	 * Se lanza para todos los cambios en los TextField
	 * Guarda los valores, actualiza los Slider y el color
	 */
	private void onTextFieldChange() {
		try {
			valueRed = Integer.parseInt(tfRed.getText());
			valueGreen = Integer.parseInt(tfGreen.getText());
			valueBlue = Integer.parseInt(tfBlue.getText());
			
			valueRed %= 256;
			valueGreen %= 256;
			valueBlue %= 256;
			
			updateSliders();
			updateColor();
		} catch(NumberFormatException e) {
			//Nothing
		}
	}
	
	private void onDoneAction() {
		CustomButton.currentColor = selectedColor;
		this.dispose();
	}
}

