package e04;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {
	
	private JFrame window;
	
	private Chronometer chrono;
	private JButton bStart, bPause, bReset;
	
	public MainWindow() {
		window = new JFrame("Ejercicio 04");
		window.setBounds(200, 200, 300, 150);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void initializeComponents() {
		window.setLayout(new GridBagLayout());
		GridBagConstraints settings;
		
		/* Cronometro */
		chrono = new Chronometer();
		
		settings = new GridBagConstraints();
		settings.fill = GridBagConstraints.BOTH;
		settings.weightx = 1;
		settings.weighty = 3;
		settings.gridwidth = 3;
		
		window.add(chrono, settings);
		
		/* Botones */
		//Empezar
		bStart = new JButton("Empezar");
		
		settings = new GridBagConstraints();
		settings.gridx = 0;
		settings.gridy = 1;
		settings.weightx = 1;
		settings.fill = GridBagConstraints.BOTH;
		
		window.add(bStart, settings);
		
		//Parar
		bPause = new JButton("Parar");
		
		settings = new GridBagConstraints();
		settings.gridx = 1;
		settings.gridy = 1;
		settings.weightx = 1;
		settings.fill = GridBagConstraints.BOTH;
		
		window.add(bPause, settings);
		
		//Resetear
		bReset = new JButton("Resetear");
		
		settings = new GridBagConstraints();
		settings.gridx = 2;
		settings.gridy = 1;
		settings.weightx = 1;
		settings.fill = GridBagConstraints.BOTH;
		
		window.add(bReset, settings);
		
	}
	
	public void initializeListeners() {
		bStart.addActionListener(e -> chrono.startTimer());
		bPause.addActionListener(e -> chrono.pauseTimer());
		bReset.addActionListener(e -> chrono.resetTimer());
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}

}

