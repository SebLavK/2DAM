package e04;

import java.awt.EventQueue;

/**
*@author Sebas Lavigne
*
*/

public class Main {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				try {
					MainWindow window = new MainWindow();
					window.initialize();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}

