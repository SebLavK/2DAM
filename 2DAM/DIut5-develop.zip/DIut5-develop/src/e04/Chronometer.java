package e04;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

/**
*@author Sebas Lavigne
*
*/

public class Chronometer extends JPanel {
	
	private static final long serialVersionUID = 1L;

	public static final int REFRESH_RATE = 10;

	private JLabel lTimerDisplay;
	private Timer timer;
	private long startTime;
	private long elapsedTime;
	
	public Chronometer() {
		super();
		
		initializeTimer();
		
		this.setLayout(new GridLayout(1, 1));
		this.setBackground(Color.BLACK);
		
		lTimerDisplay = new JLabel("00 : 00 . 000");
			lTimerDisplay.setHorizontalAlignment(SwingConstants.CENTER);
			lTimerDisplay.setForeground(Color.WHITE);
			Font font = new Font("Segoe UI", Font.PLAIN, 30);
			String fonts[] = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
			for (String string : fonts) {
				System.out.println(string);
			}
			lTimerDisplay.setFont(font);
		this.add(lTimerDisplay);
	}
	
	/**
	 * Lanza el contador.
	 * Si el cronometro ya tenia tiempo, continua desde ahi
	 */
	public void startTimer() {
		if (elapsedTime == 0) {
			startTime = System.nanoTime();
		} else {
			startTime = System.nanoTime() - elapsedTime;
		}
		timer.start();
	}
	
	/**
	 * Pausa el cronometro
	 */
	public void pauseTimer() {
		timer.stop();
	}
	
	/**
	 * Pausa el cronometro y lo pone a cero
	 */
	public void resetTimer() {
		timer.stop();
		startTime = System.nanoTime();
		tickTimer();
	}
	
	/**
	 * Cada tick del cronometro, actualiza el tiempo transcurrido
	 * y lo muestra en el Label.
	 */
	private void tickTimer() {
		elapsedTime = System.nanoTime() - startTime;
		
		LocalTime time = LocalTime.of(0, 0).plus(Duration.of(elapsedTime, ChronoUnit.NANOS));
		lTimerDisplay.setText(time.format(DateTimeFormatter.ofPattern("mm : ss . SSS")));
	}
	
	/**
	 * Inicializa el Timer, cada REFRESH_RATE milisegundos
	 * llama a tickTimer para actualizar el tiempo
	 */
	private void initializeTimer() {
		timer = new Timer(REFRESH_RATE, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				tickTimer();
			}
		});
	}

	/**
	 * Devuelve el Label con el contador para editar sus
	 * propiedades
	 * @return the lTimerDisplay
	 */
	public JLabel getlTimerDisplay() {
		return lTimerDisplay;
	}

}

