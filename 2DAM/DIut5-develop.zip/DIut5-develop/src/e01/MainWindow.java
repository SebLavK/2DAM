package e01;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
*@author Sebas Lavigne
*
*/

public class MainWindow {
	
	private JFrame window;
	
	private JPanel panelGrey;
	private JPanel panelCyan;
	
	private JPanel[][] panelColors;
	private JButton[][] buttonSelectors;
	
	
	
	public MainWindow() {
		window = new JFrame("Ejercicio 01");
		window.setBounds(100,100,900,500);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	/**
	 * Inicializa componentes
	 */
	public void initializeComponents() {
		window.setLayout(new GridBagLayout());
		GridBagConstraints settings;
		
		//Panel gris
		panelGrey = new JPanel();
		panelGrey.setLayout(new GridLayout(4,4));
		panelGrey.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
		panelGrey.setBackground(Color.GRAY);
		
		settings = new GridBagConstraints();
		settings.gridx = 0;
		settings.gridy = 0;
		settings.weightx = 10;
		settings.weighty = 1;
		settings.fill = GridBagConstraints.BOTH;
		
		window.add(panelGrey,settings);
		
		//Panel cyan
		panelCyan = new JPanel();
		panelCyan.setLayout(new GridLayout(4, 4));
		panelCyan.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createEmptyBorder(80, 30, 80, 30), 
				BorderFactory.createTitledBorder("Pintar área")));
		panelCyan.setBackground(Color.CYAN);
		
		settings = new GridBagConstraints();
		settings.gridx = 1;
		settings.gridy = 0;
		settings.weightx = 1;
		settings.weighty = 1;
		settings.fill = GridBagConstraints.BOTH;
		
		window.add(panelCyan,settings);
		
		//Paneles del panel gris
		panelColors = new JPanel[4][4];
		for (int i = 0; i < panelColors.length; i++) {
			for (int j = 0; j < panelColors[0].length; j++) {
				panelColors[i][j] = new JPanel();
				panelColors[i][j].setBorder(BorderFactory.createLineBorder(Color.BLACK));
				panelGrey.add(panelColors[i][j]);
			}
		}
		
		//Botones del panel cyan
		buttonSelectors = new JButton[4][4];
		for (int i = 0; i < buttonSelectors.length; i++) {
			for (int j = 0; j < buttonSelectors[0].length; j++) {
				buttonSelectors[i][j] = new CustomButton(panelColors[i][j], i, j);
				/*
				 * Para cambiar el texto del botón en cursiva se le establece una fuente
				 * igual que la que ya tiene, con estilo ITALIC
				 */
				buttonSelectors[i][j].setFont(new Font(
						buttonSelectors[i][j].getFont().getName(),
						Font.ITALIC,
						buttonSelectors[i][j].getFont().getSize()));
				panelCyan.add(buttonSelectors[i][j]);
			}
		}
	}
	
	/**
	 * Cada CustomButton tiene su propio listener, por lo tanto no hace falta inicializar nada aqui
	 */
	public void initializeListeners() {
		
	}
	
	public void initialize() {
		window.setVisible(true);
		initializeComponents();
		initializeListeners();
	}
}

