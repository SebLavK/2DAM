package e01;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

/**
*@author Sebas Lavigne
*/

public class CustomButton extends JButton implements ActionListener {
	
	private static final long serialVersionUID = 1L;
	
	private JPanel panelLink;
	
	/**
	 * Al crear un boton propio le queda asignado un panel
	 * al que cambiara el color en cuanto se pulse el boton
	 * @param panelLink el panel al que esta relacionado
	 * @param i la fila
	 * @param j la columna
	 */
	public CustomButton(JPanel panelLink, int i, int j) {
		super(i+"-"+j);
		this.panelLink = panelLink;
		
		//A ESTE boton se le anade un ActionListener definido en ESTA clase
		this.addActionListener(this);
	}

	/**
	 * Simplemente se establece el color del panel relacionado a negro
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		panelLink.setBackground(Color.BLACK);
	}

}
