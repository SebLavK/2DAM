package main;

import java.util.ArrayList;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import jdbc.SessionFactoryUtil;
import menu.Menu;
import queries.Queries;

/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static final String[] MENU_ITEMS = {
			"Datos del departamento 20 y sus empleados",
			"Empleado con mayor salario del dpto VENTAS",
			"Salario medio de los empleados del dpto de Barcelona",
			"Empleados que empezaron a trabajar en 2005",
			"Numero de empleados del dpto VENTAS"
	};
	
	
	public static void main(String[] args) {
		SessionFactory sf = SessionFactoryUtil.getSessionFactory();
		Session session = sf.openSession();
		
		boolean done = false;
		while (!done) {
			switch(Menu.generateMenu(MENU_ITEMS, true, "Consultas")) {
			case -1:
				done = true;
				System.out.println("Saliendo del programa");
				break;
			case 0:
				Queries.getDepartamentosAndEmpleadosFromDep(session, 20);
				break;
			case 1:
				Queries.getTopBillingEmpleadoFromDep(session, "VENTAS");
				break;
			case 2:
				Queries.getAvgWagesFromDep(session, "Barcelona");
				break;
			case 3:
				Queries.getEmpleadosSince(session, 2005);
				break;
			case 4:
				Queries.getEmpleadoCountFromDep(session, "VENTAS");
				break;
			}
			System.out.println("\nPulsa INTRO para continuar");
			new Scanner(System.in).nextLine();
		}
		
		
		session.close();
		sf.close();
	}

}

