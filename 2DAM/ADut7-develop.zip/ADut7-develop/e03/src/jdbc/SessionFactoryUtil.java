package jdbc;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

/**
*@author Sebas Lavigne
*
*/

public class SessionFactoryUtil {
	
	private SessionFactoryUtil() {}

	private static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory() {
		try {
			if (sessionFactory == null) {
				//Carga la configuracion
				Configuration config = new Configuration().configure("hibernate.cfg.xml");
				StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
						.applySettings(config.getProperties());
				//Crea una sesion con la configuracion
				sessionFactory = config.buildSessionFactory(builder.build());
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return sessionFactory;
	}
	
}

