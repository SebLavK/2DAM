package queries;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import jdbc.Departamentos;
import jdbc.Empleados;

/**
*@author Sebas Lavigne
*
*/

public class Queries {
	
	public static void getDepartamentosAndEmpleadosFromDep(Session session, int depNum) {
		Query q = session.createQuery("from Departamentos as d"
				+ " where d.deptNo = :depNum");
		q.setParameter("depNum", depNum);
		
		Departamentos dep = (Departamentos) q.uniqueResult();
		
		Iterator<Empleados> it = dep.getEmpleadoses().iterator();
		Empleados emp;
		System.out.println("Datos del departamento " + depNum + ":");
		System.out.println(dep);
		System.out.println("Empleados:");
		while(it.hasNext()) {
			emp = (Empleados) it.next();
			System.out.println("\t"+emp.getApellido());
		}
	}
	
	public static void getTopBillingEmpleadoFromDep(Session session, String depName) {
		Query q = session.createQuery("from Empleados as e "
				+ "where e.salario in (select max(salario) from Empleados where departamentos.dnombre = :depName) "
				+ "and e.departamentos.dnombre = :depName");
		q.setParameter("depName", depName);
		List<Empleados> list = q.list();
		Iterator<Empleados> it = list.iterator();
		Empleados emp;
		System.out.println("Empleados con mayor salario del departamento " + depName);
		while (it.hasNext()) {
			emp = it.next();
			System.out.println(emp);
		}
	}
	
	public static void getAvgWagesFromDep(Session session, String depLoc) {
		Query q = session.createQuery("select avg(salario) from Empleados where departamentos.loc = :depLoc");
		q.setParameter("depLoc", depLoc);
		double avg = (double) q.uniqueResult();
		System.out.println("Salario medio del departamento en " + depLoc + ": " + avg);
	}
	
	public static void getEmpleadosSince(Session session, int year) {
		Query q = session.createQuery("from Empleados where year(fechaAlt) = :year");
		q.setParameter("year", year);
		List<Empleados> list = q.list();
		Iterator<Empleados> it = list.iterator();
		System.out.println("Empleados dados de alta en el anyo " + year);
		while (it.hasNext()) {
			Empleados empleados = (Empleados) it.next();
			System.out.println(empleados);
		}
	}
	
	public static void getEmpleadoCountFromDep(Session session, String depName) {
		Query q = session.createQuery("select empleadoses.size from Departamentos where dnombre = :depName");
		q.setParameter("depName", depName);
		int size = (int) q.uniqueResult();
		System.out.println("Numero de empleados del departamento " + depName + ": "+size);
	}

}

