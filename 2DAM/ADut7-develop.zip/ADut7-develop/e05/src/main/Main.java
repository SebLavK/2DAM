package main;

import java.util.ArrayList;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import jdbc.SessionFactoryUtil;
import menu.Menu;
import queries.Queries;

/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static final String[] MENU_ITEMS = {
			"Productos con existencias menores a 2",
			"Clientes de Extremadura",
			"Producto mas caro",
			"Productos con mayor y menor existencias",
			"Total de ventas en mes de noviembre",
			"Total de ventas de cada cliente",
			"Cliente que mas dinero gsato en noviembre",
			"Producto mas vendido y su cantidad"
	};
	
	public static void main(String[] args) {
		SessionFactory sf = SessionFactoryUtil.getSessionFactory();
		Session session = sf.openSession();
		
		boolean done = false;
		while (!done) {
			switch(Menu.generateMenu(MENU_ITEMS, true, "Consultas")) {
			case -1:
				done = true;
				System.out.println("Saliendo del programa");
				break;
			case 0:
				Queries.getProductosStockLessThan(session, 2);
				break;
			case 1:
				ArrayList<String> poblaciones = new ArrayList<>();
				poblaciones.add("caceres");
				poblaciones.add("badajoz");
				Queries.getClientesFrom(session, poblaciones);
				break;
			case 2:
				Queries.getMostExpensiveProducto(session);
				break;
			case 3:
				Queries.getLeastAndMostStockedProducto(session);
				break;
			case 4:
				Queries.getSalesFromMonth(session, 11);
				break;
			case 5:
				Queries.getSumSalesForClientes(session);
				break;
			case 6:
				Queries.getClienteMostSpenditureInMonth(session, 11);
				break;
			case 7:
				Queries.getMostSoldProducto(session);
				break;
			}
			System.out.println("\nPulsa INTRO para continuar");
			new Scanner(System.in).nextLine();
		}
		
		
		session.close();
		sf.close();
	}

}

