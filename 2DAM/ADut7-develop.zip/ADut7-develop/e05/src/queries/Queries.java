package queries;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import jdbc.Clientes;
import jdbc.Productos;

/**
*@author Sebas Lavigne
*
*/

public class Queries {
	
	/**
	 * Mostrar aquellos productos cuyas existencias seán menores de 2
	 * @param session
	 * @param stock
	 */
	public static void getProductosStockLessThan(Session session, int stock) {
		Query q = session.createQuery("from Productos where existencias < :stock");
		q.setParameter("stock", stock);
		Iterator<Productos> it = q.list().iterator();
		System.out.println("Productos con existencias menores a " + stock);
		while (it.hasNext()) {
			Productos p = (Productos) it.next();
			System.out.println(p);
		}
	}
	
	/**
	 * Mostrar aquellos clientes que sean de Extremadura
	 * @param session
	 * @param poblaciones
	 */
	public static void getClientesFrom(Session session, ArrayList<String> poblaciones) {
		Query q = session.createQuery("from Clientes where poblacion in (:poblaciones)");
		//setParameterList permite anadir varios parametros a partir de una coleccion
		q.setParameterList("poblaciones", poblaciones);
		Iterator<Clientes> it = q.list().iterator();
		System.out.println("Clientes procedentes de " + poblaciones);
		while (it.hasNext()) {
			Clientes c = (Clientes) it.next();
			System.out.println(c);
		}
	}
	
	/**
	 * Mostrar el producto más caro
	 * @param session
	 */
	public static void getMostExpensiveProducto(Session session) {
		Query q = session.createQuery("from Productos where precio in "
				+ "(select max(precio) from Productos)");
		Iterator<Productos> it = q.list().iterator();
		System.out.println("Producto o productos mas caros:");
		while (it.hasNext()) {
			Productos p = (Productos) it.next();
			System.out.println(p);
		}
	}
	
	/**
	 * Mostrar el producto con mayor y menor existencias
	 * @param session
	 */
	public static void getLeastAndMostStockedProducto(Session session) {
		Query q = session.createQuery("from Productos\r\n" + 
				"where existencias = \r\n" + 
				"	(select min(existencias) from Productos)\r\n" + 
				"or existencias =\r\n" + 
				"	(select max(existencias) from Productos)");
		Iterator<Productos> it = q.list().iterator();
		System.out.println("Productos con mayor y menor existencias");
		while (it.hasNext()) {
			Productos p = (Productos) it.next();
			System.out.println(p);
		}
	}
	
	/**
	 * Mostrar el total de ventas del mes de noviembre
	 * @param session
	 * @param monthNum
	 */
	public static void getSalesFromMonth(Session session, int monthNum) {
		Query q = session.createQuery("select sum(productos.precio * v.cantidad) from Ventas as v\r\n" + 
				"where month(fechaventa) = :monthNum");
		q.setParameter("monthNum", monthNum);
		//Al parecer, el producto de la consulta no es float ni double, es un BigDecimal
		BigDecimal sales = (BigDecimal) q.uniqueResult();
		System.out.println("Ventas realizadas en el mes "+monthNum+": "+sales);
	}
	
	/**
	 * Mostrar el total de ventas de cada cliente
	 * @param session
	 */
	public static void getSumSalesForClientes(Session session) {
		Query q = session.createQuery("select v.clientes, sum(v.productos.precio * v.cantidad)\r\n" + 
				"from Ventas v\r\n" + 
				"group by v.clientes");
		//Cada objecto se compone de {Clientes, double}
		List<Object[]> list = q.list();
		System.out.println("Ventas totales de cada cliente:");
		for (Object[] objects : list) {
			//Muestra el cliente
			System.out.println(objects[0]);
			//Muestra las ventas totales
			System.out.println("\tVentas totales:"+objects[1]);
		}
		
	}
	
	/**
	 * Mostrar el cliente que más dinero se haya gastado en el mes de noviembre
	 * @param session
	 * @param monthNum
	 */
	public static void getClienteMostSpenditureInMonth(Session session, int monthNum) {
		Query q = session.createQuery("select v.clientes, sum(v.productos.precio * v.cantidad) as total\r\n" + 
				"from Ventas v\r\n" + 
				"where month(fechaVenta) = :monthNum\r\n" + 
				"group by v.clientes\r\n" + 
				"order by total desc");
		q.setParameter("monthNum", monthNum);
		//Equivalente a LIMIT 1
		q.setMaxResults(1);
		//Cada objecto se compone de {Clientes, double}
		List<Object[]> list = q.list();
		System.out.println("Cliente que mas gasto en el mes "+monthNum);
		for (Object[] objects : list) {
			//Muestra el cliente
			System.out.println(objects[0]);
			//Muestra las ventas totales
			System.out.println("\tTotal gastado: "+objects[1]);
		}
	}
	
	/**
	 * Mostrar el producto más vendido (muestra también la cantidad vendida)
	 * @param session
	 */
	public static void getMostSoldProducto(Session session) {
		Query q = session.createQuery("select v.productos, sum(v.cantidad) as total\r\n" + 
				"from Ventas v\r\n" + 
				"group by v.productos\r\n" + 
				"order by total desc");
		//Equivalente a LIMIT 1
		q.setMaxResults(1);
		//Cada objeto se compone de {Productos, int}
		List<Object[]> list = q.list();
		System.out.println("Producto mas vendido:");
		for (Object[] objects : list) {
			//Muestra el cliente
			System.out.println(objects[0]);
			//Muestra las ventas totales
			System.out.println("\tCantidad total vendida: "+objects[1]);
		}
	}

}

