# -*- coding: utf-8 -*-

import src.main.manager as manager

manager.select_main_menu()




# result_set = query.query_components()
#
# items = list()
# for result in result_set:
#     items.append(result[2])
# menu.generate_menu(items, False, "Componentes")
