# -*- coding: utf-8 -*-
class Product:
    def __init__(self, code, quantity, description):
        self.code = code
        self.quantity = quantity
        self.description = description
