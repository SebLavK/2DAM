# -*- coding: utf-8 -*-
class Relation:
    def __init__(self, product, component, quantity):
        self.product = product
        self.component = component
        self.quantity = quantity