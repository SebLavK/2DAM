# -*- coding: utf-8 -*-
class Component:
    def __iadd__(self, code, quantity, description):
        self.code = code
        self.quantity = quantity
        self.description = description