# -*- coding: utf-8 -*-
class Transfer:
    def __init__(self, cod_prod, quantity):
        self.cod_prod = cod_prod
        self.quantity = quantity