# -*- coding: utf-8 -*-
import src.main.connection as connection

"""Consultas a la base de datos

"""


def query_components():
    db = connection.get_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM component")
    result_set = list(cursor.fetchall())

    return result_set


def query_component(code):
    db = connection.get_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM component WHERE code = %s", (code,))
    result_set = list(cursor.fetchall())

    return result_set


def query_products():
    db = connection.get_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM product")
    result_set = list(cursor.fetchall())

    return result_set


def query_product(code):
    db = connection.get_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM product WHERE code = %s", (code,))
    result_set = list(cursor.fetchall())

    return result_set


def query_relations():
    db = connection.get_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM component_product")
    result_set = list(cursor.fetchall())

    return result_set


def query_relation(cod_prod):
    db = connection.get_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM component_product WHERE cod_prod = %s", (cod_prod,))
    result_set = list(cursor.fetchall())

    return result_set


def query_transfers():
    db = connection.get_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM transfer")
    result_set = list(cursor.fetchall())

    return result_set


def query_transfer(cod_transfer):
    db = connection.get_connection()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM transfer WHERE cod_transfer = %s", (cod_transfer,))
    result_set = list(cursor.fetchall())

    return result_set
