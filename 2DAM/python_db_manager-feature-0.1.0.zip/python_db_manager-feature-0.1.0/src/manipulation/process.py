# -*- coding: utf-8 -*-
import src.main.connection as connection
import src.manipulation.query as query

"""Procesamiento de productos
Realiza modificaciones en las tablas para crear un producto
a partir de los componentes necesarios

Author: Sebas Lavigne
"""


def make_transfer(cod_prod, amount):
    db = connection.get_connection()

    # Obtiene cantidades necesarias para un producto
    relation_set = query.query_relation(cod_prod)

    # Verifica que haya suficientes unidades
    enough_components = True
    for i in range(int(amount)):
        for item in relation_set:
            cod_comp = item[1]
            quantity = item[2]

            cursor = db.cursor()
            cursor.execute("SELECT quantity FROM component WHERE code = %s",
                                       (cod_comp,))
            available = list(cursor.fetchall())
            if int(quantity) * int(amount) > int(available[0][0]):
                enough_components = False

    # Resta cantidades a los componentes y suma productos
    if enough_components:
        for i in range(int(amount)):
            for item in relation_set:
                cod_comp = item[1]
                quantity = item[2]

                cursor = db.cursor()
                cursor.execute("UPDATE component SET quantity = quantity - %s WHERE code = %s",
                               (str(quantity), cod_comp))
            cursor = db.cursor()
            cursor.execute("UPDATE product SET quantity = quantity + 1 WHERE code = %s", (cod_prod,))

        # Anade la transferencia
        cursor = db.cursor()
        cursor.execute("INSERT INTO transfer VALUES(null, SYSDATE(), %s, %s)", (cod_prod, str(amount)))
        print("Se han creado {} productos de codigo {}".format(str(amount), cod_prod))
    else:
        print("No hay suficientes componentes para crear ese producto en esa cantidad")

    db.commit()
    db.close()


def remove_transfer(cod_transfer):
    db = connection.get_connection()

    # Obtiene producto y cantidad de productos de la transferencia
    transfer_set = query.query_transfer(cod_transfer)
    cod_prod = (transfer_set[0])[2]
    amount = int((transfer_set[0])[3])

    # Suma cantidades a los componentes y resta productos
    relation_set = query.query_relation(cod_prod)
    for i in range(int(amount)):
        for item in relation_set:
            cod_comp = item[1]
            quantity = item[2]
            cursor = db.cursor()
            cursor.execute("UPDATE component SET quantity = quantity + %s WHERE code = %s",
                           (str(quantity), cod_comp))
        cursor = db.cursor()
        cursor.execute("UPDATE product SET quantity = quantity - 1 WHERE code = %s", (cod_prod,))

    # Quita la transferencia
    cursor = db.cursor()
    cursor.execute("DELETE FROM transfer WHERE cod_transfer = %s", (cod_transfer,))

    db.commit()
    db.close()
    print("Se ha eliminado la transferencia de codigo {}".format(cod_transfer))
