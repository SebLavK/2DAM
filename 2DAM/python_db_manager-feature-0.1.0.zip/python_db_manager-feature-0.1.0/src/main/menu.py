# -*- coding: utf-8 -*-

MAIN_MENU = ["Ver tablas", "Procesar productos"]
QUERY_MENU = [
    "Tabla de componentes",
    "Tabla de productos",
    "Tabla de relaciones",
    "Tabla de movimientos"
]
PROCESS_MENU = ["Realizar movimiento", "Eliminar movimiento"]

def generate_menu(items, exit_item, msg):
    option = -2
    i = 1
    min = 1

    print("\n{}\n=======".format(msg))
    for item in items:
        print("{} - {}".format(i, str(item)))
        i += 1

    if exit_item:
        print("\n0 - Salir")
        min = 0

    while option < min or option >= i:
        try:
            option = int(input("=======\nOpcion: "))
        except ValueError:
            option = -2
        if option < min or option >= i:
            print("Esa opcion no existe, pruebe de nuevo")

    return option - 1
