# -*- coding: utf-8 -*-
import mysql.connector as mysql

"""Conecta a una base de datos MySQL

Example:
    Ejemplo::
        
        $ import main.connection as connect
        $ cursor = connect.connection_db()

Author: Sebas Lavigne

"""

def get_connection():
    db = mysql.connect(
        host="localhost",
        database="production",
        user="root",
        password=""
    )
    return db