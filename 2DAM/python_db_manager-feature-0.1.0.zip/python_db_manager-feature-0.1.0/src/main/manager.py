# -*- coding: utf-8 -*-
import src.manipulation.query as query
import src.manipulation.process as process
import src.main.menu as menu


def select_main_menu():
    done = False
    while not done:
        option = menu.generate_menu(menu.MAIN_MENU, True, "Gestor de produccion")
        if option == -1:
            done = True
            print("Saliendo del programa")
        elif option == 0:
            select_query_menu()
        elif option == 1:
            select_process_menu()


def select_query_menu():
    done = False
    while not done:
        option = menu.generate_menu(menu.QUERY_MENU, True, "Elija la tabla a consultar")
        if option == -1:
            done = True
        elif option == 0:
            show_result_set(query.query_components())
        elif option == 1:
            show_result_set(query.query_products())
        elif option == 2:
            show_result_set(query.query_relations())
        elif option == 3:
            show_result_set(query.query_transfers())

        if not done:
            input("Pulse INTRO para continuar")


def select_process_menu():
    done = False
    while not done:
        option = menu.generate_menu(menu.PROCESS_MENU, True, "Elija una accion")
        if option == -1:
            done = True
        elif option == 0:
            cod_prod = select_product()
            if cod_prod != 0:
                amount = input("Cuantas unidades desea crear? : ")
                process.make_transfer(cod_prod, amount)
        elif option == 1:
            cod_transfer = select_transfer()
            if cod_transfer != 0:
                process.remove_transfer(cod_transfer)

        if not done:
            input("Pulse INTRO para continuar")


def show_result_set(result_set):
    for result in result_set:
        print(result)


def select_product():
    products = list()
    result_set = query.query_products()
    # Obtiene las descripciones de los productos
    for result in result_set:
        products.append(result[2])

    selection = menu.generate_menu(products, True, "Seleccione el producto a crear")
    if selection != -1:
        # Obtiene el codigo del producto
        cod_prod = result_set[selection][0]
        return cod_prod
    else:
        return 0


def select_transfer():
    result_set = query.query_transfers()

    if len(result_set) != 0:
        selection = menu.generate_menu(result_set, False, "Seleccione el movimiento a eliminar")
        # Obtiene el codigo del movimiento
        # Suma 1 por como funciona el autoincremental de MySQL y mi metodo de mostrar menu
        cod_transfer = int(result_set[selection][0])
        return cod_transfer
    else:
        print("No hay movimientos")
        return 0
