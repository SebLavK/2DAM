-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 04-03-2019 a las 22:28:32
-- Versión del servidor: 10.1.36-MariaDB
-- Versión de PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `production`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `component`
--

CREATE TABLE `component` (
  `code` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `quantity` decimal(10,0) DEFAULT NULL,
  `description` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `component`
--

INSERT INTO `component` (`code`, `quantity`, `description`) VALUES
('COMP_001', '40', 'RUEDAS'),
('COMP_002', '18', 'PUERTA_DELANTERA'),
('COMP_003', '18', 'PUERTA_TRASERA'),
('COMP_004', '9', 'MOTOR_160CV'),
('COMP_005', '4', 'MOTOR_220CV'),
('COMP_006', '10', 'FAROS_XENON'),
('COMP_007', '40', 'FAROS_LED'),
('COMP_008', '18', 'RADIO'),
('COMP_009', '22', 'MONITOR_GPS'),
('COMP_010', '5', 'CHASIS_SEDAN'),
('COMP_011', '4', 'CHASIS_TODOTERRENO'),
('COMP_012', '6', 'CHASIS_BERLINA'),
('COMP_013', '5', 'CHASIS_TRES_PUERTAS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `component_product`
--

CREATE TABLE `component_product` (
  `cod_prod` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `cod_comp` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `quantity` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `component_product`
--

INSERT INTO `component_product` (`cod_prod`, `cod_comp`, `quantity`) VALUES
('PROD_001', 'COMP_001', '4'),
('PROD_001', 'COMP_002', '2'),
('PROD_001', 'COMP_003', '2'),
('PROD_001', 'COMP_004', '1'),
('PROD_001', 'COMP_006', '2'),
('PROD_001', 'COMP_008', '1'),
('PROD_001', 'COMP_009', '1'),
('PROD_001', 'COMP_010', '1'),
('PROD_002', 'COMP_001', '4'),
('PROD_002', 'COMP_002', '2'),
('PROD_002', 'COMP_005', '1'),
('PROD_002', 'COMP_007', '2'),
('PROD_002', 'COMP_009', '1'),
('PROD_002', 'COMP_011', '1'),
('PROD_003', 'COMP_001', '4'),
('PROD_003', 'COMP_002', '2'),
('PROD_003', 'COMP_003', '2'),
('PROD_003', 'COMP_005', '1'),
('PROD_003', 'COMP_006', '2'),
('PROD_003', 'COMP_008', '1'),
('PROD_003', 'COMP_009', '1'),
('PROD_003', 'COMP_012', '1'),
('PROD_004', 'COMP_001', '4'),
('PROD_004', 'COMP_002', '2'),
('PROD_004', 'COMP_004', '1'),
('PROD_004', 'COMP_007', '2'),
('PROD_004', 'COMP_013', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product`
--

CREATE TABLE `product` (
  `code` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `quantity` decimal(10,0) DEFAULT NULL,
  `description` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `product`
--

INSERT INTO `product` (`code`, `quantity`, `description`) VALUES
('PROD_001', '0', 'SEDAN'),
('PROD_002', '0', 'TODOTERRENO'),
('PROD_003', '0', 'BERLINA'),
('PROD_004', '0', 'TRES_PUERTAS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transfer`
--

CREATE TABLE `transfer` (
  `cod_transfer` double NOT NULL,
  `date_transfer` date DEFAULT NULL,
  `cod_prod` varchar(10) COLLATE latin1_spanish_ci DEFAULT NULL,
  `quantity` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `component`
--
ALTER TABLE `component`
  ADD PRIMARY KEY (`code`);

--
-- Indices de la tabla `component_product`
--
ALTER TABLE `component_product`
  ADD PRIMARY KEY (`cod_prod`,`cod_comp`),
  ADD KEY `cod_comp` (`cod_comp`);

--
-- Indices de la tabla `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`code`);

--
-- Indices de la tabla `transfer`
--
ALTER TABLE `transfer`
  ADD UNIQUE KEY `cod_transfer` (`cod_transfer`),
  ADD KEY `cod_prod` (`cod_prod`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `transfer`
--
ALTER TABLE `transfer`
  MODIFY `cod_transfer` double NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `component_product`
--
ALTER TABLE `component_product`
  ADD CONSTRAINT `component_product_ibfk_1` FOREIGN KEY (`cod_comp`) REFERENCES `component` (`code`),
  ADD CONSTRAINT `component_product_ibfk_2` FOREIGN KEY (`cod_prod`) REFERENCES `product` (`code`);

--
-- Filtros para la tabla `transfer`
--
ALTER TABLE `transfer`
  ADD CONSTRAINT `transfer_ibfk_1` FOREIGN KEY (`cod_prod`) REFERENCES `product` (`code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
