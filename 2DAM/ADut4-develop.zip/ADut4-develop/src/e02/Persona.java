package e02;

import java.time.LocalDate;

/**
*@author Sebas Lavigne
*/

/**
 *
 */
public class Persona {
	
	private String nombre;
	private String apellidos;
	private LocalDate fechaNac;
	private int telefono;
	private String email;
	private Direccion direccion;
	
	
	public Persona(String nombre, String apellidos, LocalDate fechaNac, int telefono, String email,
			Direccion direccion) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNac = fechaNac;
		this.telefono = telefono;
		this.email = email;
		this.direccion = direccion;
	}

	public Persona(String nombre, String apellidos, LocalDate fechaNac, int telefono, String email) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNac = fechaNac;
		this.telefono = telefono;
		this.email = email;
	}

	public Persona(String nombre, String apellidos) {
		this.nombre = nombre;
		this.apellidos = apellidos;
	}
	
	@Override
	public String toString() {
		String string = "Persona: [";
		string += (nombre != null) ? "Nombre: "+nombre+", " : "" ;
		string += (apellidos != null) ? "Apellidos: "+apellidos+", " : "" ;
		string += (fechaNac != null) ? "FechaNac: "+fechaNac+", " : "" ;
		string += (telefono != 0) ? "Telefono "+telefono+", " : "" ;
		string += (email != null) ? "Email "+email+", " : "" ;
		string += "]";
		string += (direccion != null) ? "\n\t"+direccion : "";
		
		return string;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * @return the fechaNac
	 */
	public LocalDate getFechaNac() {
		return fechaNac;
	}

	/**
	 * @param fechaNac the fechaNac to set
	 */
	public void setFechaNac(LocalDate fechaNac) {
		this.fechaNac = fechaNac;
	}

	/**
	 * @return the telefono
	 */
	public int getTelefono() {
		return telefono;
	}

	/**
	 * @param telefono the telefono to set
	 */
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the direccion
	 */
	public Direccion getDireccion() {
		return direccion;
	}

	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}
	
	
}
