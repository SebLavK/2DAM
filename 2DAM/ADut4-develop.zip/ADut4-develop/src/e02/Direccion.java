package e02;

/**
*@author Sebas Lavigne
*/

public class Direccion {
	
	private int numero;
	private String calle;
	private String ciudad;
	private String pais;
	
	public Direccion(int numero, String calle, String ciudad, String pais) {
		this.numero = numero;
		this.calle = calle;
		this.ciudad = ciudad;
		this.pais = pais;
	}
	
	public Direccion(String ciudad) {
		this.ciudad = ciudad;
	}
	
	@Override
	public String toString() {
		String string = "Direccion: [";
		string += (numero != 0) ? "Numero: "+numero+", " : "" ;
		string += (calle != null) ? "Calle: "+calle+", " : "" ;
		string += (ciudad != null) ? "Ciudad: "+ciudad+", " : "" ;
		string += (pais != null) ? "Pais: "+pais+", " : "" ;
		string += "]";
		
		return string;
	}

	/**
	 * @return the numero
	 */
	public int getNumero() {
		return numero;
	}

	/**
	 * @param numero the numero to set
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}

	/**
	 * @return the calle
	 */
	public String getCalle() {
		return calle;
	}

	/**
	 * @param calle the calle to set
	 */
	public void setCalle(String calle) {
		this.calle = calle;
	}

	/**
	 * @return the ciudad
	 */
	public String getCiudad() {
		return ciudad;
	}

	/**
	 * @param ciudad the ciudad to set
	 */
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	/**
	 * @return the pais
	 */
	public String getPais() {
		return pais;
	}

	/**
	 * @param pais the pais to set
	 */
	public void setPais(String pais) {
		this.pais = pais;
	}
	
	

}
