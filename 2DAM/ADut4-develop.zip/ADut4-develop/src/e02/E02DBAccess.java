package e02;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.config.EmbeddedConfiguration;

/**
*@author Sebas Lavigne
*/

public class E02DBAccess {
	
	public static final String DBPEOPLE = "personas.yap";
	
	/**
	 * Establece una conexion con el archivo de datos
	 * @return La conexion
	 */
	public static ObjectContainer getDBConnection() {
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		
		config.common().objectClass(Persona.class).cascadeOnUpdate(true);
		config.common().objectClass(Direccion.class).cascadeOnUpdate(true);
		
		config.common().updateDepth(5);
		config.common().activationDepth(5);
		
		//No se borrara la Direccion cuando se borra una Persona
		config.common().objectClass(Persona.class).cascadeOnDelete(false);
		
		ObjectContainer db = Db4oEmbedded.openFile(config, DBPEOPLE);
		return db;
	}
	
	/*
	 * Insertar objetos
	 */
	
	/**
	 * Inserta una persona en la base de datos
	 * @param per La persona que se quiere insertar
	 */
	public static void insertPersona(Persona per) {
		ObjectContainer db = getDBConnection();
		db.store(per);
		db.commit();
		db.close();
	}
	
	/**
	 * Inserta una direccion en la base de datos
	 * @param dir La direccion que se quiere insertar
	 */
	public static void insertDireccion(Direccion dir) {
		ObjectContainer db = getDBConnection();
		db.store(dir);
		db.commit();
		db.close();
	}
	
	/**
	 * Establece el atriubto direccion de una persona
	 * @param per La persona
	 * @param dir La direccion
	 */
	public static void setDireccionForPersona(Persona per, Direccion dir) {
		ObjectContainer db = getDBConnection();
		
		Persona per_query = new Persona(per.getNombre(), per.getApellidos());
		
		ObjectSet<Persona> osper = db.queryByExample(per_query);
		ObjectSet<Direccion> osdir = db.queryByExample(dir);
		
		if (osper.size() > 0 && osdir.size() > 0) {
			Persona perUpdate = osper.next();
			perUpdate.setDireccion(osdir.next());
			db.store(perUpdate);
		} else {
			System.out.println("Error, no se ha encontrado el objeto:");
			if (osper.size() == 0) {
				System.out.println(per);
			}
			if (osdir.size() == 0) {
				System.out.println(dir);
			}
		}
		
		db.commit();
		db.close();
	}
	
	/*
	 * Obtener lista de todos los objetos
	 */
	
	/**
	 * Obtiene una lista de todas las personas guardadas en la base de datos
	 * @return Un ArrayList de Persona
	 */
	public static ArrayList<Persona> queryAllPersonas() {

		ObjectContainer db = getDBConnection();
		ObjectSet<Persona> osper = db.query(Persona.class);
		ArrayList<Persona> alper = new ArrayList<>();
		
		for (Persona persona : osper) {
			alper.add(persona);
		}
		
		db.close();
		
		return alper;
	}
	
	/**
	 * Obtiene una lista de todas las direcciones guardadas en la base de datos
	 * @return Un ArrayList de Direccion
	 */
	public static ArrayList<Direccion> queryAllDirecciones() {
		ObjectContainer db = getDBConnection();
		ObjectSet<Direccion> osdir = db.query(Direccion.class);
		ArrayList<Direccion> aldir = new ArrayList<>();
		
		for (Direccion direccion : osdir) {
			aldir.add(direccion);
		}
		
		db.close();
		
		return aldir;
	}
	
	/*
	 * Modificacion de persona
	 */
	
	/**
	 * Modifica los datos de una persona
	 * @param per La persona que se quiere modificar
	 */
	public static void modifyPersona(Persona per) {
		ObjectContainer db = getDBConnection();
		
		ObjectSet<Persona> osper = db.queryByExample(new Persona(per.getNombre(), per.getApellidos()));
		if (osper.size() > 0) {
			Persona perUpdate = osper.next();
			System.out.print("Introduce el nuevo nombre: ");
			perUpdate.setNombre(inputString());
			System.out.print("Introduce los nuevos apellidos: ");
			perUpdate.setApellidos(inputString());
			System.out.print("Introduce la nueva fecha de nacimiento: ");
			perUpdate.setFechaNac(inputLocalDate());
			System.out.print("Introduce el nuevo telefono: ");
			perUpdate.setTelefono(inputInt());
			System.out.print("Introduce el nuevo email: ");
			perUpdate.setEmail(inputString());
			
			db.store(perUpdate);
		} else {
			System.out.println("No se encontro el objeto: "+per);
		}
		
		db.commit();
		db.close();
	}
	
	/*
	 * Eliminacion de una persona
	 */
	
	/**
	 * Elimina una persona de la base de datos.
	 * Si tiene asignada una direccion, la direccion no se borra
	 * @param per La persona que se quiere eliminar
	 */
	public static void deletePersona(Persona per) {
		ObjectContainer db = getDBConnection();

		ObjectSet<Persona> osper = db.queryByExample(new Persona(per.getNombre(), per.getApellidos()));

		if (osper.size() > 0) {
			Persona perDelete = osper.next();
			db.delete(perDelete);
		} else {
			System.out.println("No se encontro el objeto: "+per);
		}
		
		db.commit();
		db.close();
	}

	/*
	 * Mostrar personas de una ciudad
	 */
	
	/**
	 * Muestra aquellas personas que viven en una determinada ciudad.
	 * Como direccion no guarda ningun tipo de coleccion, solo es posible
	 * mostrar las personas de una ciudad recorriendolas todas y filtrando
	 * por la ciudad
	 * @param city La ciudad
	 */
	public static void showPersonaFromCity(String city) {
		ArrayList<Persona> alper = queryAllPersonas();
		for (Persona persona : alper) {
			if (persona.getDireccion() != null && city.equals(persona.getDireccion().getCiudad())) {
				System.out.println(persona);
			}
		}
	}
	
	/*
	 * Utilidades
	 */
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	public static LocalDate inputLocalDate() {
		try {
			return LocalDate.parse(inputString(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		} catch (Exception e) {
			System.out.println("Introduce una fecha en el formato correcto (dd/mm/aaaa)");
			return inputLocalDate();
		}
	}
	
	public static int inputInt() {
		try {
			return Integer.parseInt(inputString());
		} catch (NumberFormatException e) {
			System.out.println("Introduce un numero");
			return inputInt();
		}
	}
}
