package e02;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
*@author Sebas Lavigne
*/

public class Main {
	
	/**
	 * 
	 * @return Un String
	 */
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	/**
	 * Pide por teclado una fecha de formato (dd/mm/aaaa)
	 * @return Un LocalDate
	 */
	public static LocalDate inputLocalDate() {
		try {
			return LocalDate.parse(inputString(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		} catch (Exception e) {
			System.out.println("Introduce una fecha en el formato correcto (dd/mm/aaaa)");
			return inputLocalDate();
		}
	}
	
	/**
	 * 
	 * @return Un entero
	 */
	public static int inputInt() {
		try {
			return Integer.parseInt(inputString());
		} catch (NumberFormatException e) {
			System.out.println("Introduce un numero");
			return inputInt();
		}
	}
	
	/**
	 * 
	 * @return Una persona con todos los atributos salvo la Direccion
	 */
	public static Persona inputPersona() {
		System.out.print("Introduce el nombre: ");
		String nombre = inputString();
		System.out.print("Introduce los apellidos: ");
		String apellidos = inputString();
		System.out.print("Introduce la fecha de nacimiento (dd/mm/aaaa): ");
		LocalDate fechaNac = inputLocalDate();
		System.out.print("Introduce el telefono: ");
		int telefono = inputInt();
		System.out.print("Introduce el email: ");
		String email = inputString();
		
		return new Persona(nombre, apellidos, fechaNac, telefono, email);
	}
	
	/**
	 * 
	 * @return Una persona con nombre y apellidos
	 */
	public static Persona inputSimplePersona() {
		System.out.print("Introduce el nombre: ");
		String nombre = inputString();
		System.out.print("Introduce los apellidos: ");
		String apellidos = inputString();
		
		return new Persona(nombre, apellidos);
	}
	
	/**
	 * 
	 * @return Una direccion con todos sus atributos
	 */
	public static Direccion inputDireccion() {
		System.out.print("Introduce el numero: ");
		int numero = inputInt();
		System.out.print("Introduce la calle: ");
		String calle = inputString();
		System.out.print("Introduce la ciudad: ");
		String ciudad = inputString();
		System.out.print("Introduce el pais: ");
		String pais = inputString();
		
		return new Direccion(numero, calle, ciudad, pais);
	}
	
	/**
	 * Pide a la base de datos una lista de todas las personas.
	 * Muestra la lista por pantalla para dar a elegir al usuario.
	 * @return La persona seleccionada
	 */
	public static Persona selectPersona() {
		ArrayList<Persona> alper = E02DBAccess.queryAllPersonas();
		int selection = menu.Menu.generateMenu(alper.toArray(), false, "Selecciona una persona");
		return alper.get(selection);
	}
	
	/**
	 * Pide a la base de datos una lista de todas las direcciones.
	 * Muestra la lista por pantalla para dar a elegir al usuario.
	 * @return La direccion seleccionada
	 */
	public static Direccion selectDireccion() {
		ArrayList<Direccion> aldir = E02DBAccess.queryAllDirecciones();
		int selection = menu.Menu.generateMenu(aldir.toArray(), false, "Selecciona una direccion");
		return aldir.get(selection);
	}

	public static void main(String[] args) {
		String[] options = {
				"Ver personas",
				"Ver direcciones",
				"Insertar persona",
				"Insertar direccion",
				"Cambiar la direccion de una persona",
				"Modificar datos de una persona",
				"Eliminar una persona",
				"Mostrar todas las personas de una ciudad"
		};
		
		boolean done = false;
		int option;
		
		while (!done) {
			option = menu.Menu.generateMenu(options, true, "Gestion de personas y direcciones");
			switch (option) {
			case -1: //Salir
				System.out.println("Saliendo del programa...");
				done = true;
				break;
			case 0:
				ArrayList<Persona> alper = E02DBAccess.queryAllPersonas();
				for (Persona persona : alper) {
					System.out.println(persona);
				}
				break;
			case 1:
				ArrayList<Direccion> aldir = E02DBAccess.queryAllDirecciones();
				for (Direccion direccion : aldir) {
					System.out.println(direccion);
				}
				break;
			case 2:
				E02DBAccess.insertPersona(inputPersona());
				break;
			case 3:
				E02DBAccess.insertDireccion(inputDireccion());
				break;
			case 4:
				E02DBAccess.setDireccionForPersona(selectPersona(), selectDireccion());
				break;
			case 5:
				E02DBAccess.modifyPersona(selectPersona());
				break;
			case 6:
				E02DBAccess.deletePersona(selectPersona());
				break;
			case 7:
				System.out.print("Introduce el nombre de la ciudad: ");
				E02DBAccess.showPersonaFromCity(inputString());
				break;
			}
			
			if (option != -1) {
				System.out.println("\nPulsa INTRO para continuar");
				inputString();
			}
		}
		
		
	}
}
