package e03;

import java.util.ArrayList;
import java.util.Scanner;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.constraints.UniqueFieldValueConstraint;

/**
*@author Sebas Lavigne
*/

public class E03DBAccess {
	
	public static final String DBSPORT = "jugadoresequipo.yap";
	
	/**
	 * Establece una conexion con el archivo de datos
	 * @return La conexion
	 */
	public static ObjectContainer getDBConnection() {
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		
		config.common().objectClass(Jugador.class).cascadeOnUpdate(true);
		config.common().objectClass(Equipo.class).cascadeOnUpdate(true);
		
		config.common().updateDepth(5);
		config.common().activationDepth(5);
		
		//Restringe el nombre del Equipo como valor unico
		config.common().objectClass(Equipo.class).objectField("nombre").indexed(true);
		config.common().add(new UniqueFieldValueConstraint(Equipo.class, "nombre"));
		
		//No se borrara el Equipo cuando se borre un Jugador
		config.common().objectClass(Jugador.class).cascadeOnDelete(false);
		
		ObjectContainer db = Db4oEmbedded.openFile(config, DBSPORT);
		return db;
	}
	
	/*
	 * Insertar objetos
	 */
	
	/**
	 * Inserta un Jugador en la base de datos
	 * @param jug El jugador
	 */
	public static void insertJugador(Jugador jug) {
		ObjectContainer db = getDBConnection();
		db.store(jug);
		db.commit();
		db.close();
	}
	
	/**
	 * Inserta un Equipo en la base de datos
	 * @param equ El Equipo
	 */
	public static void insertEquipo(Equipo equ) {
		ObjectContainer db = getDBConnection();
		db.store(equ);
		db.commit();
		db.close();
	}
	
	/*
	 * Asignacion de objetos
	 */
	
	/**
	 * Establece el Equipo que guarda un Jugador y actualiza en base de datos
	 * @param jug El jugador
	 * @param equ El Equipo que se le va a asignar
	 */
	public static void setEquipoForJugador(Jugador jug, Equipo equ) {
		ObjectContainer db = getDBConnection();
		Jugador jug_query = new Jugador(jug.getNombre(), jug.getApellidos());
		Equipo equ_query = new Equipo(equ.getNombre());
		
		ObjectSet<Jugador> osjug = db.queryByExample(jug_query);
		ObjectSet<Equipo> osequ = db.queryByExample(equ_query);
		
		if (osjug.size() > 0 && osequ.size() > 0) {
			Jugador jugUpdate = osjug.next();
			jugUpdate.setEquipo(osequ.next());
			db.store(jugUpdate);
		} else {
			System.out.println("Error, no se ha encontrado el objeto:");
			if (osjug.size() == 0) {
				System.out.println(jug);
			}
			if (osequ.size() == 0) {
				System.out.println(equ);
			}
		}
		
		db.commit();
		db.close();
	}
	
	/**
	 * Anade un Jugador a la coleccion de un Equipo
	 * @param jug El Jugador que anadir a la lista del Equipo
	 * @param equ El Equipo
	 */
	public static void addJugadorToEquipo(Jugador jug, Equipo equ) {
		ObjectContainer db = getDBConnection();
		Jugador jug_query = new Jugador(jug.getNombre(), jug.getApellidos());
		Equipo equ_query = new Equipo(equ.getNombre());
		
		ObjectSet<Jugador> osjug = db.queryByExample(jug_query);
		ObjectSet<Equipo> osequ = db.queryByExample(equ_query);
		
		if (osjug.size() > 0 && osequ.size() > 0) {
			Equipo equUpdate = osequ.next();
			equUpdate.addJugador(osjug.next());
			db.store(equUpdate);
		} else {
			System.out.println("Error, no se ha encontrado el objeto:");
			if (osjug.size() == 0) {
				System.out.println(jug);
			}
			if (osequ.size() == 0) {
				System.out.println(equ);
			}
		}
		
		db.commit();
		db.close();
	}
	
	/*
	 * Obtener lista de todos los objetos
	 */
	
	/**
	 * Obtiene una lista de todos los jugadores guardados en la base de datos
	 * @return Un ArrayList de Jugador
	 */
	public static ArrayList<Jugador> queryAllJugadores() {
		ObjectContainer db = getDBConnection();
		ObjectSet<Jugador> osjug = db.query(Jugador.class);
		ArrayList<Jugador> aljug = new ArrayList<>();
		
		aljug.addAll(osjug);
		
		db.close();
		
		return aljug;
	}
	
	/**
	 * Obtiene una lista de todos los equipos guardados en la base de datos
	 * @return Un ArrayList de Equipo
	 */
	public static ArrayList<Equipo> queryAllEquipos() {
		ObjectContainer db = getDBConnection();
		ObjectSet<Equipo> osequ = db.query(Equipo.class);
		ArrayList<Equipo> alequ = new ArrayList<>();
		
		alequ.addAll(osequ);
		
		db.close();
		
		return alequ;
	}
	
	
	/*
	 * Modificacion de objetos
	 */
	
	/**
	 * Modifica los datos de un jugador
	 * @param jug El jugador que se quiere modificar
	 */
	public static void updateJugador(Jugador jug) {
		ObjectContainer db = getDBConnection();
		
		Jugador jug_query = new Jugador(jug.getNombre(), jug.getApellidos());
		ObjectSet<Jugador> osjug = db.queryByExample(jug_query);
		if (osjug.size() > 0) {
			Jugador jugUpdate = osjug.next();
			System.out.println("Introduce los nuevos datos del jugador:");
			Jugador jugNew = Main.inputJugador();
			
			jugUpdate.setNombre(jugNew.getNombre());
			jugUpdate.setApellidos(jugNew.getApellidos());
			jugUpdate.setNacionalidad(jugNew.getNacionalidad());
			jugUpdate.setPosicion(jugNew.getPosicion());
			jugUpdate.setDorsal(jugNew.getDorsal());
			
			db.store(jugUpdate);
		} else {
			System.out.println("No se ha encontrado el "+jug);
		}
		
		db.commit();
		db.close();
	}
	
	/**
	 * Modifica los datos de un equipo
	 * @param equ El equipo que se quiere modificar
	 */
	public static void updateEquipo(Equipo equ) {
		ObjectContainer db = getDBConnection();
		
		Equipo equ_query = new Equipo(equ.getNombre());
		ObjectSet<Equipo> osequ = db.queryByExample(equ_query);
		if (osequ.size() > 0) {
			Equipo equUpdate = osequ.next();
			System.out.println("Introduce los nuevos datos del equipo:");
			Equipo equNew = Main.inputEquipo();
			
			equUpdate.setNombre(equNew.getNombre());
			equUpdate.setCategoria(equNew.getCategoria());
			equUpdate.setPais(equNew.getPais());
			equUpdate.setEstadio(equNew.getEstadio());
			
			db.store(equUpdate);
		} else {
			System.out.println("No se ha encontrado el "+equ);
		}
		
		db.commit();
		db.close();
	}
	
	/*
	 * Cambio de equipo
	 */
	
	/**
	 * Cambia a un jugador de equipo
	 * Para ello lo quita de la lista de su equipo anterior (si lo tiene)
	 * Luego le establece el nuevo equipo y lo anade a la lista del equipo
	 * @param jug
	 * @param newEqu
	 */
	public static void changeEquipo(Jugador jug, Equipo newEqu) {
		ObjectContainer db = getDBConnection();
		
		Jugador jug_query = new Jugador(jug.getNombre(), jug.getApellidos());
		ObjectSet<Jugador> osjug = db.queryByExample(jug_query);
		
		Equipo newEqu_query = new Equipo(newEqu.getNombre());
		ObjectSet<Equipo> osequ = db.queryByExample(newEqu_query);
		
		if (osjug.size() > 0 && osequ.size() > 0) {
			Jugador jugUpdate = osjug.next();
			Equipo equUpdate = osequ.next();
			
			//Saca el jugador del equipo antiguo
			Equipo oldEqu = jugUpdate.getEquipo();
			//Controla que el jugador tenga equipo
			if (oldEqu != null) {
				oldEqu.removeJugador(jugUpdate);
			}
			
			db.store(oldEqu);
			
			//A partir de aqui se usan los otros metodos de asignacion
			db.commit();
			db.close();
			
			setEquipoForJugador(jugUpdate, equUpdate);
			addJugadorToEquipo(jugUpdate, equUpdate);
			
		} else {
			System.out.println("Error, no se ha encontrado el objeto:");
			if (osjug.size() == 0) {
				System.out.println(jug);
			}
			if (osequ.size() == 0) {
				System.out.println(newEqu);
			}
		}
		
		db.close();
	}
	
	/*
	 * Elmiminacion de un jugador
	 */
	
	/**
	 * Elimina a un jugador. Como la eliminacion en casacada esta desactivada
	 * no se eliminara el equipo al que pertenece.
	 * Se elimina de la lista del equipo al que pertenece.
	 * @param jug El Jugador que se quiere eliminar
	 */
	public static void deleteJugador(Jugador jug) {
		ObjectContainer db = getDBConnection();
		
		Jugador jug_query = new Jugador(jug.getNombre(), jug.getApellidos());
		ObjectSet<Jugador> osjug = db.queryByExample(jug_query);
		if (osjug.size() > 0) {
			Jugador jugDelete = osjug.next();
			Equipo equUpdate = jugDelete.getEquipo();
			
			if (equUpdate != null) {
				equUpdate.removeJugador(jugDelete);
				db.store(equUpdate);
			}
			db.delete(jugDelete);
			
		} else {
			System.out.println("No se ha encontrado el "+jug);
		}
		
		db.commit();
		db.close();
	}
	
	/*
	 * Mostrar jugadores de un equipo
	 */
	
	public static ArrayList<Jugador> queryJugadoresFromEquipo(Equipo equ) {
		ObjectContainer db = getDBConnection();
		
		Equipo equ_query = new Equipo(equ.getNombre());
		ObjectSet<Equipo> osequ = db.queryByExample(equ_query);
		ArrayList<Jugador> aljug = null;
		if (osequ.size() > 0) {
			aljug = osequ.next().getJugadores();
		} else {
			System.out.println("No se ha encontrado el "+equ);
		}
		
		db.close();
		
		return aljug;
	}
	
	/*
	 * Utilidades
	 */
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	public static int inputInt() {
		try {
			return Integer.parseInt(inputString());
		} catch (NumberFormatException e) {
			System.out.println("Introduce un numero");
			return inputInt();
		}
	}
}
