package e03;

import java.util.ArrayList;
import java.util.Scanner;


/**
*@author Sebas Lavigne
*/

public class Main {
	
	/**
	 * 
	 * @return Un String
	 */
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	/**
	 * 
	 * @return Un entero
	 */
	public static int inputInt() {
		try {
			return Integer.parseInt(inputString());
		} catch (NumberFormatException e) {
			System.out.println("Introduce un numero");
			return inputInt();
		}
	}
	
	/**
	 * 
	 * @return Un jugador con todos sus campos salvo el equipo
	 */
	public static Jugador inputJugador() {
		Jugador jug = new Jugador();
		System.out.print("Introduce el nombre: ");
		jug.setNombre(inputString());
		System.out.print("Introduce los apellidos: ");
		jug.setApellidos(inputString());
		System.out.print("Introduce la nacionalidad: ");
		jug.setNacionalidad(inputString());
		System.out.print("Introduce la posicion: ");
		jug.setPosicion(inputString());
		System.out.print("Introduce el dorsal: ");
		jug.setDorsal(inputInt());
		
		return jug;
	}
	
	/**
	 * 
	 * @return Un jugador con nombre y apellidos
	 */
	public static Jugador inputSimpleJugador() {
		Jugador jug = new Jugador();
		System.out.print("Introduce el nombre: ");
		jug.setNombre(inputString());
		System.out.print("Introduce los apellidos: ");
		jug.setApellidos(inputString());
		
		return jug;
	}
	
	/**
	 * 
	 * @return Un equipo con todos sus campos salvo la coleccion de jugadores
	 */
	public static Equipo inputEquipo() {
		Equipo equ = new Equipo();
		System.out.print("Introduce el nombre: ");
		equ.setNombre(inputString());
		System.out.print("Introduce la categoria: ");
		equ.setCategoria(inputString());
		System.out.print("Introduce el pais: ");
		equ.setPais(inputString());
		System.out.print("Introduce el estadio: ");
		equ.setEstadio(inputString());
		
		return equ;
	}
	
	/**
	 * 
	 * @return Un equipo con nombre
	 */
	public static Equipo inputSimpleEquipo() {
		Equipo equ = new Equipo();
		System.out.print("Introduce el nombre: ");
		equ.setNombre(inputString());
		
		return equ;
	}
	
	/**
	 * Pide a la base de datos una lista de todas los jugadores.
	 * Muestra la lista por pantalla para dar a elegir al usuario.
	 * @return El jugador seleccionado
	 */
	public static Jugador selectJugador() {
		ArrayList<Jugador> aljug = E03DBAccess.queryAllJugadores();
		int selection = menu.Menu.generateMenu(aljug.toArray(), false, "Selecciona un jugador");
		return aljug.get(selection);
	}
	
	/**
	 * Pide a la base de datos una lista de todas los jugadores.
	 * Muestra la lista por pantalla para dar a elegir al usuario.
	 * @return El jugador seleccionado
	 */
	public static Equipo selectEquipo() {
		ArrayList<Equipo> alequ = E03DBAccess.queryAllEquipos();
		int selection = menu.Menu.generateMenu(alequ.toArray(), false, "Selecciona un equipo");
		return alequ.get(selection);
	}

	public static void main(String[] args) {
		String[] options = {
			"Ver jugadores",
			"Ver equipos",
			"Insertar jugador",
			"Insertar equipo",
			"Asignar equipo a un jugador",
			"Modificar jugador",
			"Modificar equipo",
			"Cambiar jugador de equipo",
			"Eliminar un jugador",
			"Mostrar todos los jugadores de un equipo"
		};
		
		boolean done = false;
		int option;
		
		while (!done) {
			option = menu.Menu.generateMenu(options, true, "Gestion de la liga");
			switch (option) {
			case -1:
				System.out.println("Saliendo del programa...");
				done = true;
				break;
			case 0:
				for (Jugador jugador : E03DBAccess.queryAllJugadores()) {
					System.out.println(jugador);
				}
				break;
			case 1:
				for (Equipo equipo : E03DBAccess.queryAllEquipos()) {
					System.out.println(equipo);
				}
				break;
			case 2:
				System.out.println("Introduce los datos del nuevo jugador");
				E03DBAccess.insertJugador(inputJugador());
				break;
			case 3:
				System.out.println("Introduce los datos del nuevo equipo");
				E03DBAccess.insertEquipo(inputEquipo());
				break;
			case 4:
				System.out.println("***Asignacion de equipo***");
				Jugador jug = selectJugador();
				Equipo equ = selectEquipo();
				E03DBAccess.setEquipoForJugador(jug, equ);
				E03DBAccess.addJugadorToEquipo(jug, equ);
				break;
			case 5:
				System.out.println("***Modificacion de un jugador***");
				E03DBAccess.updateJugador(selectJugador());
				break;
			case 6:
				System.out.println("***Modificacion de un equipo***");
				E03DBAccess.updateEquipo(selectEquipo());
				break;
			case 7:
				System.out.println("***Asignar jugador a un equipo nuevo***");
				E03DBAccess.changeEquipo(selectJugador(), selectEquipo());
				break;
			case 8:
				System.out.println("***Eliminar jugador***");
				E03DBAccess.deleteJugador(selectJugador());
				break;
			case 9:
				System.out.println("***Jugadores de un equipo***");
				for (Jugador jugador : E03DBAccess.queryJugadoresFromEquipo(selectEquipo())) {
					System.out.println(jugador);
				}
				break;
			}
			
			if (option != -1) {
				System.out.println("\nPulsa INTRO para continuar");
				inputString();
			}
		}
		
	}
}
