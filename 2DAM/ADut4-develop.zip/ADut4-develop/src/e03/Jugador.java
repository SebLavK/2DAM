package e03;

/**
*@author Sebas Lavigne
*/

public class Jugador {
	
	private String nombre;
	private String apellidos;
	private String nacionalidad;
	private String posicion;
	private int dorsal;
	
	private Equipo equipo;

	public Jugador(String nombre, String apellidos, String nacionalidad, String posicion, int dorsal, Equipo equipo) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.nacionalidad = nacionalidad;
		this.posicion = posicion;
		this.dorsal = dorsal;
		this.equipo = equipo;
	}

	public Jugador(String nombre, String apellidos, String nacionalidad, String posicion, int dorsal) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.nacionalidad = nacionalidad;
		this.posicion = posicion;
		this.dorsal = dorsal;
	}

	public Jugador(String nombre, String apellidos) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
	}

	public Jugador() {
		super();
	}
	
	@Override
	public String toString() {
		String string = "Jugador: [";
		string += (nombre != null) ? "Nombre: "+nombre+", " : "";
		string += (apellidos != null) ? "Apellidos: "+apellidos+", " : "";
		string += (nacionalidad  != null) ? "Nacionalidad: "+nacionalidad+", " : "";
		string += (posicion != null) ? "Posicion: "+posicion+", " : "";
		string += (dorsal != 0) ? "Dorsal: "+dorsal : "";
		string += "]";
		string += (equipo != null) ? "\n\t"+equipo : "";
		
		return string;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	/**
	 * @return the nacionalidad
	 */
	public String getNacionalidad() {
		return nacionalidad;
	}

	/**
	 * @param nacionalidad the nacionalidad to set
	 */
	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	/**
	 * @return the posicion
	 */
	public String getPosicion() {
		return posicion;
	}

	/**
	 * @param posicion the posicion to set
	 */
	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}

	/**
	 * @return the dorsal
	 */
	public int getDorsal() {
		return dorsal;
	}

	/**
	 * @param dorsal the dorsal to set
	 */
	public void setDorsal(int dorsal) {
		this.dorsal = dorsal;
	}

	/**
	 * @return the equipo
	 */
	public Equipo getEquipo() {
		return equipo;
	}

	/**
	 * @param equipo the equipo to set
	 */
	public void setEquipo(Equipo equipo) {
		this.equipo = equipo;
	}
	
	

}
