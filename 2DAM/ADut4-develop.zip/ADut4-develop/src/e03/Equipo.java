package e03;

import java.util.ArrayList;

/**
*@author Sebas Lavigne
*/

public class Equipo {
	
	private String nombre;
	private String categoria;
	private String pais;
	private String estadio;
	
	private ArrayList<Jugador> jugadores;

	public Equipo(String nombre, String categoria, String pais, String estadio, ArrayList<Jugador> jugadores) {
		super();
		this.nombre = nombre;
		this.categoria = categoria;
		this.pais = pais;
		this.estadio = estadio;
		this.jugadores = jugadores;
		
		jugadores = new ArrayList<>();
	}

	public Equipo(String nombre, String categoria, String pais, String estadio) {
		super();
		this.nombre = nombre;
		this.categoria = categoria;
		this.pais = pais;
		this.estadio = estadio;
		jugadores = new ArrayList<>();
	}

	public Equipo(String nombre) {
		super();
		this.nombre = nombre;
		jugadores = new ArrayList<>();
	}

	public Equipo() {
		super();
		jugadores = new ArrayList<>();
	}
	
	@Override
	public String toString() {
		String string = "Equipo: [";
		string += (nombre != null) ? "Nombre: "+nombre+", " : "";
		string += (categoria != null) ? "Categoria: "+categoria+", " : "";
		string += (pais!= null) ? "Pais: "+pais+", " : "";
		string += (estadio != null) ? "Estadio: "+estadio+", " : "";
		string += (jugadores != null) ? "No Jugadores: "+jugadores.size() : "";
		string += "]";
		
		return string;
	}

	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the categoria
	 */
	public String getCategoria() {
		return categoria;
	}

	/**
	 * @param categoria the categoria to set
	 */
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	/**
	 * @return the pais
	 */
	public String getPais() {
		return pais;
	}

	/**
	 * @param pais the pais to set
	 */
	public void setPais(String pais) {
		this.pais = pais;
	}

	/**
	 * @return the estadio
	 */
	public String getEstadio() {
		return estadio;
	}

	/**
	 * @param estadio the estadio to set
	 */
	public void setEstadio(String estadio) {
		this.estadio = estadio;
	}

	/**
	 * @return the jugadores
	 */
	public ArrayList<Jugador> getJugadores() {
		return jugadores;
	}

	/**
	 * @param jugador El jugador a anadir a la lista
	 */
	public void addJugador(Jugador jugador) {
		jugadores.add(jugador);
	}
	
	/**
	 * 
	 * @param jugador El jugador que quitar de la lista
	 * @return Verdadero si se ha quitado al jugador
	 */
	public boolean removeJugador(Jugador jugador) {
		return jugadores.remove(jugador);
	}
	
	

}
