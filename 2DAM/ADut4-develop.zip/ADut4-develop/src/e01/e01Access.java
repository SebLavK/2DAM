package e01;

import java.util.ArrayList;
import java.util.Scanner;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;

/**
 * Esta clase extiende la clase de acceso a DB4o del ejemplo en los apuntes
 * anade la funcionalidad que se pide en el ejercicio 01
*@author Sebas Lavigne
*
*/

public class e01Access extends AccesoDB4o {
	
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	/**
	 * Muestra todos los empleados en la base de datos
	 */
	public static void showEmpleados() {
		ObjectContainer db = GetConexionBD();
		ObjectSet<Empleado> osemp = db.query(Empleado.class);
		
		System.out.println("Empleados en la base de datos:\n");
		
		for (Empleado empleado : osemp) {
			System.out.println(empleado);
		}
		
		db.close();
	}
	
	/**
	 * Muestra todos los departamentos en la base de datos
	 */
	public static void showDepartamentos() {
		ObjectContainer db = GetConexionBD();
		ObjectSet<Departamento> osdep = db.query(Departamento.class);
		
		System.out.println("Departamentos en la base de datos:\n");
		
		for (Departamento departamento : osdep) {
			System.out.println(departamento);
		}
		db.close();
	}
	
	/**
	 * Muestra los empleados de un departamento determinado
	 * @param dep El departamento en el que se encuentran los empleados
	 */
	public static void showEmpleadosFromDepartamento(Departamento dep) {
		ObjectContainer db = GetConexionBD();
		ObjectSet<Departamento> osdep = db.queryByExample(dep);
		if (osdep.size() > 0) {
			ArrayList<Empleado> emps = osdep.next().getEmpleados();
			System.out.println("Empleados del "+dep+"\n");
			for (Empleado emp : emps) {
				System.out.println(emp);
			}
		} else {
			System.out.println("No existe el "+dep+" en la base de datos");
		}
		db.close();
	}

	/**
	 * Modifica el nombre y apellidos de un empleado que ya esta en la base de datos
	 * @param emp Empleado ya existente en la base de datos al que se le quieren modificar datos
	 */
	public static void UpdateEmpleado(Empleado emp) {
		//Obtiene conexion
		ObjectContainer db = GetConexionBD();
		//Busca al empleado
		Empleado emp_query = new Empleado(emp.getNombre(), emp.getApellidos());
		ObjectSet<Empleado> osemp = db.queryByExample(emp_query);
		
		//Si el empleado existe...
		if (osemp.size() > 0) {
			//Cambia atributos del resultado
			Empleado empUpdate = osemp.next();
			System.out.print("Introduce el nuevo nombre del empleado: ");
			empUpdate.setNombre(inputString());
			System.out.print("Introduce los nuevos apellidos del empleado: ");
			empUpdate.setApellidos(inputString());
			
			//Guarda el empleado modificado
			db.store(empUpdate);
			System.out.println("Se han modificado los datos:\n\t"+emp+" -> "+empUpdate);
		} else {
			System.out.println("No se encuentra el "+emp+" en la base de datos");
		}
		
		db.commit();
		db.close();
	}
	
	/**
	 * Modifica la localidad de un departamento que ya esta en la base de datos
	 * @param dep Departamento ya existente en la base de datos
	 * al que se le quiere modificar la localidad
	 */
	public static void UpdateDepartamento(Departamento dep) {
		//Obtiene conexion
		ObjectContainer db = GetConexionBD();
		//Busca el departamento
		Departamento dep_query = new Departamento(dep.getNombre(), dep.getLocalidad());
		ObjectSet<Departamento> osdep = db.queryByExample(dep_query);
		
		//Si el departamento existe...
		if (osdep.size() > 0) {
			//Cambia la localidad del resultado
			Departamento depUpdate = osdep.next();
			//Para visualizar despues se guarda el objeto antiguo
			Departamento depOld = new Departamento(depUpdate.getNombre(), depUpdate.getLocalidad());
			System.out.print("Introduce la nueva localidad del departamento: ");
			depUpdate.setLocalidad(inputString());
			
			//Guarda el departamento modificado
			db.store(depUpdate);
			System.out.println("Se han modificado los datos:\n\t"+depOld+" -> "+depUpdate);
		} else {
			System.out.println("No se encuentra el "+dep+" en la base de datos");
		}
		
		db.commit();
		db.close();
	}
	
	/**
	 * Cambia un empleado de un departamento a otro.
	 * @param emp El empleado que cambia de departamento
	 * @param newDep El nuevo departamento del empleado
	 */
	public static void CambiarEmpleadoDepartamento(Empleado emp, Departamento newDep) {
		//Obtiene conexion
		ObjectContainer db = GetConexionBD();
		//Busca el empleado
		Empleado emp_query = new Empleado(emp.getNombre(), emp.getApellidos());
		ObjectSet<Empleado> osemp = db.queryByExample(emp_query);
		//Busca el nuevo departamento
		Departamento dep_query = new Departamento(newDep.getNombre(), newDep.getLocalidad());
		ObjectSet<Departamento> osdep = db.queryByExample(dep_query);
		
		//Si el empleado y el nuevo departamento existen...
		if (osemp.size() > 0 && osdep.size() > 0) {
			//Obtiene el empleado de la base de datos
			Empleado empUpdate = osemp.next();
			
			//Obtiene el nuevo departamento
			Departamento newDepUpdate = osdep.next();
			
			//Obtiene el antiguo departamento
			Departamento oldDepUpdate = empUpdate.getDepart();
			//Quita al empleado de la coleccion del departamento antiguo
			oldDepUpdate.removeEmpleados(empUpdate);
			//Actualiza el antiguo departamento (ya sin el empleado)
			db.store(oldDepUpdate);
			db.commit();
			//Se cierra aqui la conexion porque las siguientes asignaciones usan
			//otros metodos
			db.close();
			
			
			//Asigna el empleado al departamento
			SetDepartamentoEmpleado(empUpdate, newDepUpdate);
			//Anade el empleado a la coleccion del departamento
			AddEmpleadoDepartamento(empUpdate, newDepUpdate);
			
			System.out.println("Se ha modificado el "+emp+"\n\t"+oldDepUpdate+" -> "+newDepUpdate);
		} else {
			System.out.println("Error al cambiar el empleado:");
			if (! (osemp.size() > 0)) {
				System.out.println("\tNo existe "+emp);
			}
			if (! (osdep.size() > 0)) {
				System.out.println("\tNo existe "+newDep);
			}
		}
		
		//Se cierra aqui en caso de que no exista el empleado o el departamento
		db.close();
	}
	
	public static void DeleteDepartamento(Departamento dep) {
		//Obtiene conexion
		ObjectContainer db = GetConexionBD();
		//Busca el departamento
		Departamento dep_query = new Departamento(dep.getNombre(), dep.getLocalidad());
		ObjectSet<Departamento> osdep = db.queryByExample(dep_query);
		
		//Si existe el departamento...
		if (osdep.size() > 0) {
			//Obtiene el departamento
			Departamento depDelete = osdep.next();
			//Obtiene su lista de empleados
			ArrayList<Empleado> emps = depDelete.getEmpleados();
			//Nulifica el departamento para cada empleado y lo actualiza
			for (Empleado emp : emps) {
				emp.setDepart(null);
				db.store(emp);
			}
			//Borra el departametno
			db.delete(depDelete);
		} else {
			System.out.println("No se encuentra el "+dep);
		}
		
		db.commit();
		db.close();
	}
}






















































