package e01;

import com.db4o.config.EmbeddedConfiguration;
import com.db4o.constraints.UniqueFieldValueConstraint;
import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;

public class AccesoDB4o {
	
	public static final String BDEMP = "BDEmpleados.yap";
	
	public static ObjectContainer GetConexionBD() {
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		  // actualizamos en cascada
		config.common().objectClass(Departamento.class).cascadeOnUpdate(true);
		config.common().objectClass(Empleado.class).cascadeOnUpdate(true);
		  // cambiamos el nivel de actualizacion a 5
		config.common().updateDepth(5);
		config.common().activationDepth(5);
		  //Nos creamos en Departamento como indice el campo nombre
		config.common().objectClass(Departamento.class).objectField("nombre").indexed(true);
		  //Nos creamos una restriccion para evitar insertar departamentos con el mismo nombre
		config.common().add(new UniqueFieldValueConstraint(Departamento.class, "nombre"));

		//Se desactiva el borrado en cascada para Departamento
		config.common().objectClass(Departamento.class).cascadeOnDelete(false);

		
		  // creamos/abrimos la BD con la configuracion creada
		ObjectContainer db = Db4oEmbedded.openFile(config, BDEMP);
		
		return db;
	}
	
	/*
	 * INSERTAR OBJETOS
	 */

	/**
	 * @param dep Nuevo departamento a insertar pero sin ArrayList<Empleado>
	 */
	public static void Insert_Departamento(Departamento dep) {
		ObjectContainer db = GetConexionBD();// obtener la conexion a la BD
		db.store(dep);// almacenamos el objeto empleado
		db.commit();
		db.close(); // cerrar base de datos
	}
	
	/**
	 * @param emp Nuevo empleado a insertar pero sin el objeto Departamento
	 */
	public static void Insert_Empleado(Empleado emp) {
		ObjectContainer db = GetConexionBD();// obtener la conexion a la BD
		db.store(emp);// almacenamos el objeto empleado
		db.commit();
		db.close(); // cerrar base de datos
	}
	
	/*
	 * ACTUALIZAR ATRIBUTOS DE LAS RELACIONES
	 */
	
	/**
	 * 
	 * @param emp Empleado ya existente en la BD, al cual vamos a asignar el Departamento (@param dep)
	 * 
	 * @param dep Departamento ya existente en la BD, el cual vamos a asignar al Empleado (@param emp)
	 */
	public static void SetDepartamentoEmpleado(Empleado emp, Departamento dep) {
		ObjectContainer db = GetConexionBD();//Obtener la conexion a la BD
		
		Empleado emp_query = new Empleado(emp.getNombre(), emp.getApellidos());
		Departamento depto_query = new Departamento(dep.getNombre(), dep.getLocalidad());
		
		ObjectSet<Empleado> osemp = db.queryByExample(emp_query);
		ObjectSet<Departamento> osdep = db.queryByExample(depto_query);
		
		if (osemp.size() > 0) {
			//hemos encontrado el empleado
			Empleado empleado = osemp.next();
			if (osdep.size() > 0) {
				//hemos encontrado el Departameno, por lo tanto actualizamos el campo Departamento del Empleado
				empleado.setDepart(osdep.next());
				//guardamos el objeto Empleado
				db.store(empleado);
			}
		}
		db.commit();
		db.close();
	}
	
	/**
	 * 
	 * @param emp Empleado ya existente en la BD, el cual vamos a anadir al ArrayList del Departamento
	 * 
	 * @param dep Departamento ya existente en la BD al cual se le va a anadir el empleado
	 */
	public static void AddEmpleadoDepartamento(Empleado emp, Departamento dep) {
		ObjectContainer db = GetConexionBD();// obtener la conexion a la BD
		Empleado emp_query = new Empleado(emp.getNombre(), emp.getApellidos());
		Departamento depto_query = new Departamento(dep.getNombre(), dep.getLocalidad());
		//buscamos el empleado
		ObjectSet<Empleado> osemp = db.queryByExample(emp_query);
		//buscamos el departamento
		ObjectSet<Departamento> osdep = db.queryByExample(depto_query);
		
		if (osdep.size() > 0) {
			//existe el departamento
			Departamento dept = osdep.next();
			if (osemp.size() > 0) {
				//existe el empleado a anadir
				dept.addEmpleados(osemp.next());
				//actualizamos el departamento
				db.store(dept);
			}
		}
		db.commit();
		db.close();
	}
	
	/*
	 * BORRAR OBJETOS
	 */
	
	public static void RemoveDepartamento(Departamento dep) {
		ObjectContainer db = GetConexionBD();
		Departamento depto_query = new Departamento(dep.getNombre(), dep.getLocalidad());
		//buscamos el departamento
		ObjectSet<Departamento> osdep = db.queryByExample(depto_query);
		
		if (osdep.size() > 0) {
			//existe el departamento, lo borramos
			Departamento dept = osdep.next();
			db.delete(dept);
		}
		db.commit();
		db.close();
	}
}

