package e01;

import java.util.Scanner;

/**
*@author Sebas Lavigne
*/

public class Main {
	
	public static String inputString() {
		return new Scanner(System.in).nextLine();
	}


	public static void main(String[] args) {
		String[] options = {
				"Ver empleados",
				"Ver departamentos",
				"Ver empleados de un departamento",
				"Anadir un empleado",
				"Anadir un departamento",
				"Asignar un empleado a un departamento",
				"Cambiar datos de un empleado",
				"Cambiar la localidad de un departamento",
				"Cambiar un empleado de departamento",
				"Eliminar un departamento",
				};
		
		boolean done = false;
		int option;
		//Strings auxiliares
		String s1, s2, s3;
		while (!done) {
			option = menu.Menu.generateMenu(options, true, "Base de datos OO");
			switch (option) {
			case -1: //Salir
				System.out.println("Saliendo del programa...");
				done = true;
				break;
			case 0: //Ver empleados
				e01Access.showEmpleados();
				break;
			case 1: //Ver departamentos
				e01Access.showDepartamentos();
				break;
			case 2: //Ver empleados en un departamento
				System.out.println("Introduce el nombre del departamento");
				e01Access.showEmpleadosFromDepartamento(
						new Departamento(inputString(), null)
						);
				break;
			case 3: //Anadir empleado
				System.out.println("Introduce el nombre del empleado");
				s1 = inputString();
				System.out.println("Introduce los apellidos del empleado");
				s2 = inputString();
				e01Access.Insert_Empleado(
						new Empleado(s1, s2)
						);
				break;
			case 4: //Anadir departamento
				System.out.println("Introduce el nombre del departamento");
				s1 = inputString();
				System.out.println("Introduce la localidad del departamento");
				s2 = inputString();
				e01Access.Insert_Departamento(
						new Departamento(s1, s2)
						);
				break;
			case 5: //Asignar departamento
				System.out.println("Introduce el nombre del empleado");
				s1 = inputString();
				System.out.println("Introduce los apellidos del empleado");
				s2 = inputString();
				System.out.println("Introduce el nombre del departamento");
				s3 = inputString();
				e01Access.SetDepartamentoEmpleado(
						new Empleado(s1,s2),
						new Departamento(s3, null)
						);
				e01Access.AddEmpleadoDepartamento(
						new Empleado(s1,s2),
						new Departamento(s3, null)
						);
				break;
			case 6: //Cambiar datos empleado
				System.out.println("Introduce el nombre del empleado");
				s1 = inputString();
				System.out.println("Introduce los apellidos del empleado");
				s2 = inputString();
				e01Access.UpdateEmpleado(new Empleado(s1, s2));
				break;
			case 7: //Cambiar localidad departamento
				System.out.println("Introduce el departamento");
				s1 = inputString();
				e01Access.UpdateDepartamento(new Departamento(s1,  null));
				break;
			case 8: //Cambiar empleado de departamento
				System.out.println("Introduce el nombre del empleado");
				s1 = inputString();
				System.out.println("Introduce los apellidos del empleado");
				s2 = inputString();
				System.out.println("Introduce el nombre de su nuevo departamento");
				s3 = inputString();
				e01Access.CambiarEmpleadoDepartamento(
						new Empleado(s1,s2),
						new Departamento(s3, null)
						);
				break;
			case 9: //Borrar departamento
				System.out.println("Introduce el departamento");
				s1 = inputString();
				e01Access.DeleteDepartamento(new Departamento(s1, null));
				break;
			}
			
			//Nulifica los String auxiliares
			s1 = s2 = s3 = null;
			
			if (option != -1) {
				System.out.println("\nPulsa INTRO para continuar");
				inputString();
			}
		}
	}
}
