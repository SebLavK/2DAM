package e11;

import java.util.concurrent.Semaphore;

/**
 * @author Sebas Lavigne
 */

public class Pump extends Thread{

	public static final int INLET = 0;
	public static final int OUTLET = 1;

	private int type;
	private int num;
	private float pumpAmount;
	private WaterTank tank;
	
	private Semaphore valve;

	public Pump(int type, int num, float pumpAmount, WaterTank tank) {
		this.type = type;
		this.num = num;
		this.pumpAmount = pumpAmount;
		this.tank = tank;
		
		valve = new Semaphore(0);
	}

	@Override
	public String toString() {
		return (type == INLET ? "IN " : "OUT")+"-"+num;
	}

	/**
	 * Manda meter o sacar agua en funcion del tipo de bomba
	 */
	@Override
	public void run() {
		if (type == INLET) {
			tank.pumpIn(this, pumpAmount);
		} else {
			tank.pumpOut(this, pumpAmount);
		}
	}
	
	/**
	 * "Abre" la valvula para que la bomba
	 * meta o saque agua del tanque
	 */
	public void releaseValve() {
		valve.release();
	}
	
	/**
	 * "Cierra" la valvula para que la bomba
	 * espere a meter o sacar agua
	 */
	public void shutValve() {
		try {
			valve.acquire();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @return La cantidad de agua que esta bomba quiere bombear
	 */
	public float getPumpAmount() {
		return pumpAmount;
	}

}
