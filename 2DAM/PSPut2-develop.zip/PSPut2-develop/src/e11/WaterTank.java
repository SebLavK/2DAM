package e11;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.concurrent.Semaphore;

/**
 * @author Sebas Lavigne
 */

public class WaterTank {

	public static final float DEFAULT_CAPACITY = 200;

	private float capacity;
	private float store;

	private Semaphore mutex;

	private TreeSet<Pump> inputSet;
	private TreeSet<Pump> outputSet;

	public WaterTank(float store, float capacity) {
		this.store = store;
		this.capacity = capacity;

		mutex = new Semaphore(1, true);

		/*
		 * Los TreeSet mantienen su coleccion ordenada mediante el comparador con el que
		 * se crean. El comparador de cada uno se pasa como metodo por referencia
		 * mediante lambda
		 */

		// Para llenar el tanque se buscara la primera
		// bomba que lo llene sin pasarse
		inputSet = new TreeSet<>(this::comparePumpsDescending);
		// Para vaciar el tanque se llamara siempre
		// a la bomba de menor cantidad primero
		// Si la de menor cantidad no puede sacar,
		// las demas tampoco
		outputSet = new TreeSet<>(this::comparePumpsAscending);
	}

	@Override
	public String toString() {
		return "Tanque: (" + store + "/" + capacity + ")";
	}

	/**
	 * Abre las valvulas de las bombas que quieren meter agua empezando por la de
	 * mayor cantidad siempre que no desborde el tanque
	 */
	public void releaseInputs() {
		Iterator<Pump> it = inputSet.iterator();
		//Este ArrayList contendra los elementos que se quieran
		//quitar del TreeSet.
		//Si se quitan durante la iteracion
		//ocurre un ConcurrentModificationException
		ArrayList<Pump> toRemove = new ArrayList<>();
		// Para cada bomba de la lista...
		while (it.hasNext()) {
			Pump pump = (Pump) it.next();
			// Si no desborda...
			if (store + pump.getPumpAmount() <= capacity) {
				// La quita de la lista
				toRemove.add(pump);
				// Abre la valvula
				System.out.println("    --- Se abre la valvula de " + pump);
				pump.releaseValve();
			}
		}

		//Quita todas las bombas necesarias
		inputSet.removeAll(toRemove);
		// Solo muestra el mensaje si hay bombas esperando
		if (inputSet.size() > 0) {
			System.out.println("No hay espacio para meter agua,\nhay " + inputSet.size() + " esperando");
			System.out.println(this);
		}
	}

	/**
	 * La bomba llama a este metodo para meter agua en el tanque Si desborda, espera
	 * a que le den turno
	 * 
	 * Se usa el mutex de cierta manera que solo un hilo recorre el metodo
	 * a la vez
	 * 
	 * @param pump   La bomba
	 * @param amount La cantidad de agua que quiere meter
	 */
	public void pumpIn(Pump pump, float amount) {
		try {
			mutex.acquire();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		System.out.println(pump + " METER AGUA (" + amount + ") " + this);
		// Si al meter agua se pasa...
		//Vuelve a hacer el chequeo de todas formas cuando obtiene permiso
		while (store + amount > capacity) {
			// Anade a la lista de bombas de agua
			inputSet.add(pump);
			// La bloquea
			System.out.println("    XXX Se cierra la valvua de " + pump);
			mutex.release();
			pump.shutValve();
			try {
				mutex.acquire();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		store += amount;
		System.out.println("\t" + pump + " metio agua (" + amount + ") " + this);
		releaseOutputs();
		mutex.release();
		
	}

	/**
	 * Va abriendo valvulas para que las bombas puedan sacar agua, empezando por la
	 * que quiera menor cantidad hasta que no suficiente agua que sacar
	 */
	public void releaseOutputs() {
		boolean theresWater = true;

		// Mientras haya agua...
		while (theresWater && outputSet.size() > 0) {
			// Si hay suficiente para la primer bomba de la lista...
			if (outputSet.first().getPumpAmount() <= store) {
				// Abre la valvula de la bomba
				System.out.println("    --- Se abre la valvula de " + outputSet.first());
				outputSet.pollFirst().releaseValve();
			} else { // Si no...
				// No hay agua, sale del bucle
				theresWater = false;
			}
		}

		// Solo muestra el mensaje si hay bombas esperando
		if (outputSet.size() > 0) {
			System.out.println("No hay mas agua que sacar,\nhay " + outputSet.size() + " esperando");
			System.out.println(this);
		}
	}

	/**
	 * La bomba llama a este metodo para sacar agua del tanque Si no hay suficiente,
	 * espera a que le den turno
	 * 
	 * Se usa el mutex de cierta manera que solo un hilo recorre el metodo
	 * a la vez
	 * 
	 * @param pump   La bomba
	 * @param amount La cantidad de agua que quiere sacar
	 */
	public void pumpOut(Pump pump, float amount) {
		try {
			mutex.acquire();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		System.out.println(pump + " SACAR AGUA (" + amount + ") " + this);
		// Si no hay suficiente agua para sacar...
		//Vuelve a hacer el chequeo cuando obtiene permiso
		while (amount > store) {
			// Anade a la lista de bombas de agua
			outputSet.add(pump);
			// La bloquea
			System.out.println("    XXX Se cierra la valvua de " + pump);
			mutex.release();
			pump.shutValve();
			try {
				mutex.acquire();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		store -= amount;
		System.out.println("\t" + pump + " saco agua (" + amount + ") " + this);
		releaseInputs();
		mutex.release();
		
	}

	/**
	 * Compara dos bombas por la cantidad que bombean para ordenarlas de forma
	 * ascendente
	 * 
	 * @param p1
	 * @param p2
	 * @return
	 */
	public int comparePumpsAscending(Pump p1, Pump p2) {
		return Float.compare(p1.getPumpAmount(), p2.getPumpAmount());
	}

	/**
	 * Compara dos bombas por la cantidad que bombean para ordenarlas de forma
	 * descendente
	 * 
	 * @param p1
	 * @param p2
	 * @return
	 */
	public int comparePumpsDescending(Pump p1, Pump p2) {
		return Float.compare(p2.getPumpAmount(), p1.getPumpAmount());
	}

}
