package e11;

import java.util.Random;

/**
*@author Sebas Lavigne
*/

public class Main {
	/*
	 * La cantidad de agua con la que se inicializa el deposito
	 * JUGAR CON ESTE NUMERO
	 */
	public static final float INITIAL_STORE = 0;

	/**
	 * Crea el deposito y las bombas de agua que lo usan
	 * 
	 * ATENCION: 
	 * 
	 * es posible que se genere aleatoriamente
	 * mas cantidad de agua para meter o sacar y por tanto
	 * algun hilo quede siempre esperando. Esto es normal,
	 * y se puede evitar cambiando la cantidad de agua
	 * inicial a un valor medio de la capacidad total
	 * @param args
	 */
	public static void main(String[] args) {
		Random rd = new Random();
		WaterTank tank = new WaterTank(INITIAL_STORE, WaterTank.DEFAULT_CAPACITY);
		Pump[] pumps = new Pump[12];
		
		for (int i = 0; i < pumps.length; i++) {
			pumps[i] = new Pump(i%2, i/2, rd.nextInt(30)+10, tank);
		}
		
		for (int i = 0; i < pumps.length; i++) {
			pumps[i].start();
		}
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		int threads = Thread.activeCount() - 1;
		if (threads > 0) {
			System.out.println("\nQuedan "+(threads)+" hilos en funcionamiento");
			System.out.println("Esto no es un error, algun hilo esta esperando\n"
					+ "porque no puede meter o sacar toda el agua que quiere:");
			System.out.println("\nCierra el programa manualmente");
		}
	}
}
