package e09;

import java.util.Random;
import java.util.concurrent.Semaphore;

/**
 * Simula una sala de baile en la que siempre debe haber
 * un numero equitativo de mujeres y hombres.
 * 
 * @author Sebas Lavigne
 */
public class DanceRoom {

	/* Exclusion mutua */
	private Semaphore mutex;
	/* La portera de hombres */
	private Semaphore bouncerMen;
	/* El portero de mujeres */
	private Semaphore bouncerWomen;

	private int men;
	private int women;

	public DanceRoom() {
		mutex = new Semaphore(1);
		bouncerMen = new Semaphore(1, true);
		bouncerWomen = new Semaphore(1, true);
	}
	
	/**
	 * Devuelve la inigualdad de la sala de baile, es decir,
	 * el valor absoluto de la diferencia entre mujeres y hombres
	 * @return un entero
	 */
	private int inequality() {
		return Math.abs(men - women);
	}
	
	/**
	 * Devuelve si hay mas hombres que mujeres. No importa que el numero sea igual,
	 * este metodo debe usarse despues de chequear la inigualdad.
	 * 
	 * Si se evalua este metodo frente al sexo de un Peep se da verdadero si
	 * el sexo esta en mayoria
	 * 
	 * @return Verdadero si hay mas hombres que mujeres.
	 * Falso si hay mas mujeres que hombres (o igual numero)
	 */
	private boolean patriarchy() {
		return men > women;
	}

	/**
	 * Controla la entrada de personas en la sala de baile
	 * @param peep La persona que quiere entrar
	 */
	public void entry(Peep peep) {
		try {
			mutex.acquire();
			System.out.println(peep + " quiere entrar a la sala de baile "+ this);
			mutex.release();
			
			//Intenta entrar
			if (peep.isMale()) { bouncerMen.acquire(); } else {	bouncerWomen.acquire(); }
			
			//Una vez entra...
			mutex.acquire();
			
				//Suma la cantidad de personas
				if (peep.isMale()) { men++; } else { women++; }
				
				/*
				 * Reajuste de permisos
				 * Hay dos supuestos en los que se le da permiso al sexo contrario
				 * para entrar:
				 * 
				 *  - Habia "deficit" de un sexo y despues de entrar varios del sexo
				 *  contrario ahora hay igualdad
				 *  - Habia igualdad y ahora al entrar la inigualdad es 1 (por
				 *  tanto la inigualdad va a favor de su sexo)
				 */
				
				if (inequality() == 0 || (inequality() == 1 && patriarchy() == peep.isMale()) ) {
					//Da permiso al sexo contrario
					if (peep.isMale()) { bouncerWomen.release(); } else { bouncerMen.release(); }
				}
			
			System.out.println("\t" + peep + " ha entrado "+this);
			mutex.release();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Chunda chunda
	 * @param peep La persona que baila
	 */
	public void dance(Peep peep) {
		try {
			mutex.acquire();
			System.out.println("\t\t" + peep + " esta bailando " + this);
			mutex.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		try {
			Thread.sleep(new Random().nextInt(2000) + 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Controla la salida de la sala de baile
	 * Cuando una persona sale se da permiso para que entre otra
	 * del mismo sexo, salvo en el caso de que al salir
	 * haya mucha inigualdad
	 * @param peep La persona que sale
	 */
	public void exit(Peep peep) {
		try {
			mutex.acquire();
				
				//Resta la cantidad de personas
				if (peep.isMale()) { men--; } else { women--; }
				
				/*
				 * Reajuste de permisos
				 * Despues de que alguien se vaya
				 * se dan tres supuestos:
				 * - Hay mayoria de su sexo, quita un permiso del sexo contrario
				 * - Hay igualdad, quita un permiso del sexo contrario y da uno del suyo
				 * - Hay minoria de su sexo, da un permiso a su mismo sexo
				 * 
				 * Por tanto:
				 * - Se quita un permiso del sexo contrario cuando
				 * hay igualdad o mayoria del sexo propio
				 * - Se anade un permiso del propio sexo cuando
				 * hay igualdad o minoria del sexo propio 
				 */
				
				//Si hay igualdad o mayoria del sexo propio
				if (inequality() == 0 || (inequality() > 0 && patriarchy() == peep.isMale())) {
					//Quita un permiso del sexo contrario
					if (peep.isMale()) { bouncerWomen.tryAcquire(); } else { bouncerMen.tryAcquire(); } 
				}
				
				//Si hay igualdad o minoria del sexo propio
				if (inequality() == 0 || (inequality() > 0 && patriarchy() != peep.isMale())) {
					//Da un permiso a su sexo
					if (peep.isMale()) { bouncerMen.release(); } else { bouncerWomen.release(); }
				}
				
			System.out.println("\t\t\t"+peep + " se va "+this);
			mutex.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		return "("+bouncerWomen.availablePermits()+","+bouncerMen.availablePermits()+")"+"[M:" + women + ",H:" + men + "] (!= " + inequality() +")";
	}

}
