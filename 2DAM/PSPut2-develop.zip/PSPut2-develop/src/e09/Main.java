package e09;

import java.util.HashSet;

/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static final int WOMEN_AMOUNT = 12;
	public static final int MEN_AMOUNT = 8;

	public static void main(String[] args) {
		DanceRoom danceRoom = new DanceRoom();
		HashSet<Peep> people = new HashSet<>();
		
		for (int i = 0; i < WOMEN_AMOUNT; i++) {
			people.add(new Peep(danceRoom, Peep.FEMALE, i));
		}
		
		for (int i = 0; i < MEN_AMOUNT; i++) {
			people.add(new Peep(danceRoom, Peep.MALE, i));
		}
		
		for (Peep peep : people) {
			peep.start();
		}
	}
}

