package e09;

import java.util.Random;

/**
*@author Sebas Lavigne
*
*/

public class Peep extends Thread {
	
	public static final boolean MALE = true;
	public static final boolean FEMALE = false;
	
	private DanceRoom danceRoom;
	private boolean male;
	private int num;
	
	/**
	 * @param male
	 * @param num
	 */
	public Peep(DanceRoom danceRoom, boolean male, int num) {
		this.danceRoom = danceRoom;
		this.male = male;
		this.num = num;
	}
	
	public boolean isMale() {
		return male;
	}
	
	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			try {
				Thread.sleep(new Random().nextInt(2000)+1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			danceRoom.entry(this);
			danceRoom.dance(this);
			danceRoom.exit(this);
		}
	}



	@Override
	public String toString() {
		return (male ? "Hombre" : "Mujer") + "-" + num;
	}
	
}

