package e07;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.Semaphore;

public class Main {

	/*
	 * El productor escribira al final del fichero El consumidor leera la siguiente
	 * linea de un BufferedReader De esta manera el fichero de texto se comporta
	 * como una lista
	 */
	public static final File textFile = new File("cadenas.txt");

	public static void main(String[] args) {
		Semaphore vacio = new Semaphore(0);// semáforo sin permisos, el primero que llame a acquire() se bloqueará
		Semaphore lleno = new Semaphore(5); // semáforo que se bloqueará cuando el buffer esté lleno
		Semaphore mutex = new Semaphore(1); // semáforo para la sección crítica.
		Consumidor[] consumidores = new Consumidor[2];
		Productor[] productores = new Productor[2];

		/*
		 * Crea un BufferedReader para compartir entre los consumidores
		 */
		if (textFile.exists()) {
			textFile.delete();
		}
		try {
			textFile.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		FileReader fr;
		try {
			fr = new FileReader(textFile);
			BufferedReader br = new BufferedReader(fr);

			for (int i = 0; i < consumidores.length; i++) {
				consumidores[i] = new Consumidor("C" + (i + 1), vacio, lleno, mutex, br);
				consumidores[i].start();
			}
			for (int i = 0; i < productores.length; i++) {
				productores[i] = new Productor("P" + (i + 1), vacio, lleno, mutex);
				productores[i].start();
			}

			/*
			 * Espera a que terminen los consumidores para cerrar el flujo del
			 * BufferedReader
			 */
			for (int i = 0; i < consumidores.length; i++) {
				consumidores[i].join();
			}

			br.close();
			fr.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}