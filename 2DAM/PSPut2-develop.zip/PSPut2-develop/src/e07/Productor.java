package e07;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.Semaphore;

public class Productor extends Thread {
	String name;
	Semaphore vacio; // cola para esperar cuando está vacío
	Semaphore lleno; // cola para esperar cuando está lleno
	Semaphore mutex;

	public Productor(String name, Semaphore vacio, Semaphore lleno, Semaphore mutex) {
		this.name = name;
		this.vacio = vacio;
		this.lleno = lleno;
		this.mutex = mutex;
	}
	
	private void writeToFile(String produce) {
		try {
			FileWriter fw = new FileWriter(Main.textFile, true);
			PrintWriter pw = new PrintWriter(fw);
			
			pw.println("Cadena "+produce+" escrita por el productor "+ name);
			
			pw.close();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// vamos a repetir el proceso 5 veces (producimos 5 números cada vez)
		for (int i = 0; i < 5; i++) {
			try {
				lleno.acquire();// tomamos un permiso del semáforo (inicialmente son 5)
				mutex.acquire();// para acceder en exclusión mutua a la cola
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			String produce = name + "-" + i;
			// insertamos un elemento en la cola
			Buffer.cola.offer(produce);
			System.out.println("Productor " + name + " produce " + produce);
			Buffer.mostrarCola();
			
			/* Codigo del ejercicio 7
			 */
			System.out.println("El productor "+name+" ha escrito al fichero");
			writeToFile(produce);
			
			
			mutex.release();// salimos de la exclusión mutua
			vacio.release();// liberamos un permiso de vacío, avisamos que está lleno
		}
	}
}