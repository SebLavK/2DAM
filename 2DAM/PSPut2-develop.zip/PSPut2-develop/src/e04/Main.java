package e04;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class Main {

	public static void main(String[] args) {
		//Crea objetos
		Semaphore mutex = new Semaphore(1, true);
		BalloonPopper[] friends = new BalloonPopper[3];
		Thread[] threads = new Thread[friends.length];
		
		//Instancia a los amigos y los hilos
		for (int i = 0; i < friends.length; i++) {
			friends[i] = new BalloonPopper(mutex);
			threads[i] = new Thread(friends[i], "Amigo "+i);
		}
		
		//Inicia los hilos
		for (int i = 0; i < threads.length; i++) {
			threads[i].start();
		}
		
		//Espera a que terminen los hilos y muestra por pantalla
		int total = 0;
		for (int i = 0; i < threads.length; i++) {
			try {
				threads[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("El "+threads[i].getName()+" ha reventado "+friends[i].getPopped());
			total += friends[i].getPopped();
		}
		System.out.println("Total de globos reventados "+total);
		
	}
}

