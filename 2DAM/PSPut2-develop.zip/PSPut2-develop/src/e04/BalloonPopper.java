package e04;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class BalloonPopper implements Runnable {
	
	public static final int INIT_BALLOONS = 1000;
	
	public static int balloons = INIT_BALLOONS;
	
	private Semaphore mutex;
	private int popped;
	
	public BalloonPopper(Semaphore mutex) {
		this.mutex = mutex;
		this.popped = 0;
	}

	/**
	 * Intenta reventar globos hasta que no queden mas
	 */
	@Override
	public void run() {
		//Mientras haya globos...
		while (balloons != 0) {
			try {
				//Intenta tomar la "aguja" de reventar globos
				mutex.acquire();
				//Si hay globos...
				if (balloons != 0) {
					//Revienta un globo
					balloons--;
					//Suma su propio tanto
					popped++;
				}
				//Suelta la "aguja"
				mutex.release();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Thread.yield();
		}
	}

	/**
	 * @return La cantidad de globos reventados
	 */
	public int getPopped() {
		return popped;
	}

}

