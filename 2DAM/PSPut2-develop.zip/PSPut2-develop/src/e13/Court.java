package e13;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*/

public class Court {
	
	private int waitingForTeam;
	private int waitingForEntry;
	private int playing;
	
	private boolean courtInUse;
	
	private Semaphore mutex;
	private Semaphore teamQueue;
	private Semaphore entryQueue;
	
	public Court() {
		waitingForTeam = 0;
		waitingForEntry = 0;
		playing = 0;
		
		courtInUse = false;
		
		mutex = new Semaphore(1);
		teamQueue = new Semaphore(0);
		entryQueue = new Semaphore(0, true);
	}
	
	public void enter(String player) {
		try {
			mutex.acquire();
			System.out.println(player+" quiere jugar");
			while (courtInUse) {
				waitingForEntry++;
				mutex.release();
				entryQueue.acquire();
				mutex.acquire();
			}
			mutex.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void formTeam(String player) {
		try {
			mutex.acquire();
			
			waitingForTeam ++;
			System.out.println("\t"+player+" esta esperando a formar equipos "+waitingForTeam);
			if (waitingForTeam == 4) {
				System.out.println("\tYa somos 4! Podemos empezar");
				courtInUse = true;
				waitingForTeam = 0;
				teamQueue.release(4);
			}
			mutex.release();
			teamQueue.acquire();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void play(String player) {
		try {
			mutex.acquire();
			playing++;
			System.out.println("\t\t"+player+ " esta jugando");
			mutex.release();
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void leave(String player) {
		try {
			mutex.acquire();
			playing--;
			System.out.println("\t\t\t"+player+" abandona la cancha");
			if (playing == 0) {
				courtInUse = false;
				entryQueue.release(waitingForEntry);
				waitingForEntry = 0;
			}
			mutex.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}
