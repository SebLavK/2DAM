package e13;

import java.util.Random;

/**
*@author Sebas Lavigne
*/

public class Player extends Thread{

	private String name;
	private Court court;
	
	public Player(String name, Court court) {
		super();
		this.name = name;
		this.court = court;
	}

	@Override
	public void run() {
		for (int i = 0; i < 4; i++) {
			try {
				Thread.sleep(new Random().nextInt(4000)+1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			court.enter(name);
			court.formTeam(name);
			court.play(name);
			court.leave(name);
		}
	}

	
	
}
