package e13;

/**
*@author Sebas Lavigne
*/

public class Main {

	public static void main(String[] args) {
		Court court = new Court();
		String[] names = {"Alice","Bob","Carol","Dan","Erin","Frank","Grace","Heidi","Isabel","Judy"};
		Player[] players = new Player[7];
		
		for (int i = 0; i < players.length; i++) {
			players[i] = new Player(names[i], court);
		}
		
		for (int i = 0; i < players.length; i++) {
			players[i].start();
		}
	}
}
