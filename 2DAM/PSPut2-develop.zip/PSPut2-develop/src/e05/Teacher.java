package e05;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class Teacher extends Thread {
	
	private Semaphore staffRoomEntry;

	/**
	 * @param staffRoomEntry
	 */
	public Teacher(Semaphore staffRoomEntry) {
		super();
		this.staffRoomEntry = staffRoomEntry;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				staffRoomEntry.acquire();
				System.out.println("-> El "+this.getName()+" entra en la sala");
				Thread.sleep(200);
				System.out.println("<- El "+this.getName()+" sale de la sala");
				staffRoomEntry.release();
				Thread.sleep(20);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}

