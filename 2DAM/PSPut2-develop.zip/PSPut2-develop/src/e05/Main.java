package e05;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static final int STAFF_ROOM_CAPACITY = 3;
	public static final int TOTAL_TEACHER_AMOUNT = 7;

	public static void main(String[] args) {
		
		Semaphore staffRoomEntry = new Semaphore(STAFF_ROOM_CAPACITY, true);
		Teacher[] teachers = new Teacher[TOTAL_TEACHER_AMOUNT];
		
		for (int i = 0; i < teachers.length; i++) {
			teachers[i] = new Teacher(staffRoomEntry);
			teachers[i].setName("Profesor "+i);
		}
		
		for (int i = 0; i < teachers.length; i++) {
			teachers[i].start();
		}
		
	}
}

