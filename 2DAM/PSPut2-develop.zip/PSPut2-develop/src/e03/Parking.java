package e03;

import java.util.Random;
import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class Parking {
	
	public static final int CAPACITY = 4;
	
	private Semaphore mutex;
	private Semaphore entry;
	private boolean[] spots;
	private int[] cars;
	
	public Parking() {
		mutex = new Semaphore(1);
		entry = new Semaphore(CAPACITY, true);
		spots = new boolean[CAPACITY];
		cars = new int[CAPACITY];
		//Una plaza da falso si esta vacia
		for (int i = 0; i < CAPACITY; i++) {
			spots[i] = false;
			cars[i] = -1;
		}
	}
	
	@Override
	public String toString() {
		String string = "PARKING\n|";
		for (int i = 0; i < spots.length; i++) {
			string += " "+(spots[i] ? "X" : " ")+" |";
		}
		string += "\n|";
		for (int i = 0; i < cars.length; i++) {
			string += " "+(spots[i] ? cars[i] : " ")+" |";
		}
		return string;
	}
	
	/**
	 * Ocupa una plaza del parking
	 * @param num el numero del coche
	 */
	public void takeSpot(int num) {
		int i = 0;
		boolean parked = false;
		do {
			if (! spots[i]) { //Si la plaza esta vacia
				spots[i] = true;
				cars[i] = num;
				parked = true;
			}
			i++;
		} while (! parked);
	}
	
	/**
	 * Libera una plaza del parking
	 * @param num el numero del coche
	 */
	public void leaveSpot(int num) {
		int i = 0;
		boolean left = false;
		//Busca la plaza donde esta aparcado el coche numero num
		do {
			if (cars[i] == num) {
				cars[i] = -1;
				spots[i] = false;
				left = true;
			}
			i++;
		} while (! left);
	}
	
	/**
	 * El semaforo de entrada ahora se ejecuta aqui
	 * @param carNum el numero del coche que entra a aparcar
	 */
	public void park(int carNum) {
		System.out.println("||El coche numero "+carNum+" llega al parking e intenta entrar");
		try {
			entry.acquire();
			
				mutex.acquire();
					System.out.println("=>El coche numero "+carNum+" entra al parking");
					System.out.println("El parking tiene "
							+entry.availablePermits()+" plazas libres");
					takeSpot(carNum);
					System.out.println(this);
					System.out.println("Coches esperando para entrar: "+entry.getQueueLength());
				mutex.release();
				
				Thread.sleep(new Random().nextInt(5000)+3000);
				
				mutex.acquire();
					System.out.println("\t<=El coche numero "+carNum+" sale del parking");
					leaveSpot(carNum);
					System.out.println(this);
				mutex.release();
				
			entry.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	

}

