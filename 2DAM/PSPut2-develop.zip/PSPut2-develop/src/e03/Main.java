package e03;


/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static final int CAR_AMOUNT = 10;

	public static void main(String[] args) {
		Parking parking = new Parking();
		Car[] cars = new Car[CAR_AMOUNT];
		Thread[] carThreads = new Thread[CAR_AMOUNT];
		for (int i = 0; i < cars.length; i++) {
			cars[i] = new Car(parking, i);
			carThreads[i] = new Thread(cars[i]);
		}
		
		for (int i = 0; i < carThreads.length; i++) {
			carThreads[i].start();
		}
	}
}

