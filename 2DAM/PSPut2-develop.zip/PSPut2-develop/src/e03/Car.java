package e03;

import java.util.Random;

/**
*@author Sebas Lavigne
*
*/

public class Car implements Runnable {
	
	Parking parking;
	int num;
	
	/**
	 * @param entrySemaphore
	 * @param num
	 */
	public Car(Parking parking, int num) {
		super();
		this.parking = parking;
		this.num = num;
	}

	@Override
	public void run() {
		System.out.println("Arranca el coche numero "+num);
		try {
			Thread.sleep(new Random().nextInt(3000)+1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		parking.park(num);
	}

	/**
	 * @return the num
	 */
	public int getNum() {
		return num;
	}
	
	/**
	 * @param num the num to set
	 */
	public void setNum(int num) {
		this.num = num;
	}
}

