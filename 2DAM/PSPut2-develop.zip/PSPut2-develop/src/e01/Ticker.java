package e01;

import java.util.concurrent.Semaphore;

/**
 * Esta clase es un simple contador. Cada instancia debe trabajar en conjunto
 * con otra, usando dos semaforos. El semaforo de una instancia se libera
 * desde la otra instancia
 * 
 * @author Sebas Lavigne
 */
public class Ticker extends Thread {
	
	public static final long TICK_TIME = 1000;
	
	private String msg;
	private Semaphore myBlock;
	private Semaphore otherBlock;
	
	/**
	 * @param msg el mensaje a mostrar por pantalla
	 * @param myBlock el semaforo que controla este hilo,
	 * del que obtiene paso
	 * @param otherBlock el semaforo que controla el otro hilo,
	 * al que otorga paso
	 */
	public Ticker(String msg, Semaphore myBlock, Semaphore otherBlock) {
		super();
		this.msg = msg;
		this.myBlock = myBlock;
		this.otherBlock = otherBlock;
	}

	/**
	 * El hilo espera al semaforo de su bloque
	 * Cuando adquiere el paso muestra su mensaje (TIC o TAC)
	 * espera un segundo y abre el paso al semaforo del otro bloque
	 */
	@Override
	public void run() {
		while (true) {
			try {
				myBlock.acquire();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(msg);
			try {
				Thread.sleep(TICK_TIME);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			otherBlock.release();
		}
	}

	
	
}

