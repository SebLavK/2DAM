package e01;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static void main(String[] args) {
		
		Semaphore ticBlock = new Semaphore(1);
		Semaphore tacBlock = new Semaphore(0);
		
		Ticker tic = new Ticker("TIC", ticBlock, tacBlock);
		Ticker tac = new Ticker("TAC", tacBlock, ticBlock);
		
		tic.start();
		tac.start();
		
	}
}

