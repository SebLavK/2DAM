package e02;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class FinalThread extends Thread {
	
	private Semaphore finalBlock;

	/**
	 * @param finalBlock el semaforo que controla a este hilo
	 */
	public FinalThread(Semaphore finalBlock) {
		super();
		this.finalBlock = finalBlock;
	}

	/**
	 * Intenta adquirir el semaforo, pero debe esperar que otros 30 hilos
	 * le hagan un release()
	 */
	@Override
	public void run() {
		try {
			finalBlock.acquire(30);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Hola, soy el hilo FINAL");
	}
	
	

}

