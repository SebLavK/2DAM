package e02;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class InitialThread extends Thread {
	
	private int id;
	private Semaphore finalBlock;

	/**
	 * @param id el numero del hilo
	 * @param finalBlock el semaforo que controla un FinalThread
	 */
	public InitialThread(int id, Semaphore finalBlock) {
		super();
		this.id = id;
		this.finalBlock = finalBlock;
	}

	/**
	 * Pinta por pantalla su identificador e incrementa el semaforo de
	 * un FinalThread
	 */
	@Override
	public void run() {
		System.out.println("Hola, soy el hilo "+id);
		finalBlock.release();
	}
	
	
}

