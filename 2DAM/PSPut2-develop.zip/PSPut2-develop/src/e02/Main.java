package e02;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class Main {

	public static void main(String[] args) {
		Semaphore finalBlock = new Semaphore(0);
		FinalThread finalThread = new FinalThread(finalBlock);
		InitialThread[] initialThread = new InitialThread[30];
		
		for (int i = 0; i < initialThread.length; i++) {
			initialThread[i] = new InitialThread(i+1, finalBlock);
		}
		
		finalThread.start();
		for (int i = 0; i < initialThread.length; i++) {
			initialThread[i].start();
		}
	}
}

