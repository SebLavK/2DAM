package e06;

import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*
*/

public class Cage {

	private Semaphore feeder;
	private Semaphore swing;
	
	public Cage() {
		//Solo tres canarios pueden comer a la vez
		feeder = new Semaphore(3, true);
		//Solo un canario puede columpiarse a la vez
		swing = new Semaphore(1, true);
	}
	
	/**
	 * Metodo para comer del comedero
	 */
	public void feed() {
		try {
			feeder.acquire();
			System.out.println("O> ... El "+Thread.currentThread().getName()+" empieza a comer");
			Thread.sleep(5000);
			System.out.println("<O ... El "+Thread.currentThread().getName()+" termina de comer");
			feeder.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Metodo para subirse al columpio
	 */
	public void swing() {
		try {
			swing.acquire();
			System.out.println("\\\\_O>_\\\\ El "+Thread.currentThread().getName()+" sube al columpio");
			Thread.sleep(6000);
			System.out.println("//_<O_// El "+Thread.currentThread().getName()+" se baja del columpio");
			swing.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		 
	}
}

