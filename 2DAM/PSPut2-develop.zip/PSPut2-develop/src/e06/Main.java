package e06;

/**
*@author Sebas Lavigne
*
*/

public class Main {
	
	public static final int CANARY_AMOUNT = 10;

	public static void main(String[] args) {
		//Crea objetos
		Cage cage = new Cage();
		Canary[] canaries = new Canary[CANARY_AMOUNT];
		Thread[] threads = new Thread[canaries.length];
		
		//Instancia canarios e hilos
		for (int i = 0; i < canaries.length; i++) {
			canaries[i] = new Canary(cage);
			threads[i] = new Thread(canaries[i], "canario "+i);	
		}
		
		//Lanza hilos
		for (int i = 0; i < threads.length; i++) {
			threads[i].start();
		}
	}
}

