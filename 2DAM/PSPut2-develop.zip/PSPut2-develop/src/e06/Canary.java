package e06;

/**
*@author Sebas Lavigne
*
*/

public class Canary implements Runnable{

	private Cage cage;
	
	
	
	/**
	 * @param cage La jaula donde esta el canario
	 */
	public Canary(Cage cage) {
		super();
		this.cage = cage;
	}



	/**
	 * Un canario intentara comer y luego subirse al columpio de su jaula
	 */
	@Override
	public void run() {
		//Comer en la jaula
		cage.feed();
		//Columpiarse en la jaula
		cage.swing();
	}

	
}

