package e12;

import java.util.Random;

/**
*@author Sebas Lavigne
*/

public class Main {

	public static void main(String[] args) {
		Lift lift = new Lift();
		String[] names = {"Alice","Bob","Carol","Dan","Erin","Frank","Grace","Heidi","Isabel","Judy"};
		Peep[] people = new Peep[7];
		Random rd = new Random();
		
		for (int i = 0; i < people.length; i++) {
			people[i] = new Peep(names[i], rd.nextFloat()*70+50, lift);
		}
		
		for (int i = 0; i < people.length; i++) {
			people[i].start();
		}
	}
}
