package e12;

/**
*@author Sebas Lavigne
*/

public class Peep extends Thread {

	private String name;
	private float weight;
	private Lift lift;
	
	public Peep(String name, float weight, Lift lift) {
		super();
		this.name = name;
		this.weight = weight;
		this.lift = lift;
	}

	

	@Override
	public void run() {
		lift.getOn(this);
		lift.use();
		lift.getOff(this);
	}



	@Override
	public String toString() {
		return name+"("+String.format("%.2f", weight)+"kg)";
	}
	
	/**
	 * @return the weight
	 */
	public float getWeight() {
		return weight;
	}

}
