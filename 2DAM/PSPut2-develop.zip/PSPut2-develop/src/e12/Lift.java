package e12;

import java.util.HashSet;
import java.util.Random;
import java.util.concurrent.Semaphore;

/**
*@author Sebas Lavigne
*/

public class Lift {
	
	private float weightLimit;
	private int peopleLimit;
	private int peopleWaiting;
	
	
	private HashSet<Peep> peopleInLift;
	
	private Semaphore mutex;
	private Semaphore board;
	
	public Lift() {
		weightLimit = 450;
		peopleLimit = 6;
		
		peopleInLift = new HashSet<>();
		
		mutex = new Semaphore(1);
		board = new Semaphore(0, true);
	}
	
	/**
	 * Calcula la suma del peso de las personas que estan
	 * dentro del ascensor
	 * @return El peso total que carga el ascensor
	 */
	public float carriedWeight() {
		float carrying = 0;
		for (Peep peep : peopleInLift) {
			carrying += peep.getWeight();
		}
		return carrying;
	}

	@Override
	public String toString() {
		return "[Ascensor: ("+peopleInLift.size()+" , "+String.format("%.2f", carriedWeight())+"kg)]";
	}

	/**
	 * Simula personas que llaman al ascensor,
	 * esperan si superan alguno de los limites.
	 * 
	 * Cuando una persona baja se libera el semaforo
	 * de las personas que esperan  y se vuelve a hacer el chequeo
	 * @param peep La persona que quiere subir
	 */
	public void getOn(Peep peep) {
		System.out.println(peep + " llama al ascensor");
		try {
			boolean canBoard;
			do {
				mutex.acquire();
				//Puede subir si no supera los limites de peso y personas
				canBoard = peep.getWeight() + carriedWeight() <= weightLimit
						&& peopleInLift.size() < peopleLimit;
				//Si puede subir...
				if (canBoard) {
					//Se anade a la lista de gente que esta dentro y sale del bucle
					peopleInLift.add(peep);
					System.out.println("\t++"+peep + " sube al ascensor " + this);
					mutex.release();
				} else {//Si no puede...
					System.out.println("    xx"+peep+ " tiene que esperar "+this);
					//Se suma un tanto a la cantidad de gente esperando
					peopleWaiting++;
					//Libera el mutex y adquiere el semaforo de espera
					mutex.release();
					board.acquire();
				} 
			} while (! canBoard);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Una persona estara en el ascensor entre 2 y 5 segundos
	 * Mas que un ascensor es un balcon con vistas
	 */
	public void use() {
		try {
			Thread.sleep(new Random().nextInt(3000)+2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Simula una persona que se baja del ascensor.
	 * Una vez ha bajado, avisa a todas las personas
	 * que estan esperando ~para que se peleen por subir~
	 * @param peep La persona que se baja del ascensor
	 */
	public void getOff(Peep peep) {
		try {
			mutex.acquire();
				//Se quita de la lista de gente montada en el ascensor
				peopleInLift.remove(peep);
				System.out.println("\t\t--"+peep+" baja del ascensor "+this);
				//Da tantos permisos como gente haya esperando,
				//es muy probable que tengan que volver a esperar
				board.release(peopleWaiting);
				peopleWaiting = 0;
			mutex.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	

}
