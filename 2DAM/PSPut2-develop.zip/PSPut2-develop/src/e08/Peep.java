package e08;

/**
*@author Sebas Lavigne
*
*/

public class Peep extends Thread {
	
	private Bathroom bathroom;
	private String name;
	
	public Peep(Bathroom bathroom, String name) {
		this.bathroom = bathroom;
		this.name = name;
	}

	@Override
	public void run() {
		bathroom.use(name);
	}
	
	
}

