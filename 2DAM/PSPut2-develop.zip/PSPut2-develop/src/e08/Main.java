package e08;

/**
*@author Sebas Lavigne
*
*/

public class Main {

	public static void main(String[] args) {
		Bathroom bathroom = new Bathroom();
		Cleaner cleaner = new Cleaner(bathroom);
		Peep[] peeps = new Peep[10];
		String[] names = {"Alice","Bob","Carol","Dan","Erin","Frank","Grace","Heidi","Isabel","Judy"};
		
		for (int i = 0; i < peeps.length; i++) {
			peeps[i] = new Peep(bathroom, names[i]);
		}
		
		//Lanza los hilos, y lanza al limpiador entre medias
		for (int i = 0; i < names.length; i++) {
			peeps[i].start();
			if (i == 3) {
				cleaner.start();
			}
		}
	}
}

