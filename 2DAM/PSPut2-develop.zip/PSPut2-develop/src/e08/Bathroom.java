package e08;

import java.util.concurrent.Semaphore;

/**
 * @author Sebas Lavigne
 *
 */

public class Bathroom {

	private boolean wetFloorSign;
	private int peepsInside;
	private Semaphore mutex;
	private Semaphore entry;
	private Semaphore cleaning;

	public Bathroom() {
		wetFloorSign = false;
		peepsInside = 0;

		mutex = new Semaphore(1);
		entry = new Semaphore(0);
		cleaning = new Semaphore(0);
	}

	public void use(String name) {
		try {
			//Lectura del boolean dentro del mutex
			mutex.acquire();
				System.out.println("=> "+name + " quiere usar el bano");
				// Si ve el cartel de suelo mojado...
				if (wetFloorSign) {
					// Espera a entrar
					System.out.println("=X=" + name + " espera a que terminen de limpiar");
			mutex.release();
					entry.acquire();
				} else {
					System.out.println("-v-" + name + " no tiene que esperar");
			mutex.release();
				}

			mutex.acquire();
				System.out.println("\t" + name + " esta usando el bano");
				peepsInside += 1;
			mutex.release();
			
			Thread.sleep(2000);
			
			mutex.acquire();
				System.out.print("<= " +name + " sale del bano");
				peepsInside -= 1;
				
				if (wetFloorSign && peepsInside == 0) {
					System.out.println(", avisa al limpiador de que el bano esta libre");
					cleaning.release();
				} else {
					System.out.println();
				}
			mutex.release();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void clean() {
		try {
			mutex.acquire();
				System.out.println("/\\El limpiador quiere limpiar, pone el cartel");
				wetFloorSign = true;
			mutex.release();
			Thread.yield();
			
			//Lectura del int peepsInside dentro del mutex
			mutex.acquire();
				//Si hay gente en el bano
				if (peepsInside != 0) {
					//Espera a que se libere el bano
					mutex.release();
					cleaning.acquire();
				} else {
					mutex.release();
				}
			
			System.out.println("--------El limpiador esta limpiando");
			Thread.sleep(5000);
			
			
			mutex.acquire();
				System.out.println("\\/El limpiador termina de limpiar, avisa a los que esperan");
				wetFloorSign = false;
			//Da tantos permisos como gente hay esperando
			for (int i = 0; i < entry.getQueueLength(); i++) {
				entry.release();
			}
			mutex.release();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
