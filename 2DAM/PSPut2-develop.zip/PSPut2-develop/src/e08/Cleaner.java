package e08;

/**
*@author Sebas Lavigne
*
*/

public class Cleaner extends Thread {
	
	private Bathroom bathroom;
	
	public Cleaner(Bathroom bathroom) {
		this.bathroom = bathroom;
	}

	@Override
	public void run() {
		bathroom.clean();
	}
	
}

