package e06;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

/**
*@author Sebas Lavigne
*
*/

public class Client {
	
	public static final int PORT = 8000;
	public static final String ADDRESS = "localhost";
	
	private Socket socket;
	private DataInputStream is = null;
	private DataOutputStream os = null;

	/**
	 * Crea un objeto Cliente, establece conexion, interactua con servidor, cierra conexion
	 * @param args
	 */
	public static void main(String[] args) {
		Client client = new Client();
		client.setConnection();
		client.socketInteraction();
		client.closeSocketStreams();
	}
	
	/**
	 * Establece conexion con el servidor
	 * usando la direccion y puerto designados
	 */
	public void setConnection() {
		try {
			socket = new Socket(ADDRESS, PORT);
			System.out.println("Socket iniciado en "
			+ socket.getInetAddress().getHostAddress() + ":" + socket.getLocalPort());
			System.out.println("Conexion establecida con: "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Cierra los flujos del Socket y cierra el Socket
	 */
	public void closeSocketStreams() {
		try {
			is.close();
			os.close();
			socket.close();
			System.out.println("Conexion terminada");
		} catch (IOException e) {
			e.printStackTrace();
		};
	}
	
	/**
	 * Pide entrada de texto por teclado
	 * @return la entrada por teclado del usuario
	 */
	public String inputString() {
		return new Scanner(System.in).nextLine();
	}
	
	/**
	 * Interactua con el servidor mediante el Socket
	 */
	public void socketInteraction() {
		String msg;
		try {
			is = new DataInputStream(socket.getInputStream());
			os = new DataOutputStream(socket.getOutputStream());
			
			while (true) {
				System.out.println("Grita en la cueva:");
				msg = inputString();
				os.writeUTF(msg);
				System.out.println("Cliente: " + msg);
				msg = is.readUTF();
				System.out.println("Servidor hace eco:\n" + msg);
				
				System.out.println();
			}
			
		} catch (IOException e) {
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

}

