package e05;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

/**
*@author Sebas Lavigne
*
*/

public class Client {
	
	public static final int PORT = 8000;
	public static final String ADDRESS = "localhost";
	
	private Socket socket;
	private DataInputStream is = null;
	private DataOutputStream os = null;

	/**
	 * Crea un objeto Cliente, establece conexion, interactua con servidor, cierra conexion
	 * @param args
	 */
	public static void main(String[] args) {
		Client client = new Client();
		client.setConnection();
		client.socketInteraction();
		client.closeSocketStreams();
	}
	
	/**
	 * Establece conexion con el servidor
	 * usando la direccion y puerto designados
	 */
	public void setConnection() {
		try {
			socket = new Socket(ADDRESS, PORT);
			System.out.println("Socket iniciado en "
			+ socket.getInetAddress().getHostAddress() + ":" + socket.getLocalPort());
			System.out.println("Conexion establecida con: "
					+ socket.getInetAddress().getHostName() + ":" + socket.getPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Interactua con el servidor mediante el Socket
	 */
	public void socketInteraction() {
		String msg;
		try {
			is = new DataInputStream(socket.getInputStream());
			os = new DataOutputStream(socket.getOutputStream());
			
			//PIM
			dramaPause();
			msg = "PIM";
			writeToServer(os, msg);
			System.out.println("Cliente: "+msg);
			
			//PAM
			dramaPause();
			System.out.println("Servidor: " + readFromServer(is));
			
			//PUM
			dramaPause();
			msg = "PUM";
			writeToServer(os, msg);
			System.out.println("Cliente: "+msg);
			
			//FUEGO
			dramaPause();
			System.out.println("Servidor: " + readFromServer(is));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Lee un String recibido a traves del Socket
	 * @param is el flujo de entrada
	 * @return el String recibido
	 * @throws IOException
	 */
	public String readFromServer(DataInputStream is) throws IOException {
		return is.readUTF();
	}
	
	/**
	 * Manda un String a traves del Socket
	 * @param os el flujo de salida
	 * @param msg el String a enviar
	 * @throws IOException
	 */
	public void writeToServer(DataOutputStream os, String msg) throws IOException {
		os.writeUTF(msg);
	}
	
	/**
	 * Espera tres segundos para generar drama
	 */
	public void dramaPause() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
		
	/**
	 * Cierra los flujos del Socket y cierra el Socket
	 */
	public void closeSocketStreams() {
		try {
			is.close();
			os.close();
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		};
	}
}

