package e04;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
*@author Sebas Lavigne
*
*/

public class Server {

	public static final int PORT = 8000;
	
	private Socket client;
	private ServerSocket server;
	private DataInputStream is = null;
	private DataOutputStream os = null;
	
	public static void main(String[] args) {
		Server server = new Server();
		server.setConnection();
		server.setClientMsg("Puedes hablar mas alto?");
		server.getClientMsg();
		server.closeSocketStreams();
	}
	
	/**
	 * Establece una conexion con un cliente
	 */
	public void setConnection() {
		try {
			server = new ServerSocket(PORT);
			System.out.println("Esperando conexion entrante en el puerto "+PORT+"...");
			
			client = server.accept();
			System.out.println("Conexion establecida con: "
					+ client.getInetAddress().getHostName());
		} catch (IOException e) {
			System.out.println("Error al establecer conexion:\n"+e.getMessage());
		}
	}
	
	/**
	 * Recibe un mensaje del cliente
	 */
	public void getClientMsg() {
		try {
			is = new DataInputStream(client.getInputStream());
			System.out.println("Cliente: "+is.readUTF());
		} catch (IOException e) {
			System.out.println("Error al leer del cliente:\n"+e.getMessage());
		}
	}
	
	/**
	 * Envia un mensaje al cliente
	 * @param msg El mensaje a enviar
	 */
	public void setClientMsg(String msg) {
		try {
			os = new DataOutputStream(client.getOutputStream());
			os.writeUTF(msg);
			System.out.println("Servidor: "+msg);
		} catch (IOException e) {
			System.out.println("Error al escribir al cliente:\n"+e.getMessage());
		}
	}
	
	/**
	 * Cierra los flujos de entrada y salida y los sockets del cliente y servidor
	 */
	public void closeSocketStreams() {
		try {
			is.close();
			os.close();
			client.close();
			server.close();
		} catch (IOException e) {
			System.out.println("Error al cerrar flujos y sockets:\n"+e.getMessage());
		}
	}
}

